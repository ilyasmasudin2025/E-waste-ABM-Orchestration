from pathlib import Path
import shutil
import csv
import re
import math
from datetime import datetime

# ============================================================
# E-WASTE ABM
# STEP 14: FINAL SUBMISSION PACKAGE + PRE-SUBMISSION AUDIT
# FINAL COMPATIBLE VERSION
# ============================================================

PROJECT_ROOT = Path(r"D:\E-WASTE-ABM")
STEP12 = PROJECT_ROOT / "results_step12"
STEP13 = PROJECT_ROOT / "results_step13"
STEP11 = PROJECT_ROOT / "results_step11"

OUT = PROJECT_ROOT / "results_step14"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
MANUSCRIPT = OUT / "manuscript"
SUPPLEMENTARY = OUT / "supplementary"
REPRO = OUT / "reproducibility"
PACKAGE = OUT / "FINAL_SUBMISSION_PACKAGE"

for p in [OUT, TABLES, FIGURES, MANUSCRIPT, SUPPLEMENTARY, REPRO, PACKAGE]:
    p.mkdir(parents=True, exist_ok=True)

def log(status, section, message):
    print(f"[{status}] {section:<50} | {message}")

def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

def copy_file(src, dst):
    if not src.exists():
        raise FileNotFoundError(str(src))
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def text(path):
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""

print("=" * 100)
print("E-WASTE ABM")
print("STEP 14: FINAL SUBMISSION PACKAGE + PRE-SUBMISSION AUDIT")
print("FINAL COMPATIBLE VERSION")
print("=" * 100)
print(f"Project root : {PROJECT_ROOT}")
print(f"Output       : {OUT}")

# ------------------------------------------------------------
# STEP 14.1 - INPUT INTEGRITY
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.1 - STEP 13 / STEP 12 INPUT INTEGRITY")
print("-" * 100)

required_inputs = {
    "step13_manifest": STEP13 / "FINAL_PUBLICATION_PACKAGE_MANIFEST.csv",
    "step13_report": STEP13 / "STEP13_FINAL_PUBLICATION_READINESS_REPORT.txt",
    "step13_table_manifest": STEP13 / "tables/12_final_table_selection_manifest.csv",
    "step13_figure_manifest": STEP13 / "tables/13_final_figure_selection_manifest.csv",
    "step13_checklist": STEP13 / "tables/14_final_publication_readiness_checklist.csv",
    "step13_validation": STEP13 / "tables/15_final_step13_validation.csv",
    "final_manuscript_docx": STEP12 / "manuscript/STEP12_FINAL_MANUSCRIPT.docx",
    "final_manuscript_txt": STEP12 / "manuscript/STEP12_FINAL_MANUSCRIPT.txt",
    "abstract": STEP12 / "manuscript/STEP12_ABSTRACT.txt",
    "method": STEP12 / "manuscript/STEP12_METHOD_INTEGRATION.txt",
    "results": STEP12 / "manuscript/STEP12_RESULTS.txt",
    "discussion": STEP12 / "manuscript/STEP12_DISCUSSION.txt",
    "limitations": STEP12 / "manuscript/STEP12_LIMITATIONS.txt",
    "conclusion": STEP12 / "manuscript/STEP12_CONCLUSION.txt",
    "traceability": STEP12 / "manuscript/STEP12_EVIDENCE_TRACEABILITY.txt",
    "numeric_highlights": STEP12 / "tables/14_numeric_highlights.csv",
    "claim_matrix": STEP12 / "tables/13_claim_to_evidence.csv",
    "step11_qc": STEP12 / "tables/15_step11_qc_matrix.csv",
    "step11_checklist": STEP12 / "tables/16_step11_checklist.csv",
    "step12_validation": STEP12 / "tables/19_final_step12_validation.csv",
}

input_failures = 0
for name, path in required_inputs.items():
    if path.exists():
        log("PASS", "Input integrity", f"{name}: {path}")
    else:
        input_failures += 1
        log("FAIL", "Input integrity", f"Missing: {path}")

if input_failures:
    raise SystemExit(f"STEP 14 STOPPED: missing inputs={input_failures}")

# ------------------------------------------------------------
# STEP 14.2 - LOAD FINAL MANUSCRIPT CONTENT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.2 - LOADING FINAL MANUSCRIPT CONTENT")
print("-" * 100)

manuscript_files = {
    "abstract": required_inputs["abstract"],
    "method": required_inputs["method"],
    "results": required_inputs["results"],
    "discussion": required_inputs["discussion"],
    "limitations": required_inputs["limitations"],
    "conclusion": required_inputs["conclusion"],
    "traceability": required_inputs["traceability"],
    "full_manuscript": required_inputs["final_manuscript_txt"],
}

manuscript_texts = {k: text(v) for k, v in manuscript_files.items()}

for k, v in manuscript_texts.items():
    log("PASS" if v.strip() else "FAIL",
        "Manuscript loading",
        f"{k}: characters={len(v)}")

# ------------------------------------------------------------
# STEP 14.3 - NUMERIC CONSISTENCY AUDIT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.3 - NUMERIC CONSISTENCY AUDIT")
print("-" * 100)

numeric_rows = read_csv(required_inputs["numeric_highlights"])
numeric_values = []

for row in numeric_rows:
    for key, value in row.items():
        s = str(value).strip()
        if not s:
            continue
        # Capture ordinary decimal/integer values while avoiding IDs/dates where possible.
        for m in re.findall(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?", s):
            try:
                x = float(m)
                if math.isfinite(x):
                    numeric_values.append(x)
            except ValueError:
                pass

# Explicit authoritative value from STEP 11/12 pipeline, checked only if present.
expected_highlight = "Scenario 5 - Combined Orchestration"
combined_text = " ".join(manuscript_texts.values())
combined_present = expected_highlight.lower() in combined_text.lower()

numeric_audit_rows = [
    {
        "audit": "Numeric highlight file readable",
        "value": len(numeric_rows),
        "status": "PASS" if len(numeric_rows) > 0 else "FAIL",
    },
    {
        "audit": "Numeric values finite",
        "value": len(numeric_values),
        "status": "PASS" if all(math.isfinite(x) for x in numeric_values) else "FAIL",
    },
    {
        "audit": "Combined Orchestration label present in manuscript",
        "value": expected_highlight,
        "status": "PASS" if combined_present else "WARN",
    },
]

for r in numeric_audit_rows:
    log(r["status"], "Numeric consistency", f"{r['audit']} = {r['value']}")

write_csv(
    TABLES / "01_numeric_consistency_audit.csv",
    numeric_audit_rows,
    ["audit", "value", "status"]
)

# ------------------------------------------------------------
# STEP 14.4 - MANUSCRIPT STRUCTURE AUDIT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.4 - MANUSCRIPT STRUCTURE AUDIT")
print("-" * 100)

structure_checks = [
    ("Abstract", manuscript_texts["abstract"]),
    ("Methodology / Method Integration", manuscript_texts["method"]),
    ("Results", manuscript_texts["results"]),
    ("Discussion", manuscript_texts["discussion"]),
    ("Limitations", manuscript_texts["limitations"]),
    ("Conclusion", manuscript_texts["conclusion"]),
    ("Evidence traceability", manuscript_texts["traceability"]),
]

structure_rows = []
for name, content in structure_checks:
    ok = bool(content.strip())
    structure_rows.append({
        "section": name,
        "characters": len(content),
        "present": "YES" if ok else "NO",
        "status": "PASS" if ok else "FAIL",
    })
    log("PASS" if ok else "FAIL", "Manuscript structure", name)

write_csv(
    TABLES / "02_manuscript_structure_audit.csv",
    structure_rows,
    ["section", "characters", "present", "status"]
)

# ------------------------------------------------------------
# STEP 14.5 - FIGURE / TABLE NUMBERING & ASSET AUDIT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.5 - FIGURE / TABLE ASSET AUDIT")
print("-" * 100)

table_manifest = read_csv(required_inputs["step13_table_manifest"])
figure_manifest = read_csv(required_inputs["step13_figure_manifest"])

asset_rows = []

for row in table_manifest:
    src = Path(row["source_file"])
    ok = src.exists() and src.stat().st_size > 0
    asset_rows.append({
        "asset_type": "TABLE",
        "asset": row["publication_table"],
        "source": str(src),
        "exists": "YES" if src.exists() else "NO",
        "non_empty": "YES" if ok else "NO",
        "status": "PASS" if ok else "FAIL",
    })
    log("PASS" if ok else "FAIL", "Table asset audit", row["publication_table"])

for row in figure_manifest:
    src = Path(row["source_file"])
    ok = src.exists() and src.stat().st_size > 0
    asset_rows.append({
        "asset_type": "FIGURE",
        "asset": row["publication_figure"],
        "source": str(src),
        "exists": "YES" if src.exists() else "NO",
        "non_empty": "YES" if ok else "NO",
        "status": "PASS" if ok else "FAIL",
    })
    log("PASS" if ok else "FAIL", "Figure asset audit", row["publication_figure"])

write_csv(
    TABLES / "03_final_asset_audit.csv",
    asset_rows,
    ["asset_type", "asset", "source", "exists", "non_empty", "status"]
)

# ------------------------------------------------------------
# STEP 14.6 - CLAIM-TO-EVIDENCE AUDIT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.6 - CLAIM-TO-EVIDENCE AUDIT")
print("-" * 100)

claims = read_csv(required_inputs["claim_matrix"])
claim_rows = []
for row in claims:
    claim = str(row.get("Claim", "")).strip()
    evidence = str(row.get("Evidence", "")).strip()
    linked = bool(claim and evidence)
    claim_rows.append({
        "claim_id": row.get("Claim ID", ""),
        "claim_area": row.get("Claim Area", ""),
        "claim": claim,
        "evidence": evidence,
        "linked": "YES" if linked else "NO",
        "status": "PASS" if linked else "FAIL",
    })

claim_linked = sum(r["linked"] == "YES" for r in claim_rows)
claim_coverage = claim_linked / len(claim_rows) * 100 if claim_rows else 0

log(
    "PASS" if claim_coverage == 100 else "FAIL",
    "Claim-to-evidence audit",
    f"{claim_linked}/{len(claim_rows)} linked; coverage={claim_coverage:.2f}%"
)

write_csv(
    TABLES / "04_final_claim_to_evidence_audit.csv",
    claim_rows,
    ["claim_id", "claim_area", "claim", "evidence", "linked", "status"]
)

# ------------------------------------------------------------
# STEP 14.7 - QC / VALIDATION GATE
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.7 - QC / VALIDATION GATE")
print("-" * 100)

qc_rows = read_csv(required_inputs["step11_qc"])
checklist_rows = read_csv(required_inputs["step11_checklist"])
validation_rows = read_csv(required_inputs["step12_validation"])

def count_fail(rows):
    return sum(1 for r in rows if any(str(v).strip().upper() == "FAIL" for v in r.values()))

qc_failures = count_fail(qc_rows)
check_failures = count_fail(checklist_rows)
validation_failures = count_fail(validation_rows)

log("PASS" if qc_failures == 0 else "FAIL",
    "QC gate", f"STEP11 QC failures={qc_failures}")
log("PASS" if check_failures == 0 else "FAIL",
    "QC gate", f"STEP11 checklist failures={check_failures}")
log("PASS" if validation_failures == 0 else "FAIL",
    "QC gate", f"STEP12 validation failures={validation_failures}")

# ------------------------------------------------------------
# STEP 14.8 - BUILD FINAL SUBMISSION MANUSCRIPT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.8 - BUILDING FINAL SUBMISSION MANUSCRIPT")
print("-" * 100)

# Preserve the authoritative DOCX unchanged and create a clearly named submission copy.
submission_docx = MANUSCRIPT / "FINAL_SUBMISSION_MANUSCRIPT.docx"
copy_file(required_inputs["final_manuscript_docx"], submission_docx)

# Consolidated text copy for audit/reference.
submission_txt = MANUSCRIPT / "FINAL_SUBMISSION_MANUSCRIPT.txt"
submission_txt.write_text(manuscript_texts["full_manuscript"], encoding="utf-8")

log("PASS", "Submission manuscript", str(submission_docx))
log("PASS", "Submission manuscript", str(submission_txt))

# ------------------------------------------------------------
# STEP 14.9 - BUILD FINAL TABLE / FIGURE PACKAGE
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.9 - BUILDING FINAL TABLE / FIGURE PACKAGE")
print("-" * 100)

# Tables
for row in table_manifest:
    src = Path(row["source_file"])
    copy_file(src, TABLES / row["publication_table"])

# Figures
for row in figure_manifest:
    src = Path(row["source_file"])
    copy_file(src, FIGURES / row["publication_figure"])

# ------------------------------------------------------------
# STEP 14.10 - BUILD SUPPLEMENTARY / REPRODUCIBILITY PACKAGE
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.10 - BUILDING SUPPLEMENTARY / REPRODUCIBILITY PACKAGE")
print("-" * 100)

supplementary_sources = [
    STEP12 / "tables/09_sensitivity_evidence.csv",
    STEP12 / "tables/10_validation_evidence.csv",
    STEP12 / "tables/12_evidence_map.csv",
    STEP12 / "tables/13_claim_to_evidence.csv",
    STEP12 / "tables/14_numeric_highlights.csv",
    STEP11 / "tables/12_reproducibility_audit.csv",
    STEP11 / "tables/16_final_quality_control_matrix.csv",
]

for src in supplementary_sources:
    if src.exists():
        copy_file(src, SUPPLEMENTARY / src.name)
        log("PASS", "Supplementary asset", src.name)

# Copy authoritative parameter/model inputs where available.
repro_sources = [
    PROJECT_ROOT / "results_step00/ABM_PARAMETER_CONFIG.json",
    PROJECT_ROOT / "results_step00/ABM_BASE_PARAMETERS.csv",
    PROJECT_ROOT / "results_step00/ABM_SCENARIO_PARAMETERS.csv",
    PROJECT_ROOT / "results_step01/STEP01_AGENT_SPECIFICATION.csv",
    PROJECT_ROOT / "results_step01/STEP01_AGENT_PARAMETERS.csv",
    PROJECT_ROOT / "results_step02/STEP02_RAW_SIMULATION_RESULTS.csv",
]

for src in repro_sources:
    if src.exists():
        copy_file(src, REPRO / src.name)
        log("PASS", "Reproducibility asset", src.name)

# ------------------------------------------------------------
# STEP 14.11 - FINAL SUBMISSION PACKAGE ASSEMBLY
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.11 - BUILDING FINAL SUBMISSION PACKAGE")
print("-" * 100)

# Copy entire prepared output components into final package.
for folder in [MANUSCRIPT, TABLES, FIGURES, SUPPLEMENTARY, REPRO]:
    for src in folder.rglob("*"):
        if src.is_file():
            rel = src.relative_to(OUT)
            copy_file(src, PACKAGE / rel)

package_files = [p for p in PACKAGE.rglob("*") if p.is_file()]
package_nonempty = all(p.stat().st_size > 0 for p in package_files)

print(f"Final submission artifacts : {len(package_files)}")
log("PASS" if package_files else "FAIL",
    "Submission package", f"Artifacts={len(package_files)}")
log("PASS" if package_nonempty else "FAIL",
    "Submission package", f"All artifacts non-empty={package_nonempty}")

# ------------------------------------------------------------
# STEP 14.12 - FINAL PRE-SUBMISSION CHECKLIST
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.12 - FINAL PRE-SUBMISSION CHECKLIST")
print("-" * 100)

checks = [
    ("STEP13 completed successfully", input_failures == 0),
    ("Manuscript DOCX available", submission_docx.exists() and submission_docx.stat().st_size > 0),
    ("Manuscript TXT available", submission_txt.exists() and submission_txt.stat().st_size > 0),
    ("All manuscript sections present", all(r["status"] == "PASS" for r in structure_rows)),
    ("All publication tables available", all(r["status"] == "PASS" for r in asset_rows if r["asset_type"] == "TABLE")),
    ("All publication figures available", all(r["status"] == "PASS" for r in asset_rows if r["asset_type"] == "FIGURE")),
    ("Claim-to-evidence coverage = 100%", claim_coverage == 100),
    ("STEP11 QC failures = 0", qc_failures == 0),
    ("STEP11 checklist failures = 0", check_failures == 0),
    ("STEP12 validation failures = 0", validation_failures == 0),
    ("Final package non-empty", package_nonempty),
]

check_rows = []
for item, ok in checks:
    status = "PASS" if ok else "FAIL"
    check_rows.append({"check": item, "status": status, "value": "TRUE" if ok else "FALSE"})
    log(status, "Pre-submission checklist", item)

write_csv(
    TABLES / "05_final_pre_submission_checklist.csv",
    check_rows,
    ["check", "status", "value"]
)

check_failures_final = sum(r["status"] == "FAIL" for r in check_rows)

# ------------------------------------------------------------
# STEP 14.13 - FINAL MANIFEST
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.13 - FINAL SUBMISSION MANIFEST")
print("-" * 100)

manifest = []
for p in sorted(package_files):
    manifest.append({
        "artifact_order": len(manifest) + 1,
        "artifact": str(p.relative_to(PACKAGE)),
        "type": p.suffix.lower().lstrip("."),
        "size_bytes": p.stat().st_size,
        "status": "PASS" if p.stat().st_size > 0 else "FAIL",
    })

write_csv(
    OUT / "FINAL_SUBMISSION_PACKAGE_MANIFEST.csv",
    manifest,
    ["artifact_order", "artifact", "type", "size_bytes", "status"]
)

print(f"Manifest artifacts : {len(manifest)}")

# ------------------------------------------------------------
# STEP 14.14 - FINAL VALIDATION
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 14.14 - FINAL STEP 14 VALIDATION")
print("-" * 100)

validation = [
    {"metric": "Input failures", "value": input_failures, "status": "PASS" if input_failures == 0 else "FAIL"},
    {"metric": "Manuscript structure failures", "value": sum(r["status"] == "FAIL" for r in structure_rows), "status": "PASS" if all(r["status"] == "PASS" for r in structure_rows) else "FAIL"},
    {"metric": "Asset failures", "value": sum(r["status"] == "FAIL" for r in asset_rows), "status": "PASS" if all(r["status"] == "PASS" for r in asset_rows) else "FAIL"},
    {"metric": "Claim coverage", "value": f"{claim_coverage:.2f}%", "status": "PASS" if claim_coverage == 100 else "FAIL"},
    {"metric": "STEP11 QC failures", "value": qc_failures, "status": "PASS" if qc_failures == 0 else "FAIL"},
    {"metric": "STEP11 checklist failures", "value": check_failures, "status": "PASS" if check_failures == 0 else "FAIL"},
    {"metric": "STEP12 validation failures", "value": validation_failures, "status": "PASS" if validation_failures == 0 else "FAIL"},
    {"metric": "Final checklist failures", "value": check_failures_final, "status": "PASS" if check_failures_final == 0 else "FAIL"},
    {"metric": "Submission artifacts", "value": len(package_files), "status": "PASS" if package_files else "FAIL"},
]

write_csv(
    TABLES / "06_final_step14_validation.csv",
    validation,
    ["metric", "value", "status"]
)

# ------------------------------------------------------------
# STEP 14.15 - FINAL REPORT
# ------------------------------------------------------------
status = "PASS" if check_failures_final == 0 else "FAIL"

report = f"""
E-WASTE ABM
STEP 14: FINAL SUBMISSION PACKAGE + PRE-SUBMISSION AUDIT
FINAL SUBMISSION READINESS REPORT

Generated: {datetime.now().isoformat(timespec='seconds')}

SUMMARY
- STEP 13 input failures: {input_failures}
- Manuscript sections audited: {len(structure_rows)}
- Publication tables audited: {sum(r["asset_type"] == "TABLE" for r in asset_rows)}
- Publication figures audited: {sum(r["asset_type"] == "FIGURE" for r in asset_rows)}
- Claim-to-evidence coverage: {claim_coverage:.2f}%
- STEP 11 QC failures: {qc_failures}
- STEP 11 checklist failures: {check_failures}
- STEP 12 validation failures: {validation_failures}
- Final checklist failures: {check_failures_final}
- Final submission artifacts: {len(package_files)}

STATUS
{status} - {"FINAL SUBMISSION PACKAGE READY" if status == "PASS" else "REVIEW REQUIRED"}

IMPORTANT
This step assembles and audits the existing authoritative outputs. It does not alter
the scientific results, statistical evidence, scenario values, sensitivity results,
or validation conclusions.

OUTPUT
{OUT}

FINAL SUBMISSION PACKAGE
{PACKAGE}
"""

(OUT / "STEP14_FINAL_SUBMISSION_READINESS_REPORT.txt").write_text(
    report.strip() + "\n", encoding="utf-8"
)

# ------------------------------------------------------------
# FINAL SUMMARY
# ------------------------------------------------------------
print("\n" + "=" * 100)
print("STEP 14 FINAL SUMMARY")
print("=" * 100)
print(f"Manuscript sections audited : {len(structure_rows)}")
print(f"Publication tables          : {sum(r['asset_type'] == 'TABLE' for r in asset_rows)}")
print(f"Publication figures         : {sum(r['asset_type'] == 'FIGURE' for r in asset_rows)}")
print(f"Claim-to-evidence coverage  : {claim_coverage:.2f}%")
print(f"STEP 11 QC failures         : {qc_failures}")
print(f"STEP 11 checklist failures  : {check_failures}")
print(f"STEP 12 validation failures : {validation_failures}")
print(f"Final checklist failures    : {check_failures_final}")
print(f"Submission artifacts        : {len(package_files)}")
print(f"Output folder               : {OUT}")
print(f"Final package               : {PACKAGE}")
print()
print("STEP 14 STATUS :", status)
print("FINAL SUBMISSION PACKAGE READY" if status == "PASS" else "FINAL SUBMISSION PACKAGE REQUIRES REVIEW")
