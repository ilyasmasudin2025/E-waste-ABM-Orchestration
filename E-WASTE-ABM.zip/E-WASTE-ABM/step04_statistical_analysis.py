r"""
E-WASTE ABM
STEP 4: INFERENTIAL STATISTICAL ANALYSIS
Final version

Purpose:
- Use replicate-level observations (30 independent replicates per scenario)
- Aggregate the 12 periods within each replicate before inferential testing
- Compare 6 scenarios using:
    1) One-way ANOVA
    2) Welch ANOVA
    3) Kruskal-Wallis
    4) Tukey HSD post-hoc
    5) Pairwise Mann-Whitney U with Holm correction
    6) Effect sizes (eta-squared, epsilon-squared, Cohen's d)
    7) Baseline-vs-scenario comparisons
- Generate publication-ready tables and figures

Input:
    D:\E-WASTE-ABM\results_step02\STEP02_RAW_SIMULATION_RESULTS.csv

Output:
    D:\E-WASTE-ABM\results_step04
"""

from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.oneway import anova_oneway
from statsmodels.stats.multitest import multipletests


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(r"D:\E-WASTE-ABM")
INPUT_DIR = ROOT / "results_step02"
OUTPUT_DIR = ROOT / "results_step04"
TABLE_DIR = OUTPUT_DIR / "tables"
FIG_DIR = OUTPUT_DIR / "figures"

RAW_FILE = INPUT_DIR / "STEP02_RAW_SIMULATION_RESULTS.csv"

SCENARIO_ORDER = [
    "Baseline",
    "Scenario 1 - Formal-Informal Integration",
    "Scenario 2 - Economic Incentives",
    "Scenario 3 - Information & Traceability",
    "Scenario 4 - Producer Responsibility",
    "Scenario 5 - Combined Orchestration",
]

METRICS = [
    "Collected (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
    "System Cost (USD)",
]

HIGHER_BETTER = {
    "Collected (kg)": True,
    "Recovered Material (kg)": True,
    "Residual Waste (kg)": False,
    "Collection Rate (%)": True,
    "Formal Participation (%)": True,
    "Ending Inventory (kg)": False,
    "System Cost (USD)": False,
}


# ============================================================
# HELPERS
# ============================================================

def banner(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def save_df(df, filename):
    path = TABLE_DIR / filename
    df.to_csv(path, index=False)
    print(f"[SAVED] {path}")
    return path


def find_column(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def cohens_d(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    nx, ny = len(x), len(y)
    vx, vy = np.var(x, ddof=1), np.var(y, ddof=1)
    pooled = np.sqrt(((nx - 1) * vx + (ny - 1) * vy) / (nx + ny - 2))
    if pooled == 0:
        return 0.0
    return (np.mean(x) - np.mean(y)) / pooled


def eta_squared_from_anova(groups):
    all_values = np.concatenate(groups)
    grand_mean = np.mean(all_values)
    ss_between = sum(len(g) * (np.mean(g) - grand_mean) ** 2 for g in groups)
    ss_total = sum(np.sum((g - grand_mean) ** 2) for g in groups)
    return ss_between / ss_total if ss_total > 0 else np.nan


def epsilon_squared_kruskal(h, k, n):
    # Rank-based effect size commonly used with Kruskal-Wallis
    return max(0.0, (h - k + 1) / (n - k))


def effect_label(value):
    if pd.isna(value):
        return "NA"
    a = abs(value)
    if a < 0.20:
        return "Negligible"
    if a < 0.50:
        return "Small"
    if a < 0.80:
        return "Medium"
    return "Large"


# ============================================================
# STEP 4.1 - LOAD DATA
# ============================================================

banner("E-WASTE ABM\nSTEP 4: INFERENTIAL STATISTICAL ANALYSIS\nFINAL VERSION")

print(f"Project root : {ROOT}")
print(f"Input        : {RAW_FILE}")
print(f"Output       : {OUTPUT_DIR}")

TABLE_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

if not RAW_FILE.exists():
    raise FileNotFoundError(
        f"Input file not found:\n{RAW_FILE}\n"
        "Run STEP 2 first."
    )

df = pd.read_csv(RAW_FILE)

print(f"\nRaw rows : {len(df)}")
print(f"Raw cols : {len(df.columns)}")


# ============================================================
# STEP 4.2 - IDENTIFY STRUCTURE
# ============================================================

banner("STEP 4.2 - DATA STRUCTURE IDENTIFICATION")

scenario_col = find_column(df, ["Scenario", "scenario"])
replicate_col = find_column(
    df,
    ["Replicate", "replicate", "Replication", "Run", "run", "Seed"]
)
period_col = find_column(df, ["Period", "period", "Time", "time"])

if scenario_col is None:
    raise ValueError("Scenario column not found.")

if replicate_col is None:
    raise ValueError(
        "Replicate identifier not found. "
        "STEP 4 requires replicate-level inference."
    )

print(f"Scenario column  : {scenario_col}")
print(f"Replicate column : {replicate_col}")
print(f"Period column    : {period_col if period_col else 'Not used'}")

scenarios = list(df[scenario_col].dropna().unique())

# preserve expected order
scenarios = [s for s in SCENARIO_ORDER if s in scenarios] + [
    s for s in scenarios if s not in SCENARIO_ORDER
]

print("\nScenarios:")
for i, s in enumerate(scenarios):
    print(f"{i}. {s}")


# ============================================================
# STEP 4.3 - VALIDATE REPLICATION
# ============================================================

banner("STEP 4.3 - REPLICATION VALIDATION")

rep_counts = (
    df.groupby(scenario_col)[replicate_col]
    .nunique()
    .reindex(scenarios)
)

validation_rows = []

for scenario in scenarios:
    n_rep = int(rep_counts.loc[scenario])
    subset = df[df[scenario_col] == scenario]

    if period_col:
        n_period = subset[period_col].nunique()
    else:
        n_period = np.nan

    passed = (n_rep == 30) and (pd.isna(n_period) or n_period == 12)

    validation_rows.append({
        "Scenario": scenario,
        "Replicates": n_rep,
        "Periods": n_period,
        "Expected Replicates": 30,
        "Expected Periods": 12,
        "Status": "PASS" if passed else "CHECK"
    })

validation = pd.DataFrame(validation_rows)
save_df(validation, "01_replication_validation.csv")
print(validation.to_string(index=False))

if not all(validation["Status"] == "PASS"):
    print("\n[WARNING] Replication structure differs from expected 30 × 12.")
    print("STEP 4 will continue using available replicate identifiers.")


# ============================================================
# STEP 4.4 - BUILD REPLICATE-LEVEL DATASET
# ============================================================

banner("STEP 4.4 - REPLICATE-LEVEL AGGREGATION")

available_metrics = [m for m in METRICS if m in df.columns]

if len(available_metrics) < len(METRICS):
    missing = [m for m in METRICS if m not in df.columns]
    print(f"[WARNING] Missing metrics: {missing}")

print(f"Metrics used : {len(available_metrics)}")

# Critical methodological choice:
# 12 periods are aggregated within each replicate.
# Therefore each scenario contributes approximately n=30 independent
# replicate-level observations, rather than 360 pseudo-replicates.

group_cols = [scenario_col, replicate_col]

replicate_df = (
    df.groupby(group_cols, as_index=False)[available_metrics]
    .mean()
)

replicate_df = replicate_df.rename(
    columns={
        scenario_col: "Scenario",
        replicate_col: "Replicate"
    }
)

replicate_df["Scenario"] = pd.Categorical(
    replicate_df["Scenario"],
    categories=scenarios,
    ordered=True
)

replicate_df = replicate_df.sort_values(["Scenario", "Replicate"])

save_df(replicate_df, "02_replicate_level_data.csv")

print(f"Replicate-level rows : {len(replicate_df)}")
print(
    replicate_df.groupby("Scenario", observed=False)["Replicate"]
    .nunique()
    .to_string()
)


# ============================================================
# STEP 4.5 - REPLICATE DESCRIPTIVE SUMMARY
# ============================================================

banner("STEP 4.5 - REPLICATE-LEVEL DESCRIPTIVE SUMMARY")

desc_rows = []

for scenario in scenarios:
    sub = replicate_df[replicate_df["Scenario"] == scenario]

    for metric in available_metrics:
        x = sub[metric].dropna().astype(float)

        desc_rows.append({
            "Scenario": scenario,
            "Metric": metric,
            "N": len(x),
            "Mean": x.mean(),
            "SD": x.std(ddof=1),
            "SE": x.std(ddof=1) / np.sqrt(len(x)),
            "Median": x.median(),
            "Minimum": x.min(),
            "Maximum": x.max(),
            "95% CI Lower": (
                x.mean() - stats.t.ppf(0.975, len(x)-1) *
                x.std(ddof=1) / np.sqrt(len(x))
                if len(x) > 1 else np.nan
            ),
            "95% CI Upper": (
                x.mean() + stats.t.ppf(0.975, len(x)-1) *
                x.std(ddof=1) / np.sqrt(len(x))
                if len(x) > 1 else np.nan
            ),
        })

rep_desc = pd.DataFrame(desc_rows)
save_df(rep_desc, "03_replicate_descriptive_statistics.csv")


# ============================================================
# STEP 4.6 - ASSUMPTION DIAGNOSTICS
# ============================================================

banner("STEP 4.6 - ASSUMPTION DIAGNOSTICS")

assumption_rows = []

for metric in available_metrics:
    groups = [
        replicate_df.loc[
            replicate_df["Scenario"] == s, metric
        ].dropna().astype(float).values
        for s in scenarios
    ]

    groups = [g for g in groups if len(g) >= 2]

    # Shapiro-Wilk on residual-like centered observations is not used
    # as a decisive gate; it is reported descriptively.
    shapiro_ps = []
    for g in groups:
        if 3 <= len(g) <= 5000:
            try:
                shapiro_ps.append(stats.shapiro(g).pvalue)
            except Exception:
                pass

    try:
        lev_stat, lev_p = stats.levene(*groups, center="median")
    except Exception:
        lev_stat, lev_p = np.nan, np.nan

    assumption_rows.append({
        "Metric": metric,
        "Levene Statistic": lev_stat,
        "Levene p-value": lev_p,
        "Equal Variance at alpha=0.05": (
            "Yes" if pd.notna(lev_p) and lev_p >= 0.05 else "No/Check"
        ),
        "Minimum Shapiro p": (
            np.min(shapiro_ps) if shapiro_ps else np.nan
        ),
    })

assumptions = pd.DataFrame(assumption_rows)
save_df(assumptions, "04_assumption_diagnostics.csv")
print(assumptions.to_string(index=False))


# ============================================================
# STEP 4.7 - ANOVA / WELCH / KRUSKAL-WALLIS
# ============================================================

banner("STEP 4.7 - OMNIBUS INFERENTIAL TESTS")

omnibus_rows = []

for metric in available_metrics:
    groups_by_scenario = {
        s: replicate_df.loc[
            replicate_df["Scenario"] == s, metric
        ].dropna().astype(float).values
        for s in scenarios
    }

    groups = list(groups_by_scenario.values())

    # Classical one-way ANOVA
    try:
        f_stat, p_anova = stats.f_oneway(*groups)
    except Exception:
        f_stat, p_anova = np.nan, np.nan

    # Welch ANOVA
    try:
        welch = anova_oneway(
            np.concatenate(groups),
            groups=np.concatenate([
                np.repeat(s, len(groups_by_scenario[s]))
                for s in scenarios
            ]),
            use_var="unequal"
        )
        welch_f = float(welch.statistic)
        welch_p = float(welch.pvalue)
        welch_df = str(welch.df)
    except Exception:
        welch_f, welch_p, welch_df = np.nan, np.nan, ""

    # Kruskal-Wallis
    try:
        h_stat, p_kw = stats.kruskal(*groups)
    except Exception:
        h_stat, p_kw = np.nan, np.nan

    eta2 = eta_squared_from_anova(groups)
    eps2 = epsilon_squared_kruskal(
        h_stat, len(groups), sum(len(g) for g in groups)
    ) if pd.notna(h_stat) else np.nan

    omnibus_rows.append({
        "Metric": metric,
        "ANOVA F": f_stat,
        "ANOVA p": p_anova,
        "Welch F": welch_f,
        "Welch p": welch_p,
        "Welch df": welch_df,
        "Kruskal-Wallis H": h_stat,
        "Kruskal-Wallis p": p_kw,
        "Eta-squared": eta2,
        "Eta-squared Interpretation": effect_label(np.sqrt(eta2)) if pd.notna(eta2) else "NA",
        "Epsilon-squared": eps2,
    })

omnibus = pd.DataFrame(omnibus_rows)
save_df(omnibus, "05_omnibus_tests.csv")
print(omnibus.to_string(index=False))


# ============================================================
# STEP 4.8 - TUKEY HSD POST-HOC
# ============================================================

banner("STEP 4.8 - TUKEY HSD POST-HOC")

tukey_rows = []

for metric in available_metrics:
    tmp = replicate_df[["Scenario", metric]].dropna().copy()

    try:
        tukey = pairwise_tukeyhsd(
            endog=tmp[metric].astype(float),
            groups=tmp["Scenario"].astype(str),
            alpha=0.05
        )

        table = pd.DataFrame(
            tukey.summary().data[1:],
            columns=tukey.summary().data[0]
        )

        for _, r in table.iterrows():
            tukey_rows.append({
                "Metric": metric,
                "Group 1": r["group1"],
                "Group 2": r["group2"],
                "Mean Difference": float(r["meandiff"]),
                "p-adjusted": float(r["p-adj"]),
                "Lower CI": float(r["lower"]),
                "Upper CI": float(r["upper"]),
                "Reject H0": bool(r["reject"]),
            })

    except Exception as e:
        print(f"[WARNING] Tukey failed for {metric}: {e}")

tukey_df = pd.DataFrame(tukey_rows)
save_df(tukey_df, "06_tukey_hsd_posthoc.csv")


# ============================================================
# STEP 4.9 - NONPARAMETRIC PAIRWISE TESTS
# ============================================================

banner("STEP 4.9 - PAIRWISE MANN-WHITNEY U + HOLM CORRECTION")

mw_rows = []

for metric in available_metrics:
    raw_results = []

    for i in range(len(scenarios)):
        for j in range(i + 1, len(scenarios)):
            s1, s2 = scenarios[i], scenarios[j]

            x = replicate_df.loc[
                replicate_df["Scenario"] == s1, metric
            ].dropna().astype(float).values

            y = replicate_df.loc[
                replicate_df["Scenario"] == s2, metric
            ].dropna().astype(float).values

            try:
                u, p = stats.mannwhitneyu(
                    x, y,
                    alternative="two-sided"
                )
            except Exception:
                u, p = np.nan, np.nan

            raw_results.append({
                "Metric": metric,
                "Group 1": s1,
                "Group 2": s2,
                "U": u,
                "p-raw": p,
            })

    if raw_results:
        pvals = [r["p-raw"] for r in raw_results]
        valid = [pd.notna(p) for p in pvals]

        valid_p = [p for p in pvals if pd.notna(p)]

        if valid_p:
            _, p_holm, _, _ = multipletests(
                valid_p,
                alpha=0.05,
                method="holm"
            )

            idx = 0
            for r, ok in zip(raw_results, valid):
                if ok:
                    r["p-Holm"] = p_holm[idx]
                    r["Significant alpha=0.05"] = p_holm[idx] < 0.05
                    idx += 1
                else:
                    r["p-Holm"] = np.nan
                    r["Significant alpha=0.05"] = False

        mw_rows.extend(raw_results)

mw_df = pd.DataFrame(mw_rows)
save_df(mw_df, "07_mannwhitney_holm_posthoc.csv")


# ============================================================
# STEP 4.10 - BASELINE VS EACH SCENARIO
# ============================================================

banner("STEP 4.10 - BASELINE VS ALL INTERVENTION SCENARIOS")

baseline = "Baseline"
baseline_rows = []

for metric in available_metrics:
    x = replicate_df.loc[
        replicate_df["Scenario"] == baseline, metric
    ].dropna().astype(float).values

    for scenario in scenarios:
        if scenario == baseline:
            continue

        y = replicate_df.loc[
            replicate_df["Scenario"] == scenario, metric
        ].dropna().astype(float).values

        # Welch t-test
        try:
            t_stat, p_t = stats.ttest_ind(
                x, y,
                equal_var=False
            )
        except Exception:
            t_stat, p_t = np.nan, np.nan

        # Mann-Whitney
        try:
            u_stat, p_u = stats.mannwhitneyu(
                x, y,
                alternative="two-sided"
            )
        except Exception:
            u_stat, p_u = np.nan, np.nan

        d = cohens_d(y, x)  # positive means scenario > baseline

        baseline_rows.append({
            "Metric": metric,
            "Scenario": scenario,
            "Baseline Mean": np.mean(x),
            "Scenario Mean": np.mean(y),
            "Absolute Difference (Scenario - Baseline)": np.mean(y) - np.mean(x),
            "Percentage Change vs Baseline (%)": (
                ((np.mean(y) - np.mean(x)) / np.mean(x) * 100)
                if np.mean(x) != 0 else np.nan
            ),
            "Welch t": t_stat,
            "Welch p": p_t,
            "Mann-Whitney U": u_stat,
            "Mann-Whitney p": p_u,
            "Cohen's d (Scenario - Baseline)": d,
            "Effect Interpretation": effect_label(d),
            "Direction": (
                "Higher"
                if np.mean(y) > np.mean(x)
                else "Lower"
                if np.mean(y) < np.mean(x)
                else "Equal"
            ),
            "Significant Welch alpha=0.05": (
                pd.notna(p_t) and p_t < 0.05
            ),
            "Significant MW alpha=0.05": (
                pd.notna(p_u) and p_u < 0.05
            ),
        })

baseline_df = pd.DataFrame(baseline_rows)
save_df(baseline_df, "08_baseline_vs_scenarios.csv")


# ============================================================
# STEP 4.11 - EFFECT SIZE SUMMARY
# ============================================================

banner("STEP 4.11 - EFFECT SIZE SUMMARY")

effect_rows = []

for metric in available_metrics:
    om = omnibus.loc[omnibus["Metric"] == metric].iloc[0]

    effect_rows.append({
        "Metric": metric,
        "Eta-squared": om["Eta-squared"],
        "Epsilon-squared": om["Epsilon-squared"],
        "ANOVA p": om["ANOVA p"],
        "Welch p": om["Welch p"],
        "Kruskal-Wallis p": om["Kruskal-Wallis p"],
        "Overall Evidence": (
            "Significant"
            if (
                (pd.notna(om["ANOVA p"]) and om["ANOVA p"] < 0.05)
                or
                (pd.notna(om["Welch p"]) and om["Welch p"] < 0.05)
                or
                (pd.notna(om["Kruskal-Wallis p"]) and om["Kruskal-Wallis p"] < 0.05)
            )
            else "Not significant"
        )
    })

effect_df = pd.DataFrame(effect_rows)
save_df(effect_df, "09_effect_size_summary.csv")


# ============================================================
# STEP 4.12 - STATISTICAL CONCLUSIONS
# ============================================================

banner("STEP 4.12 - STATISTICAL CONCLUSIONS")

conclusion_rows = []

for metric in available_metrics:
    om = omnibus.loc[omnibus["Metric"] == metric].iloc[0]

    tuk = tukey_df[tukey_df["Metric"] == metric] if not tukey_df.empty else pd.DataFrame()

    sig_tukey = int(tuk["Reject H0"].sum()) if not tuk.empty else 0

    mw = mw_df[mw_df["Metric"] == metric] if not mw_df.empty else pd.DataFrame()
    sig_mw = int(mw["Significant alpha=0.05"].sum()) if not mw.empty else 0

    conclusion_rows.append({
        "Metric": metric,
        "ANOVA p": om["ANOVA p"],
        "Welch p": om["Welch p"],
        "Kruskal-Wallis p": om["Kruskal-Wallis p"],
        "Eta-squared": om["Eta-squared"],
        "Epsilon-squared": om["Epsilon-squared"],
        "Significant Tukey Pairs": sig_tukey,
        "Significant MW-Holm Pairs": (
            int(
                mw["p-Holm"].lt(0.05).sum()
            ) if "p-Holm" in mw.columns else 0
        ),
        "Conclusion": (
            "Scenario effect detected"
            if (
                (pd.notna(om["Welch p"]) and om["Welch p"] < 0.05)
                or
                (pd.notna(om["Kruskal-Wallis p"]) and om["Kruskal-Wallis p"] < 0.05)
            )
            else "No statistically significant scenario effect detected"
        )
    })

conclusions = pd.DataFrame(conclusion_rows)
save_df(conclusions, "10_statistical_conclusions.csv")
print(conclusions.to_string(index=False))


# ============================================================
# STEP 4.13 - FIGURES
# ============================================================

banner("STEP 4.13 - GENERATING FIGURES")

def scenario_boxplot(metric, filename, ylabel=None):
    data = [
        replicate_df.loc[
            replicate_df["Scenario"] == s, metric
        ].dropna().astype(float).values
        for s in scenarios
    ]

    plt.figure(figsize=(12, 7))
    plt.boxplot(data, tick_labels=[
        "Baseline",
        "S1",
        "S2",
        "S3",
        "S4",
        "S5"
    ])
    plt.ylabel(ylabel if ylabel else metric)
    plt.title(f"Replicate-Level Distribution: {metric}")
    plt.xticks(rotation=0)
    plt.grid(axis="y", alpha=0.25)
    plt.tight_layout()
    path = FIG_DIR / filename
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"[SAVED] {path}")


scenario_boxplot(
    "Collected (kg)",
    "01_boxplot_collected_ewaste.png",
    "Collected E-waste (kg)"
)

scenario_boxplot(
    "Recovered Material (kg)",
    "02_boxplot_recovered_material.png",
    "Recovered Material (kg)"
)

scenario_boxplot(
    "Collection Rate (%)",
    "03_boxplot_collection_rate.png",
    "Collection Rate (%)"
)

scenario_boxplot(
    "Formal Participation (%)",
    "04_boxplot_formal_participation.png",
    "Formal Participation (%)"
)

scenario_boxplot(
    "System Cost (USD)",
    "05_boxplot_system_cost.png",
    "System Cost (USD)"
)


# Effect size chart
plot_effect = effect_df.copy()
plot_effect = plot_effect.sort_values("Eta-squared", ascending=True)

plt.figure(figsize=(10, 7))
plt.barh(plot_effect["Metric"], plot_effect["Eta-squared"])
plt.xlabel("Eta-squared")
plt.title("Scenario Effect Size by Metric")
plt.grid(axis="x", alpha=0.25)
plt.tight_layout()
path = FIG_DIR / "06_eta_squared_effect_size.png"
plt.savefig(path, dpi=300, bbox_inches="tight")
plt.close()
print(f"[SAVED] {path}")


# Baseline comparison chart: percentage changes
key_metrics = [
    "Collected (kg)",
    "Recovered Material (kg)",
    "Collection Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
    "System Cost (USD)",
]

bc = baseline_df[
    baseline_df["Metric"].isin(key_metrics)
].copy()

for metric in key_metrics:
    tmp = bc[bc["Metric"] == metric].copy()
    if tmp.empty:
        continue

    plt.figure(figsize=(11, 6))
    plt.bar(
        ["S1", "S2", "S3", "S4", "S5"],
        tmp["Percentage Change vs Baseline (%)"]
    )
    plt.axhline(0, linewidth=1)
    plt.ylabel("Change vs Baseline (%)")
    plt.title(f"Baseline Comparison: {metric}")
    plt.grid(axis="y", alpha=0.25)
    plt.tight_layout()

    safe = (
        metric.lower()
        .replace(" ", "_")
        .replace("(", "")
        .replace(")", "")
        .replace("%", "pct")
        .replace("/", "_")
    )
    path = FIG_DIR / f"07_baseline_change_{safe}.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"[SAVED] {path}")


# ============================================================
# STEP 4.14 - REPORT
# ============================================================

banner("STEP 4.14 - GENERATING STEP 4 REPORT")

n_sig = int(
    conclusions["Conclusion"]
    .eq("Scenario effect detected")
    .sum()
)

report_lines = [
    "E-WASTE ABM",
    "STEP 4: INFERENTIAL STATISTICAL ANALYSIS",
    "FINAL VERSION",
    "",
    f"Input: {RAW_FILE}",
    f"Output: {OUTPUT_DIR}",
    "",
    "METHODOLOGICAL NOTE",
    "The 12 simulation periods were aggregated within each replicate.",
    "Therefore, inferential tests use replicate-level observations",
    "(approximately 30 independent replicates per scenario) rather",
    "than treating 360 scenario-period observations as independent.",
    "",
    f"Scenarios analyzed: {len(scenarios)}",
    f"Metrics analyzed: {len(available_metrics)}",
    f"Statistically differentiated metrics: {n_sig}/{len(available_metrics)}",
    "",
    "OMNIBUS RESULTS",
]

for _, r in conclusions.iterrows():
    report_lines.append(
        f"- {r['Metric']}: {r['Conclusion']} | "
        f"ANOVA p={r['ANOVA p']:.6g} | "
        f"Welch p={r['Welch p']:.6g} | "
        f"KW p={r['Kruskal-Wallis p']:.6g} | "
        f"eta²={r['Eta-squared']:.4f}"
    )

report_lines += [
    "",
    "KEY BASELINE COMPARISONS",
]

for metric in [
    "Collected (kg)",
    "Recovered Material (kg)",
    "Collection Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
    "System Cost (USD)",
]:
    tmp = baseline_df[baseline_df["Metric"] == metric]

    for _, r in tmp.iterrows():
        report_lines.append(
            f"- {metric} | {r['Scenario']} | "
            f"change={r['Percentage Change vs Baseline (%)']:.2f}% | "
            f"Welch p={r['Welch p']:.6g} | "
            f"Cohen's d={r["Cohen's d (Scenario - Baseline)"]:.3f}"
        )

report_lines += [
    "",
    "INTERPRETATION GUIDANCE",
    "1. Use omnibus tests to establish whether scenario differences exist.",
    "2. Use Tukey HSD for pairwise mean comparisons when ANOVA assumptions are acceptable.",
    "3. Use Welch ANOVA when variance heterogeneity is present.",
    "4. Use Kruskal-Wallis and Mann-Whitney-Holm as nonparametric robustness checks.",
    "5. Interpret statistical significance together with effect size and practical magnitude.",
    "",
    "STEP 4 STATUS: PASS",
    "READY FOR NEXT STEP",
]

report_path = OUTPUT_DIR / "STEP04_INFERENTIAL_ANALYSIS_REPORT.txt"
report_path.write_text("\n".join(report_lines), encoding="utf-8")

print(f"[SAVED] {report_path}")


# ============================================================
# STEP 4.15 - FINAL VALIDATION
# ============================================================

banner("STEP 4.15 - FINAL STEP 4 VALIDATION")

checks = [
    ("Input file", RAW_FILE.exists()),
    ("Raw data non-empty", len(df) > 0),
    ("Scenario column", scenario_col is not None),
    ("Replicate identifier", replicate_col is not None),
    ("Expected scenarios", len(scenarios) == 6),
    ("Replicate-level dataset", len(replicate_df) > 0),
    ("Descriptive statistics", (TABLE_DIR / "03_replicate_descriptive_statistics.csv").exists()),
    ("Omnibus tests", (TABLE_DIR / "05_omnibus_tests.csv").exists()),
    ("Tukey post-hoc", (TABLE_DIR / "06_tukey_hsd_posthoc.csv").exists()),
    ("Mann-Whitney post-hoc", (TABLE_DIR / "07_mannwhitney_holm_posthoc.csv").exists()),
    ("Baseline comparisons", (TABLE_DIR / "08_baseline_vs_scenarios.csv").exists()),
    ("Effect sizes", (TABLE_DIR / "09_effect_size_summary.csv").exists()),
    ("Statistical conclusions", (TABLE_DIR / "10_statistical_conclusions.csv").exists()),
    ("Figures", len(list(FIG_DIR.glob("*.png"))) >= 6),
    ("Report", report_path.exists()),
]

all_pass = True

for label, ok in checks:
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {label}")
    all_pass = all_pass and ok

print("\n" + "=" * 100)
print("STEP 4 FINAL SUMMARY")
print("=" * 100)
print(f"Scenarios analyzed          : {len(scenarios)}")
print(f"Replicate-level rows       : {len(replicate_df)}")
print(f"Metrics analyzed           : {len(available_metrics)}")
print(f"Scenario effects detected  : {n_sig}/{len(available_metrics)}")
print(f"Tables generated           : {len(list(TABLE_DIR.glob('*.csv')))}")
print(f"Figures generated          : {len(list(FIG_DIR.glob('*.png')))}")
print(f"Output folder              : {OUTPUT_DIR}")
print(f"Tables folder              : {TABLE_DIR}")
print(f"Figures folder             : {FIG_DIR}")
print("\nSTEP 4 STATUS :", "PASS" if all_pass else "CHECK")
print("=" * 100)

if not all_pass:
    raise SystemExit("STEP 4 validation failed. Review the checks above.")

print("READY FOR NEXT STEP")
