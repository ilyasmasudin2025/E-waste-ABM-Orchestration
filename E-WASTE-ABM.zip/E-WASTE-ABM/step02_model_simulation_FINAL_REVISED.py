from pathlib import Path
import json
import math
import random
import pandas as pd


# ============================================================
# E-WASTE ABM
# STEP 2: MODEL IMPLEMENTATION & SCENARIO SIMULATION
# FINAL REVISION BEFORE STEP 3
#
# Main revisions:
# 1. Robust scenario-parameter parser:
#    supports both LONG and WIDE CSV formats.
#
# 2. Correct collection mechanism:
#    Formal participation
#        -> collection incentive / accessibility
#        -> effective collection efficiency
#        -> operational collector capacity
#        -> collected e-waste
#
# 3. Correct cost mechanism:
#    collection cost = collected × collection cost/kg
#    processing cost = processed × processing cost/kg
#    system cost = collection cost + processing cost
#
# 4. Unit consistency:
#    consumer e-waste generation is kg/household/year.
#    With 12 simulation periods/year, generation is
#    converted to kg/household/month.
#
# 5. Collector capacity:
#    source parameter = kg/collector/day.
#    converted to monthly operational capacity using
#    DAYS_PER_PERIOD.
#
# 6. Scenario-specific mechanisms:
#    Scenario 1 -> formalization
#    Scenario 2 -> collection incentive
#    Scenario 3 -> information & traceability
#    Scenario 4 -> producer responsibility
#    Scenario 5 -> combined orchestration
#
# 7. 30 replicates × 12 periods × 6 scenarios.
# ============================================================


# ============================================================
# PROJECT DIRECTORIES
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

STEP00_DIR = PROJECT_ROOT / "results_step00"
STEP01_DIR = PROJECT_ROOT / "results_step01"
OUTPUT_DIR = PROJECT_ROOT / "results_step02"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# SIMULATION SETTINGS
# ============================================================

NUM_REPLICATES = 30

# 12 periods = 12 months/year
PERIODS_PER_YEAR = 12

# Collection capacity from source is kg/collector/day.
DAYS_PER_PERIOD = 30


# ============================================================
# DISPLAY UTILITIES
# ============================================================

def banner(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def section(title):
    print("\n" + "-" * 100)
    print(title)
    print("-" * 100)


# ============================================================
# GENERAL UTILITIES
# ============================================================

def clean_number(value, default=0.0):

    if value is None:
        return default

    try:

        if pd.isna(value):
            return default

        if isinstance(value, str):

            text = (
                value
                .strip()
                .replace(",", "")
                .replace("$", "")
                .replace("USD", "")
                .replace("Rp", "")
                .replace("%", "")
            )

            if text == "":
                return default

            return float(text)

        return float(value)

    except (ValueError, TypeError):

        return default


def normalize_text(value):

    if value is None:
        return ""

    text = str(value).strip().lower()

    replacements = {
        "_": " ",
        "-": " ",
        "/": " ",
        "–": " ",
        "—": " ",
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    text = " ".join(text.split())

    return text


def clamp(value, low=0.0, high=1.0):

    return max(
        low,
        min(high, clean_number(value))
    )


def is_numeric(value):

    try:

        if pd.isna(value):
            return False

        float(str(value).replace(",", "").replace("%", "").strip())

        return True

    except (ValueError, TypeError):

        return False


# ============================================================
# PARAMETER SEARCH
# ============================================================

def find_parameter(
    df,
    possible_names,
    default=None
):

    if df is None or df.empty:
        return default

    columns = {
        normalize_text(c): c
        for c in df.columns
    }

    parameter_col = None
    value_col = None

    parameter_candidates = [
        "parameter",
        "parameter name",
        "parameter_name",
        "name",
        "variable",
        "variable name",
    ]

    value_candidates = [
        "value",
        "base value",
        "base_value",
        "value numeric",
        "value_numeric",
        "parameter value",
    ]

    for candidate in parameter_candidates:

        key = normalize_text(candidate)

        if key in columns:

            parameter_col = columns[key]

            break

    for candidate in value_candidates:

        key = normalize_text(candidate)

        if key in columns:

            value_col = columns[key]

            break

    if parameter_col is None or value_col is None:

        return default

    targets = [
        normalize_text(x)
        for x in possible_names
    ]

    # Exact match
    for _, row in df.iterrows():

        current = normalize_text(
            row[parameter_col]
        )

        if current in targets:

            return clean_number(
                row[value_col],
                default
            )

    # Partial match
    for target in targets:

        for _, row in df.iterrows():

            current = normalize_text(
                row[parameter_col]
            )

            if (
                target in current
                or current in target
            ):

                return clean_number(
                    row[value_col],
                    default
                )

    return default


# ============================================================
# SCENARIO NAME NORMALIZATION
# ============================================================

def scenario_matches(
    scenario_text,
    aliases
):

    current = normalize_text(
        scenario_text
    )

    for alias in aliases:

        target = normalize_text(alias)

        if (
            current == target
            or target in current
            or current in target
        ):

            return True

    return False


# ============================================================
# ROBUST SCENARIO PARAMETER EXTRACTION
# ============================================================

def find_scenario_parameter(
    df,
    scenario_aliases,
    parameter_aliases,
    default=None
):

    if df is None or df.empty:
        return default

    # --------------------------------------------------------
    # METHOD A
    # LONG FORMAT
    #
    # Scenario | Parameter | Value
    # --------------------------------------------------------

    normalized_columns = {
        normalize_text(c): c
        for c in df.columns
    }

    scenario_col = None
    parameter_col = None
    value_col = None

    scenario_candidates = [
        "scenario",
        "scenario name",
        "scenario_name",
    ]

    parameter_candidates = [
        "parameter",
        "parameter name",
        "parameter_name",
        "variable",
        "variable name",
    ]

    value_candidates = [
        "value",
        "scenario value",
        "scenario_value",
        "parameter value",
    ]

    for candidate in scenario_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            scenario_col = normalized_columns[key]

            break

    for candidate in parameter_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            parameter_col = normalized_columns[key]

            break

    for candidate in value_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            value_col = normalized_columns[key]

            break

    if (
        scenario_col is not None
        and parameter_col is not None
        and value_col is not None
    ):

        for _, row in df.iterrows():

            scenario_text = row[scenario_col]
            parameter_text = row[parameter_col]

            scenario_ok = scenario_matches(
                scenario_text,
                scenario_aliases
            )

            parameter_ok = False

            ptext = normalize_text(
                parameter_text
            )

            for alias in parameter_aliases:

                target = normalize_text(alias)

                if (
                    ptext == target
                    or target in ptext
                    or ptext in target
                ):

                    parameter_ok = True
                    break

            if scenario_ok and parameter_ok:

                return clean_number(
                    row[value_col],
                    default
                )

    # --------------------------------------------------------
    # METHOD B
    # WIDE FORMAT
    #
    # Parameter | Baseline | Scenario 1 | Scenario 2 | ...
    # --------------------------------------------------------

    # Find parameter column
    parameter_column = None

    for candidate in parameter_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            parameter_column = normalized_columns[key]

            break

    if parameter_column is None:

        # Often the first column is parameter
        parameter_column = df.columns[0]

    # Find matching parameter row
    matching_rows = []

    for _, row in df.iterrows():

        ptext = normalize_text(
            row[parameter_column]
        )

        matched = False

        for alias in parameter_aliases:

            target = normalize_text(alias)

            if (
                ptext == target
                or target in ptext
                or ptext in target
            ):

                matched = True
                break

        if matched:

            matching_rows.append(row)

    if not matching_rows:

        return default

    row = matching_rows[0]

    # Find scenario column
    for column in df.columns:

        column_text = normalize_text(
            column
        )

        if scenario_matches(
            column_text,
            scenario_aliases
        ):

            return clean_number(
                row[column],
                default
            )

    # --------------------------------------------------------
    # Special handling based on scenario ID
    # --------------------------------------------------------

    scenario_id = None

    for alias in scenario_aliases:

        text = normalize_text(alias)

        if text.startswith("scenario 1"):
            scenario_id = 1

        elif text.startswith("scenario 2"):
            scenario_id = 2

        elif text.startswith("scenario 3"):
            scenario_id = 3

        elif text.startswith("scenario 4"):
            scenario_id = 4

        elif text.startswith("scenario 5"):
            scenario_id = 5

    if scenario_id is not None:

        possible_columns = [
            f"Scenario {scenario_id}",
            f"Scenario {scenario_id} ",
            f"Scenario {scenario_id} (F-I Integration)",
            f"Scenario {scenario_id} (Economic Incentives)",
            f"Scenario {scenario_id} (Info & Traceability)",
            f"Scenario {scenario_id} (Producer Responsibility)",
            f"Scenario {scenario_id} (Combined)",
        ]

        for candidate in possible_columns:

            candidate_norm = normalize_text(
                candidate
            )

            for column in df.columns:

                column_norm = normalize_text(
                    column
                )

                if (
                    candidate_norm == column_norm
                    or candidate_norm in column_norm
                    or column_norm in candidate_norm
                ):

                    return clean_number(
                        row[column],
                        default
                    )

    return default


# ============================================================
# LOAD FILES
# ============================================================

banner(
    "E-WASTE ABM\n"
    "STEP 2: MODEL IMPLEMENTATION & SCENARIO SIMULATION\n"
    "FINAL REVISION BEFORE STEP 3"
)

print(
    f"Project root : {PROJECT_ROOT}"
)

print(
    f"Output       : {OUTPUT_DIR}"
)


banner(
    "STEP 2.1 - LOADING STEP 0–1"
)


base_file = (
    STEP00_DIR
    / "ABM_BASE_PARAMETERS.csv"
)

scenario_file = (
    STEP00_DIR
    / "ABM_SCENARIO_PARAMETERS.csv"
)

json_file = (
    STEP00_DIR
    / "ABM_PARAMETER_CONFIG.json"
)

agent_spec_file = (
    STEP01_DIR
    / "STEP01_AGENT_SPECIFICATION.csv"
)

agent_parameter_file = (
    STEP01_DIR
    / "STEP01_AGENT_PARAMETERS.csv"
)


required_files = [
    base_file,
    scenario_file,
    json_file,
    agent_spec_file,
    agent_parameter_file,
]


for path in required_files:

    if path.exists():

        print(
            f"[FOUND] {path}"
        )

    else:

        print(
            f"[ERROR] Missing: {path}"
        )

        raise FileNotFoundError(path)


base_df = pd.read_csv(
    base_file
)

scenario_df = pd.read_csv(
    scenario_file
)

agent_spec_df = pd.read_csv(
    agent_spec_file
)

agent_parameter_df = pd.read_csv(
    agent_parameter_file
)


with open(
    json_file,
    "r",
    encoding="utf-8"
) as f:

    config_json = json.load(f)


print(
    f"\nBase parameters     : {len(base_df)}"
)

print(
    f"Scenario parameters : {len(scenario_df)}"
)

print(
    f"Agent specifications: {len(agent_spec_df)}"
)

print(
    f"Agent parameters    : {len(agent_parameter_df)}"
)


# ============================================================
# BASE PARAMETERS
# ============================================================

banner(
    "STEP 2.2 - PARAMETER EXTRACTION"
)


def get_base(
    names,
    default
):

    return find_parameter(
        base_df,
        names,
        default
    )


# ------------------------------------------------------------
# Population
# ------------------------------------------------------------

NUM_CONSUMERS = int(
    round(
        get_base(
            [
                "consumer count",
                "number of consumers",
                "consumers",
                "consumer agents",
            ],
            100
        )
    )
)


NUM_COLLECTORS = int(
    round(
        get_base(
            [
                "collector count",
                "number of collectors",
                "collectors",
                "collector agents",
            ],
            1
        )
    )
)


NUM_RECYCLERS = int(
    round(
        get_base(
            [
                "recycler count",
                "number of recyclers",
                "recyclers",
                "recycler agents",
            ],
            1
        )
    )
)


# ------------------------------------------------------------
# Simulation
# ------------------------------------------------------------

NUM_PERIODS = int(
    round(
        get_base(
            [
                "simulation periods",
                "number of periods",
                "periods",
                "time periods",
            ],
            12
        )
    )
)


RANDOM_SEED = int(
    round(
        get_base(
            [
                "random seed",
                "seed",
                "simulation seed",
            ],
            42
        )
    )
)


# ------------------------------------------------------------
# Consumer generation
# ------------------------------------------------------------

EWASTE_PER_CONSUMER_YEAR = get_base(
    [
        "e-waste per consumer",
        "ewaste per consumer",
        "e-waste generation",
        "e waste generation",
        "consumer e-waste",
        "waste per consumer",
        "e-waste generation rate",
    ],
    8.25
)


# IMPORTANT:
# Source value is kg/household/year.
# Convert to kg/household/month.

EWASTE_PER_CONSUMER_PERIOD = (
    EWASTE_PER_CONSUMER_YEAR
    / PERIODS_PER_YEAR
)


# ------------------------------------------------------------
# Consumer behavioral variables
# ------------------------------------------------------------

AWARENESS = get_base(
    [
        "awareness",
        "consumer awareness",
    ],
    0.50
)


INCENTIVE = get_base(
    [
        "incentive",
        "economic incentive",
    ],
    0.50
)


ACCESSIBILITY = get_base(
    [
        "accessibility",
        "collection accessibility",
    ],
    0.50
)


CONVENIENCE = get_base(
    [
        "convenience",
        "collection convenience",
    ],
    0.50
)


TRUST = get_base(
    [
        "trust",
        "institutional trust",
    ],
    0.47
)


# ------------------------------------------------------------
# System parameters
# ------------------------------------------------------------

COLLECTION_EFFICIENCY = get_base(
    [
        "collection efficiency",
        "collection_efficiency",
        "collection efficiency rate",
    ],
    0.80
)


RECOVERY_RATE = get_base(
    [
        "recovery rate",
        "material recovery rate",
        "recycling recovery rate",
    ],
    0.653
)


# Source C2:
# collection capacity = 23.9 kg/collector/day

COLLECTOR_CAPACITY_PER_DAY = get_base(
    [
        "collector capacity",
        "collection capacity",
        "collection capacity per period",
        "collection capacity per day",
    ],
    23.9
)


# Convert daily collector capacity
# into monthly capacity.

COLLECTOR_CAPACITY_PER_PERIOD = (
    COLLECTOR_CAPACITY_PER_DAY
    * DAYS_PER_PERIOD
)


PROCESSING_CAPACITY = get_base(
    [
        "recycler capacity",
        "processing capacity",
        "recycling capacity",
    ],
    506.0
)


# ------------------------------------------------------------
# Cost parameters
# ------------------------------------------------------------

COLLECTION_COST_PER_KG = get_base(
    [
        "collection cost per kg",
        "collection cost",
        "cost collection",
    ],
    0.337
)


PROCESSING_COST_PER_KG = get_base(
    [
        "processing cost per kg",
        "processing cost",
        "recycling cost",
    ],
    0.835
)


# ============================================================
# PRINT BASE PARAMETERS
# ============================================================

print(
    f"Consumers                     : {NUM_CONSUMERS}"
)

print(
    f"Collectors                    : {NUM_COLLECTORS}"
)

print(
    f"Recyclers                     : {NUM_RECYCLERS}"
)

print(
    f"Simulation periods            : {NUM_PERIODS}"
)

print(
    f"Random seed                   : {RANDOM_SEED}"
)

print(
    f"E-waste / consumer / year     : "
    f"{EWASTE_PER_CONSUMER_YEAR:.4f} kg"
)

print(
    f"E-waste / consumer / period   : "
    f"{EWASTE_PER_CONSUMER_PERIOD:.4f} kg"
)

print(
    f"Awareness                     : {AWARENESS:.4f}"
)

print(
    f"Incentive                     : {INCENTIVE:.4f}"
)

print(
    f"Accessibility                 : {ACCESSIBILITY:.4f}"
)

print(
    f"Convenience                   : {CONVENIENCE:.4f}"
)

print(
    f"Trust                         : {TRUST:.4f}"
)

print(
    f"Collection efficiency         : "
    f"{COLLECTION_EFFICIENCY:.4f}"
)

print(
    f"Recovery rate                 : "
    f"{RECOVERY_RATE:.4f}"
)

print(
    f"Collector capacity/day        : "
    f"{COLLECTOR_CAPACITY_PER_DAY:.4f} kg"
)

print(
    f"Collector capacity/period     : "
    f"{COLLECTOR_CAPACITY_PER_PERIOD:.4f} kg"
)

print(
    f"Processing capacity/period    : "
    f"{PROCESSING_CAPACITY:.4f} kg"
)

print(
    f"Collection cost / kg          : "
    f"USD {COLLECTION_COST_PER_KG:.4f}"
)

print(
    f"Processing cost / kg          : "
    f"USD {PROCESSING_COST_PER_KG:.4f}"
)


# ============================================================
# SCENARIOS
# ============================================================

banner(
    "STEP 2.3 - SCENARIO CONFIGURATION"
)


SCENARIOS = [

    {
        "id": 0,
        "name": "Baseline",
        "aliases": [
            "baseline",
            "base",
        ],
    },

    {
        "id": 1,
        "name": "Scenario 1 - Formal-Informal Integration",
        "aliases": [
            "scenario 1",
            "formal informal integration",
            "formal-informal integration",
            "scenario 1 (f-i integration)",
        ],
    },

    {
        "id": 2,
        "name": "Scenario 2 - Economic Incentives",
        "aliases": [
            "scenario 2",
            "economic incentives",
            "economic incentive",
            "scenario 2 (economic incentives)",
        ],
    },

    {
        "id": 3,
        "name": "Scenario 3 - Information & Traceability",
        "aliases": [
            "scenario 3",
            "information traceability",
            "information & traceability",
            "information and traceability",
            "scenario 3 (info & traceability)",
        ],
    },

    {
        "id": 4,
        "name": "Scenario 4 - Producer Responsibility",
        "aliases": [
            "scenario 4",
            "producer responsibility",
            "producer-responsibility",
            "scenario 4 (producer responsibility)",
        ],
    },

    {
        "id": 5,
        "name": "Scenario 5 - Combined Orchestration",
        "aliases": [
            "scenario 5",
            "combined orchestration",
            "combined",
            "scenario 5 (combined)",
        ],
    },
]


for scenario in SCENARIOS:

    print(
        f"{scenario['id']}. "
        f"{scenario['name']}"
    )


# ============================================================
# SCENARIO PARAMETER ACCESS
# ============================================================

def scenario_value(
    scenario,
    parameter_names,
    baseline_value
):

    if scenario["id"] == 0:

        return baseline_value

    value = find_scenario_parameter(
        scenario_df,
        scenario["aliases"],
        parameter_names,
        None
    )

    if value is None:

        return baseline_value

    return value


# ============================================================
# FALLBACK SCENARIO VALUES
#
# These values reflect the scenario-adjustment structure
# documented in the ABM elicitation data.
#
# They are used ONLY if the CSV cannot expose the relevant
# scenario-specific field.
# ============================================================

BASELINE_POLICY_PARAMETERS = {
    "formalization_incentive": 200.0,
    "collection_incentive": 0.121,
    "transparency": 0.24,
    "epr_requirement": 0.295,
    "enforcement": 0.26,
}


SCENARIO_FALLBACKS = {

    1: {
        "formalization_incentive": 605.0,
        "collection_incentive": 0.121,
        "transparency": 0.34,
        "epr_requirement": 0.295,
        "enforcement": 0.36,
    },

    2: {
        "formalization_incentive": 200.0,
        "collection_incentive": 0.555,
        "transparency": 0.24,
        "epr_requirement": 0.295,
        "enforcement": 0.26,
    },

    3: {
        "formalization_incentive": 200.0,
        "collection_incentive": 0.121,
        "transparency": 0.79,
        "epr_requirement": 0.295,
        "enforcement": 0.26,
    },

    4: {
        "formalization_incentive": 335.0,
        "collection_incentive": 0.183,
        "transparency": 0.34,
        "epr_requirement": 0.64,
        "enforcement": 0.46,
    },

    5: {
        "formalization_incentive": 705.0,
        "collection_incentive": 0.655,
        "transparency": 0.88,
        "epr_requirement": 0.75,
        "enforcement": 0.56,
    },
}


def scenario_special_value(
    scenario,
    parameter_names,
    fallback_key
):

    value = find_scenario_parameter(
        scenario_df,
        scenario["aliases"],
        parameter_names,
        None
    )

    if value is not None:

        return value

    if scenario["id"] == 0:

        return BASELINE_POLICY_PARAMETERS.get(
            fallback_key,
            0.0
        )

    return SCENARIO_FALLBACKS.get(
        scenario["id"],
        {}
    ).get(
        fallback_key,
        0.0
    )


# ============================================================
# BUILD SCENARIO PARAMETERS
# ============================================================

def build_scenario_parameters(
    scenario
):

    # --------------------------------------------------------
    # Primary behavioral parameters
    # --------------------------------------------------------

    awareness = scenario_value(
        scenario,
        [
            "awareness",
            "consumer awareness",
        ],
        AWARENESS
    )

    incentive = scenario_value(
        scenario,
        [
            "incentive",
            "economic incentive",
        ],
        INCENTIVE
    )

    accessibility = scenario_value(
        scenario,
        [
            "accessibility",
            "collection accessibility",
        ],
        ACCESSIBILITY
    )

    convenience = scenario_value(
        scenario,
        [
            "convenience",
            "collection convenience",
        ],
        CONVENIENCE
    )

    trust = scenario_value(
        scenario,
        [
            "trust",
            "institutional trust",
        ],
        TRUST
    )

    collection_efficiency = scenario_value(
        scenario,
        [
            "collection efficiency",
            "collection_efficiency",
        ],
        COLLECTION_EFFICIENCY
    )

    recovery_rate = scenario_value(
        scenario,
        [
            "recovery rate",
            "material recovery rate",
        ],
        RECOVERY_RATE
    )

    # --------------------------------------------------------
    # Operational parameters
    # --------------------------------------------------------

    collector_capacity = scenario_value(
        scenario,
        [
            "collector capacity",
            "collection capacity",
            "collection capacity per day",
        ],
        COLLECTOR_CAPACITY_PER_DAY
    )

    processing_capacity = scenario_value(
        scenario,
        [
            "processing capacity",
            "recycler capacity",
        ],
        PROCESSING_CAPACITY
    )

    ewaste_per_consumer = scenario_value(
        scenario,
        [
            "e-waste per consumer",
            "ewaste per consumer",
            "e-waste generation",
        ],
        EWASTE_PER_CONSUMER_YEAR
    )

    # --------------------------------------------------------
    # Special policy parameters
    # --------------------------------------------------------

    formalization_incentive = (
        scenario_special_value(
            scenario,
            [
                "formalization incentive",
                "formalisation incentive",
            ],
            "formalization_incentive"
        )
    )

    collection_incentive = (
        scenario_special_value(
            scenario,
            [
                "collection incentive",
                "collection incentive usd kg",
            ],
            "collection_incentive"
        )
    )

    transparency = (
        scenario_special_value(
            scenario,
            [
                "information transparency",
                "information transparency level",
                "transparency",
            ],
            "transparency"
        )
    )

    epr_requirement = (
        scenario_special_value(
            scenario,
            [
                "epr compliance requirement",
                "epr requirement",
                "producer responsibility",
            ],
            "epr_requirement"
        )
    )

    enforcement = (
        scenario_special_value(
            scenario,
            [
                "regulatory enforcement intensity",
                "enforcement intensity",
                "regulatory enforcement",
            ],
            "enforcement"
        )
    )

    return {

        "awareness": clamp(
            awareness
        ),

        "incentive": clamp(
            incentive
        ),

        "accessibility": clamp(
            accessibility
        ),

        "convenience": clamp(
            convenience
        ),

        "trust": clamp(
            trust
        ),

        "collection_efficiency": clamp(
            collection_efficiency
        ),

        "recovery_rate": clamp(
            recovery_rate
        ),

        # Capacity remains in kg/day here.
        "collector_capacity_day": max(
            0.0,
            collector_capacity
        ),

        # Convert to period capacity.
        "collector_capacity_period": (
            max(
                0.0,
                collector_capacity
            )
            * DAYS_PER_PERIOD
            * max(1, NUM_COLLECTORS)
        ),

        "processing_capacity": max(
            0.0,
            processing_capacity
        ),

        "ewaste_per_consumer_year": max(
            0.0,
            ewaste_per_consumer
        ),

        "ewaste_per_consumer_period": (
            max(
                0.0,
                ewaste_per_consumer
            )
            / PERIODS_PER_YEAR
        ),

        "formalization_incentive": max(
            0.0,
            formalization_incentive
        ),

        "collection_incentive": max(
            0.0,
            collection_incentive
        ),

        "transparency": clamp(
            transparency
        ),

        "epr_requirement": clamp(
            epr_requirement
        ),

        "enforcement": clamp(
            enforcement
        ),
    }


# ============================================================
# CONSUMER AGENT
# ============================================================

class ConsumerAgent:

    def __init__(
        self,
        agent_id,
        awareness,
        incentive,
        accessibility,
        convenience,
        trust,
        ewaste,
        rng
    ):

        self.agent_id = agent_id

        self.awareness = clamp(
            awareness
        )

        self.incentive = clamp(
            incentive
        )

        self.accessibility = clamp(
            accessibility
        )

        self.convenience = clamp(
            convenience
        )

        self.trust = clamp(
            trust
        )

        self.ewaste = max(
            0.0,
            ewaste
        )

        self.rng = rng

        self.decision_score = 0.0
        self.formal_probability = 0.0
        self.formal_collection = False

    def decide(
        self,
        policy_effect=0.0
    ):

        # ----------------------------------------------------
        # Base behavioral score
        # ----------------------------------------------------

        self.decision_score = (

            0.20 * self.awareness

            + 0.20 * self.incentive

            + 0.20 * self.accessibility

            + 0.20 * self.convenience

            + 0.20 * self.trust
        )

        # ----------------------------------------------------
        # Policy effect
        # ----------------------------------------------------

        self.decision_score = clamp(
            self.decision_score
            + policy_effect,
            0.0,
            1.0
        )

        # ----------------------------------------------------
        # Logistic probability
        # ----------------------------------------------------

        x = 8.0 * (
            self.decision_score
            - 0.5
        )

        try:

            self.formal_probability = (
                1.0
                /
                (
                    1.0
                    + math.exp(-x)
                )
            )

        except OverflowError:

            self.formal_probability = (
                1.0
                if x > 0
                else 0.0
            )

        # ----------------------------------------------------
        # Probabilistic decision
        # ----------------------------------------------------

        self.formal_collection = (
            self.rng.random()
            <
            self.formal_probability
        )

        return self.formal_collection


# ============================================================
# COLLECTOR AGENT
# ============================================================

class CollectorAgent:

    def __init__(
        self,
        agent_id,
        capacity_per_period,
        efficiency
    ):

        self.agent_id = agent_id

        self.capacity_per_period = max(
            0.0,
            capacity_per_period
        )

        self.efficiency = clamp(
            efficiency
        )

    def collect(
        self,
        incoming
    ):

        incoming = max(
            0.0,
            incoming
        )

        # Potential collection after efficiency.
        potential_collection = (
            incoming
            * self.efficiency
        )

        # Operational capacity is the final physical limit.
        collected = min(
            potential_collection,
            self.capacity_per_period
        )

        return max(
            0.0,
            collected
        )


# ============================================================
# RECYCLER AGENT
# ============================================================

class RecyclerAgent:

    def __init__(
        self,
        agent_id,
        capacity_per_period,
        recovery_rate
    ):

        self.agent_id = agent_id

        self.capacity_per_period = max(
            0.0,
            capacity_per_period
        )

        self.recovery_rate = clamp(
            recovery_rate
        )

    def process(
        self,
        incoming
    ):

        incoming = max(
            0.0,
            incoming
        )

        processable = min(
            incoming,
            self.capacity_per_period
        )

        recovered = (
            processable
            * self.recovery_rate
        )

        residual = (
            processable
            - recovered
        )

        return (
            processable,
            recovered,
            residual
        )


# ============================================================
# POLICY EFFECT CALCULATION
# ============================================================

def calculate_policy_effect(
    scenario,
    params
):

    if scenario["id"] == 0:

        return 0.0

    # --------------------------------------------------------
    # Formalization incentive effect
    #
    # Normalized using 200 USD baseline.
    # --------------------------------------------------------

    formalization_effect = (
        (
            params["formalization_incentive"]
            - 200.0
        )
        / 1000.0
    )

    # --------------------------------------------------------
    # Collection incentive effect
    # --------------------------------------------------------

    collection_incentive_effect = (
        (
            params["collection_incentive"]
            - 0.121
        )
        * 0.60
    )

    # --------------------------------------------------------
    # Information transparency effect
    # --------------------------------------------------------

    transparency_effect = (
        (
            params["transparency"]
            - 0.24
        )
        * 0.20
    )

    # --------------------------------------------------------
    # EPR effect
    # --------------------------------------------------------

    epr_effect = (
        (
            params["epr_requirement"]
            - 0.295
        )
        * 0.20
    )

    # --------------------------------------------------------
    # Enforcement effect
    # --------------------------------------------------------

    enforcement_effect = (
        (
            params["enforcement"]
            - 0.26
        )
        * 0.15
    )

    total_effect = (
        formalization_effect
        + collection_incentive_effect
        + transparency_effect
        + epr_effect
        + enforcement_effect
    )

    # Keep policy effect realistic.
    return max(
        -0.15,
        min(
            0.20,
            total_effect
        )
    )


# ============================================================
# OPERATIONAL COLLECTION EFFECT
# ============================================================

def calculate_operational_efficiency(
    scenario,
    params
):

    base_efficiency = (
        params["collection_efficiency"]
    )

    # --------------------------------------------------------
    # Collection incentive improves willingness and
    # operational attractiveness of collection.
    # --------------------------------------------------------

    incentive_effect = (
        params["collection_incentive"]
        - 0.121
    ) * 0.20

    # --------------------------------------------------------
    # Accessibility/convenience are direct operational
    # factors.
    # --------------------------------------------------------

    accessibility_effect = (
        params["accessibility"]
        - ACCESSIBILITY
    ) * 0.10

    convenience_effect = (
        params["convenience"]
        - CONVENIENCE
    ) * 0.10

    # --------------------------------------------------------
    # Transparency supports traceability and reduces
    # collection leakage.
    # --------------------------------------------------------

    transparency_effect = (
        params["transparency"]
        - 0.24
    ) * 0.10

    # --------------------------------------------------------
    # Enforcement supports formal collection.
    # --------------------------------------------------------

    enforcement_effect = (
        params["enforcement"]
        - 0.26
    ) * 0.10

    effective_efficiency = (
        base_efficiency
        + incentive_effect
        + accessibility_effect
        + convenience_effect
        + transparency_effect
        + enforcement_effect
    )

    return clamp(
        effective_efficiency
    )


# ============================================================
# SIMULATION
# ============================================================

def run_simulation(
    scenario,
    replicate,
    random_seed
):

    params = build_scenario_parameters(
        scenario
    )

    rng = random.Random(
        random_seed
    )

    # --------------------------------------------------------
    # Agents
    # --------------------------------------------------------

    consumers = []

    for i in range(
        NUM_CONSUMERS
    ):

        consumer = ConsumerAgent(

            agent_id=f"C_{i + 1}",

            awareness=params[
                "awareness"
            ],

            incentive=params[
                "incentive"
            ],

            accessibility=params[
                "accessibility"
            ],

            convenience=params[
                "convenience"
            ],

            trust=params[
                "trust"
            ],

            ewaste=params[
                "ewaste_per_consumer_period"
            ],

            rng=rng,
        )

        consumers.append(
            consumer
        )

    # --------------------------------------------------------
    # Effective collection efficiency
    # --------------------------------------------------------

    effective_collection_efficiency = (
        calculate_operational_efficiency(
            scenario,
            params
        )
    )

    # --------------------------------------------------------
    # Collector capacity
    #
    # Total capacity:
    # capacity/day × days/period × collectors
    # --------------------------------------------------------

    total_collector_capacity = (
        params[
            "collector_capacity_period"
        ]
    )

    collector_capacity_each = (
        total_collector_capacity
        /
        max(
            1,
            NUM_COLLECTORS
        )
    )

    collectors = [

        CollectorAgent(

            agent_id=f"COL_{i + 1}",

            capacity_per_period=(
                collector_capacity_each
            ),

            efficiency=(
                effective_collection_efficiency
            ),
        )

        for i in range(
            NUM_COLLECTORS
        )
    ]

    # --------------------------------------------------------
    # Recycler capacity
    # --------------------------------------------------------

    recycler_capacity_each = (
        params[
            "processing_capacity"
        ]
        /
        max(
            1,
            NUM_RECYCLERS
        )
    )

    recyclers = [

        RecyclerAgent(

            agent_id=f"REC_{i + 1}",

            capacity_per_period=(
                recycler_capacity_each
            ),

            recovery_rate=params[
                "recovery_rate"
            ],
        )

        for i in range(
            NUM_RECYCLERS
        )
    ]

    # --------------------------------------------------------
    # Simulation state
    # --------------------------------------------------------

    rows = []

    ending_inventory = 0.0

    cumulative_generated = 0.0
    cumulative_formal = 0.0
    cumulative_informal = 0.0
    cumulative_collected = 0.0
    cumulative_processed = 0.0
    cumulative_recovered = 0.0
    cumulative_residual = 0.0

    cumulative_collection_cost = 0.0
    cumulative_processing_cost = 0.0
    cumulative_system_cost = 0.0

    # ========================================================
    # PERIOD LOOP
    # ========================================================

    for period in range(
        1,
        NUM_PERIODS + 1
    ):

        opening_inventory = ending_inventory

        generated = 0.0

        formal_ewaste = 0.0

        informal_ewaste = 0.0

        formal_participants = 0

        # ----------------------------------------------------
        # Consumer decision
        # ----------------------------------------------------

        policy_effect = (
            calculate_policy_effect(
                scenario,
                params
            )
        )

        for consumer in consumers:

            consumer.decide(
                policy_effect=policy_effect
            )

            generated += (
                consumer.ewaste
            )

            if consumer.formal_collection:

                formal_ewaste += (
                    consumer.ewaste
                )

                formal_participants += 1

            else:

                informal_ewaste += (
                    consumer.ewaste
                )

        # ----------------------------------------------------
        # COLLECTION
        #
        # Formal e-waste enters collection system.
        # Each collector receives an equal share.
        # ----------------------------------------------------

        incoming_per_collector = (
            formal_ewaste
            /
            max(
                1,
                NUM_COLLECTORS
            )
        )

        collected = 0.0

        collector_capacity_used = 0.0

        collector_capacity_total = 0.0

        for collector in collectors:

            c = collector.collect(
                incoming_per_collector
            )

            collected += c

            collector_capacity_used += c

            collector_capacity_total += (
                collector.capacity_per_period
            )

        # ----------------------------------------------------
        # Collection capacity utilization
        # ----------------------------------------------------

        collection_capacity_utilization = (

            collector_capacity_used
            /
            collector_capacity_total
            * 100.0

            if collector_capacity_total > 0

            else 0.0
        )

        # ----------------------------------------------------
        # Collection loss / leakage
        #
        # Formal material that does not get collected remains
        # outside the formal recycling stream.
        # ----------------------------------------------------

        collection_uncollected = max(
            0.0,
            formal_ewaste
            - collected
        )

        # ----------------------------------------------------
        # PROCESSING
        # ----------------------------------------------------

        incoming_per_recycler = (
            collected
            /
            max(
                1,
                NUM_RECYCLERS
            )
        )

        processed = 0.0

        recovered = 0.0

        residual = 0.0

        for recycler in recyclers:

            p, r, rs = recycler.process(
                incoming_per_recycler
            )

            processed += p

            recovered += r

            residual += rs

        # ----------------------------------------------------
        # Material that entered collection but could not
        # be processed due to recycler capacity.
        # ----------------------------------------------------

        unprocessed = max(
            0.0,
            collected
            - processed
        )

        processing_residual = residual

        residual_total = (
            processing_residual
            + unprocessed
        )

        # ----------------------------------------------------
        # DETAILED MASS-BALANCE CHECKS
        # ----------------------------------------------------
        # Formal stream: formal = collected + uncollected
        collection_balance_difference = (
            formal_ewaste
            - collected
            - collection_uncollected
        )

        # Collection stream: collected = processed + unprocessed
        processing_balance_difference = (
            collected
            - processed
            - unprocessed
        )

        # Recycling stream: processed = recovered + processing residual
        recycling_balance_difference = (
            processed
            - recovered
            - processing_residual
        )

        # ----------------------------------------------------
        # ENDING INVENTORY
        #
        # Inventory contains:
        # previous inventory
        # + uncollected formal waste
        # + informal waste
        #
        # The collected and processed stream leaves the
        # inventory.
        # ----------------------------------------------------

        ending_inventory = max(
            0.0,
            ending_inventory
            + collection_uncollected
            + informal_ewaste
        )

        overall_mass_balance_difference = (
            opening_inventory
            + generated
            - recovered
            - residual_total
            - ending_inventory
        )

        mass_balance_pass = (
            abs(collection_balance_difference) <= 1e-8
            and abs(processing_balance_difference) <= 1e-8
            and abs(recycling_balance_difference) <= 1e-8
            and abs(overall_mass_balance_difference) <= 1e-8
        )

        # ----------------------------------------------------
        # COSTS
        #
        # IMPORTANT:
        # Costs are based on actual mass flows.
        #
        # Collection cost:
        # collected × collection cost/kg
        #
        # Processing cost:
        # processed × processing cost/kg
        # ----------------------------------------------------

        collection_cost = (
            collected
            * COLLECTION_COST_PER_KG
        )

        processing_cost = (
            processed
            * PROCESSING_COST_PER_KG
        )

        system_cost = (
            collection_cost
            + processing_cost
        )

        # ----------------------------------------------------
        # RATES
        # ----------------------------------------------------

        collection_rate = (

            collected
            /
            formal_ewaste
            * 100.0

            if formal_ewaste > 0

            else 0.0
        )

        recovery_rate = (

            recovered
            /
            processed
            * 100.0

            if processed > 0

            else 0.0
        )

        formal_participation = (

            formal_participants
            /
            NUM_CONSUMERS
            * 100.0

            if NUM_CONSUMERS > 0

            else 0.0
        )

        processing_utilization = (

            processed
            /
            (
                params[
                    "processing_capacity"
                ]
                *
                max(
                    1,
                    NUM_RECYCLERS
                )
            )
            * 100.0

            if params[
                "processing_capacity"
            ] > 0

            else 0.0
        )

        # ----------------------------------------------------
        # SOURCE MASS BALANCE
        #
        # Generation = formal + informal
        # ----------------------------------------------------

        source_mass_balance_difference = (
            generated
            - formal_ewaste
            - informal_ewaste
        )

        # ----------------------------------------------------
        # CUMULATIVE VALUES
        # ----------------------------------------------------

        cumulative_generated += generated

        cumulative_formal += (
            formal_ewaste
        )

        cumulative_informal += (
            informal_ewaste
        )

        cumulative_collected += (
            collected
        )

        cumulative_processed += (
            processed
        )

        cumulative_recovered += (
            recovered
        )

        cumulative_residual += (
            residual_total
        )

        cumulative_collection_cost += (
            collection_cost
        )

        cumulative_processing_cost += (
            processing_cost
        )

        cumulative_system_cost += (
            system_cost
        )

        # ----------------------------------------------------
        # STORE PERIOD RESULT
        # ----------------------------------------------------

        rows.append({

            "Scenario ID":
                scenario["id"],

            "Scenario":
                scenario["name"],

            "Replicate":
                replicate,

            "Random Seed":
                random_seed,

            "Period":
                period,

            # ------------------------------
            # MASS FLOW
            # ------------------------------

            "Generated E-waste (kg)":
                generated,

            "Formal E-waste (kg)":
                formal_ewaste,

            "Informal E-waste (kg)":
                informal_ewaste,

            "Collected (kg)":
                collected,

            "Collection Uncollected (kg)":
                collection_uncollected,

            "Processed (kg)":
                processed,

            "Recovered Material (kg)":
                recovered,

            "Residual Waste (kg)":
                residual_total,

            "Processing Residual Waste (kg)":
                processing_residual,

            "Unprocessed Waste (kg)":
                unprocessed,

            # ------------------------------
            # INVENTORY
            # ------------------------------

            "Opening Inventory (kg)":
                opening_inventory,

            "Ending Inventory (kg)":
                ending_inventory,

            # ------------------------------
            # PERFORMANCE
            # ------------------------------

            "Collection Rate (%)":
                collection_rate,

            "Recovery Rate (%)":
                recovery_rate,

            "Formal Participation (%)":
                formal_participation,

            "Collection Capacity Utilization (%)":
                collection_capacity_utilization,

            "Processing Capacity Utilization (%)":
                processing_utilization,

            # ------------------------------
            # COST
            # ------------------------------

            "Collection Cost (USD)":
                collection_cost,

            "Processing Cost (USD)":
                processing_cost,

            "System Cost (USD)":
                system_cost,

            # ------------------------------
            # BEHAVIOR
            # ------------------------------

            "Awareness":
                params["awareness"],

            "Incentive":
                params["incentive"],

            "Accessibility":
                params["accessibility"],

            "Convenience":
                params["convenience"],

            "Trust":
                params["trust"],

            # ------------------------------
            # POLICY PARAMETERS
            # ------------------------------

            "Formalization Incentive (USD)":
                params[
                    "formalization_incentive"
                ],

            "Collection Incentive (USD/kg)":
                params[
                    "collection_incentive"
                ],

            "Information Transparency":
                params[
                    "transparency"
                ],

            "EPR Compliance Requirement":
                params[
                    "epr_requirement"
                ],

            "Regulatory Enforcement":
                params[
                    "enforcement"
                ],

            # ------------------------------
            # SYSTEM PARAMETERS
            # ------------------------------

            "Base Collection Efficiency":
                params[
                    "collection_efficiency"
                ],

            "Effective Collection Efficiency":
                effective_collection_efficiency,

            "Model Recovery Rate":
                params[
                    "recovery_rate"
                ],

            "Collector Capacity (kg/period)":
                collector_capacity_total,

            "Processing Capacity (kg/period)":
                params[
                    "processing_capacity"
                ]
                *
                max(
                    1,
                    NUM_RECYCLERS
                ),

            # ------------------------------
            # VALIDATION
            # ------------------------------

            "Source Mass Balance Difference (kg)":
                source_mass_balance_difference,

            "Collection Mass Balance Difference (kg)":
                collection_balance_difference,

            "Processing Mass Balance Difference (kg)":
                processing_balance_difference,

            "Recycling Mass Balance Difference (kg)":
                recycling_balance_difference,

            "Overall Mass Balance Difference (kg)":
                overall_mass_balance_difference,

            # Backward-compatible validation field used by
            # downstream STEP 6/7 scripts.
            "Mass Balance Difference (kg)":
                overall_mass_balance_difference,

            "Mass Balance":
                (
                    "PASS"
                    if mass_balance_pass
                    else "FAIL"
                ),
        })

    return rows


# ============================================================
# STEP 2.4 - SCENARIO PARAMETER AUDIT
# ============================================================

banner(
    "STEP 2.4 - SCENARIO PARAMETER AUDIT"
)


scenario_parameter_rows = []

for scenario in SCENARIOS:

    params = build_scenario_parameters(
        scenario
    )

    scenario_parameter_rows.append({

        "Scenario ID":
            scenario["id"],

        "Scenario":
            scenario["name"],

        "Awareness":
            params["awareness"],

        "Incentive":
            params["incentive"],

        "Accessibility":
            params["accessibility"],

        "Convenience":
            params["convenience"],

        "Trust":
            params["trust"],

        "Collection Efficiency":
            params["collection_efficiency"],

        "Effective Collection Efficiency":
            calculate_operational_efficiency(
                scenario,
                params
            ),

        "Recovery Rate":
            params["recovery_rate"],

        "Collector Capacity (kg/day)":
            params["collector_capacity_day"],

        "Collector Capacity (kg/period)":
            params["collector_capacity_period"],

        "Processing Capacity (kg/period)":
            params["processing_capacity"],

        "E-waste / Consumer / Year":
            params["ewaste_per_consumer_year"],

        "E-waste / Consumer / Period":
            params["ewaste_per_consumer_period"],

        "Formalization Incentive (USD)":
            params["formalization_incentive"],

        "Collection Incentive (USD/kg)":
            params["collection_incentive"],

        "Information Transparency":
            params["transparency"],

        "EPR Compliance Requirement":
            params["epr_requirement"],

        "Regulatory Enforcement":
            params["enforcement"],
    })


scenario_parameter_df = pd.DataFrame(
    scenario_parameter_rows
)


print(
    "\nSCENARIO PARAMETER MATRIX\n"
)

print(
    scenario_parameter_df[
        [
            "Scenario ID",
            "Scenario",
            "Awareness",
            "Incentive",
            "Accessibility",
            "Convenience",
            "Trust",
            "Collection Efficiency",
            "Effective Collection Efficiency",
            "Recovery Rate",
            "Collector Capacity (kg/day)",
            "Processing Capacity (kg/period)",
            "Formalization Incentive (USD)",
            "Collection Incentive (USD/kg)",
            "Information Transparency",
            "EPR Compliance Requirement",
            "Regulatory Enforcement",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# UNIQUE PROFILE CHECK
# ============================================================

profile_columns = [

    "Awareness",
    "Incentive",
    "Accessibility",
    "Convenience",
    "Trust",
    "Collection Efficiency",
    "Effective Collection Efficiency",
    "Recovery Rate",
    "Formalization Incentive (USD)",
    "Collection Incentive (USD/kg)",
    "Information Transparency",
    "EPR Compliance Requirement",
    "Regulatory Enforcement",
]


unique_profiles = (
    scenario_parameter_df[
        profile_columns
    ]
    .drop_duplicates()
    .shape[0]
)


print(
    f"\nUnique parameter profiles: "
    f"{unique_profiles}"
)


if unique_profiles >= len(
    SCENARIOS
):

    print(
        "[PASS] All scenario parameter "
        "profiles are differentiated."
    )

else:

    print(
        "[WARNING] Some scenario profiles "
        "remain identical."
    )


# ============================================================
# STEP 2.5 - RUN SIMULATIONS
# ============================================================

banner(
    "STEP 2.5 - SCENARIO SIMULATION"
)


all_rows = []


for scenario in SCENARIOS:

    params = build_scenario_parameters(
        scenario
    )

    effective_efficiency = (
        calculate_operational_efficiency(
            scenario,
            params
        )
    )

    print(
        f"\nRunning: "
        f"{scenario['name']}"
    )

    print(
        "  Parameters:"
    )

    print(
        f"    Awareness       : "
        f"{params['awareness']:.4f}"
    )

    print(
        f"    Incentive       : "
        f"{params['incentive']:.4f}"
    )

    print(
        f"    Accessibility   : "
        f"{params['accessibility']:.4f}"
    )

    print(
        f"    Convenience     : "
        f"{params['convenience']:.4f}"
    )

    print(
        f"    Trust           : "
        f"{params['trust']:.4f}"
    )

    print(
        f"    Collection Eff. : "
        f"{effective_efficiency:.4f}"
    )

    print(
        f"    Recovery Rate   : "
        f"{params['recovery_rate']:.4f}"
    )

    print(
        f"    Collector Cap.  : "
        f"{params['collector_capacity_period']:.2f} kg/period"
    )

    print(
        f"    Collection Cost : "
        f"USD {COLLECTION_COST_PER_KG:.4f}/kg"
    )

    print(
        f"    Processing Cost : "
        f"USD {PROCESSING_COST_PER_KG:.4f}/kg"
    )

    for replicate in range(
        1,
        NUM_REPLICATES + 1
    ):

        # CRITICAL:
        # Same seed policy structure across scenarios,
        # but scenario parameter changes affect behavior.
        seed = (
            RANDOM_SEED
            + replicate
        )

        result = run_simulation(

            scenario=scenario,

            replicate=replicate,

            random_seed=seed,
        )

        all_rows.extend(
            result
        )

    print(
        f"[PASS] "
        f"{NUM_REPLICATES} replicates completed."
    )


raw_df = pd.DataFrame(
    all_rows
)


# ============================================================
# STEP 2.6 - MASS BALANCE VALIDATION
# ============================================================

banner(
    "STEP 2.6 - MASS-BALANCE VALIDATION"
)


# Validate each conservation layer independently.
# This prevents a generation-only check from hiding errors
# in collection, processing, recycling, or inventory flows.

mass_balance_failures = int(
    (raw_df["Mass Balance"] != "PASS").sum()
)


mass_balance_columns = [
    "Source Mass Balance Difference (kg)",
    "Collection Mass Balance Difference (kg)",
    "Processing Mass Balance Difference (kg)",
    "Recycling Mass Balance Difference (kg)",
    "Overall Mass Balance Difference (kg)",
]


mass_balance_audit_rows = []

for column in mass_balance_columns:

    maximum_error = (
        pd.to_numeric(raw_df[column], errors="coerce")
        .abs()
        .max()
    )

    passed = bool(
        pd.notna(maximum_error)
        and maximum_error <= 1e-8
    )

    mass_balance_audit_rows.append({
        "Check": column,
        "Maximum Absolute Error (kg)": maximum_error,
        "Tolerance (kg)": 1e-8,
        "Status": "PASS" if passed else "FAIL",
    })

    print(
        f"[{"PASS" if passed else "FAIL"}] "
        f"{column:<48} | "
        f"max error={maximum_error:.12f} kg"
    )


mass_balance_audit_df = pd.DataFrame(
    mass_balance_audit_rows
)

maximum_mass_balance_error = (
    mass_balance_audit_df[
        "Maximum Absolute Error (kg)"
    ].max()
)


if mass_balance_failures == 0:

    print(
        "[PASS] All simulated periods passed "
        "full mass-balance validation."
    )

else:

    print(
        f"[FAIL] {mass_balance_failures} simulated "
        f"periods failed mass balance."
    )


# ============================================================
# STEP 2.7 - SCENARIO SUMMARY
# ============================================================


banner(
    "STEP 2.7 - SCENARIO SUMMARY"
)


summary_columns = [

    "Generated E-waste (kg)",

    "Formal E-waste (kg)",

    "Informal E-waste (kg)",

    "Collected (kg)",

    "Collection Uncollected (kg)",

    "Processed (kg)",

    "Recovered Material (kg)",

    "Residual Waste (kg)",

    "Processing Residual Waste (kg)",

    "Unprocessed Waste (kg)",

    "Opening Inventory (kg)",

    "Ending Inventory (kg)",

    "Collection Rate (%)",

    "Recovery Rate (%)",

    "Formal Participation (%)",

    "Collection Capacity Utilization (%)",

    "Processing Capacity Utilization (%)",

    "Collection Cost (USD)",

    "Processing Cost (USD)",

    "System Cost (USD)",
]


summary_rows = []


for scenario in SCENARIOS:

    subset = raw_df[
        raw_df["Scenario ID"]
        ==
        scenario["id"]
    ]

    row = {

        "Scenario ID":
            scenario["id"],

        "Scenario":
            scenario["name"],
    }

    for column in summary_columns:

        row[
            f"{column} Mean"
        ] = subset[column].mean()

        row[
            f"{column} SD"
        ] = subset[column].std(
            ddof=1
        )

        row[
            f"{column} Min"
        ] = subset[column].min()

        row[
            f"{column} Max"
        ] = subset[column].max()

    summary_rows.append(
        row
    )


summary_df = pd.DataFrame(
    summary_rows
)


print(
    summary_df[
        [
            "Scenario",

            "Formal Participation (%) Mean",

            "Collection Rate (%) Mean",

            "Recovery Rate (%) Mean",

            "Collected (kg) Mean",

            "Recovered Material (kg) Mean",

            "Residual Waste (kg) Mean",

            "Ending Inventory (kg) Mean",

            "Collection Cost (USD) Mean",

            "Processing Cost (USD) Mean",

            "System Cost (USD) Mean",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# STEP 2.8 - PERIOD SUMMARY
# ============================================================

banner(
    "STEP 2.8 - PERIOD SUMMARY"
)


period_group_columns = [

    "Scenario ID",

    "Scenario",

    "Period",
]


period_summary_df = (

    raw_df

    .groupby(
        period_group_columns
    )[

        summary_columns

    ]

    .mean()

    .reset_index()
)

print(
    "\nPeriod summary generated: "
    f"{len(period_summary_df)} scenario-period rows."
)

print(
    period_summary_df[
        [
            "Scenario ID",
            "Scenario",
            "Period",
            "Generated E-waste (kg)",
            "Formal E-waste (kg)",
            "Collected (kg)",
            "Processed (kg)",
            "Recovered Material (kg)",
            "Residual Waste (kg)",
            "Ending Inventory (kg)",
            "Collection Rate (%)",
            "Recovery Rate (%)",
        ]
    ].to_string(index=False)
)


# ============================================================
# STEP 2.9 - SCENARIO DIFFERENTIATION CHECK
# ============================================================

banner(
    "STEP 2.9 - SCENARIO DIFFERENTIATION"
)


diagnostic_rows = []


diagnostic_columns = [

    "Generated E-waste (kg)",

    "Formal E-waste (kg)",

    "Informal E-waste (kg)",

    "Collected (kg)",

    "Collection Uncollected (kg)",

    "Processed (kg)",

    "Recovered Material (kg)",

    "Residual Waste (kg)",

    "Processing Residual Waste (kg)",

    "Unprocessed Waste (kg)",

    "Ending Inventory (kg)",

    "Collection Rate (%)",

    "Recovery Rate (%)",

    "Formal Participation (%)",

    "Collection Cost (USD)",

    "Processing Cost (USD)",

    "System Cost (USD)",
]


for column in diagnostic_columns:

    grouped = (
        raw_df
        .groupby(
            "Scenario"
        )[column]
        .mean()
    )

    min_value = grouped.min()

    max_value = grouped.max()

    value_range = (
        max_value
        - min_value
    )

    identical = (
        abs(value_range)
        <= 1e-10
    )

    diagnostic_rows.append({

        "Metric":
            column,

        "Minimum Scenario Mean":
            min_value,

        "Maximum Scenario Mean":
            max_value,

        "Scenario Mean Range":
            value_range,

        "All Scenario Means Identical":
            identical,
    })


differentiation_df = pd.DataFrame(
    diagnostic_rows
)


print(
    differentiation_df.to_string(
        index=False
    )
)


metrics_differentiated = int(
    (
        ~differentiation_df[
            "All Scenario Means Identical"
        ]
    ).sum()
)


print(
    f"\nMetrics differentiated: "
    f"{metrics_differentiated}/"
    f"{len(diagnostic_columns)}"
)


# ============================================================
# STEP 2.10 - BASELINE VS COMBINED
# ============================================================

banner(
    "STEP 2.10 - BASELINE VS COMBINED"
)


baseline_id = 0
combined_id = 5


baseline_row = summary_df[
    summary_df["Scenario ID"]
    == baseline_id
].iloc[0]


combined_row = summary_df[
    summary_df["Scenario ID"]
    == combined_id
].iloc[0]


comparison_rows = []


for column in diagnostic_columns:

    baseline_value = baseline_row[
        f"{column} Mean"
    ]

    combined_value = combined_row[
        f"{column} Mean"
    ]

    difference = (
        combined_value
        - baseline_value
    )

    if abs(baseline_value) > 1e-12:

        percent_change = (
            difference
            /
            baseline_value
            * 100.0
        )

    else:

        percent_change = 0.0

    comparison_rows.append({

        "Metric":
            column,

        "Baseline Mean":
            baseline_value,

        "Combined Mean":
            combined_value,

        "Difference":
            difference,

        "Percent Change":
            percent_change,
    })


baseline_combined_df = pd.DataFrame(
    comparison_rows
)


print(
    baseline_combined_df.to_string(
        index=False
    )
)


# ============================================================
# STEP 2.11 - COLLECTION DIAGNOSTIC
# ============================================================

banner(
    "STEP 2.11 - COLLECTION MECHANISM DIAGNOSTIC"
)


collection_diag_rows = []


for scenario in SCENARIOS:

    subset = raw_df[
        raw_df["Scenario ID"]
        ==
        scenario["id"]
    ]

    params = build_scenario_parameters(
        scenario
    )

    expected_capacity = (
        params[
            "collector_capacity_period"
        ]
    )

    actual_collected = (
        subset[
            "Collected (kg)"
        ]
        .mean()
    )

    actual_formal = (
        subset[
            "Formal E-waste (kg)"
        ]
        .mean()
    )

    actual_uncollected = (
        subset[
            "Collection Uncollected (kg)"
        ]
        .mean()
    )

    actual_rate = (
        subset[
            "Collection Rate (%)"
        ]
        .mean()
    )

    capacity_utilization = (
        subset[
            "Collection Capacity Utilization (%)"
        ]
        .mean()
    )

    effective_efficiency = (
        subset[
            "Effective Collection Efficiency"
        ]
        .mean()
    )

    theoretical_efficiency_flow = (
        actual_formal
        * effective_efficiency
    )

    collection_mechanism_error = (
        actual_collected
        -
        min(
            theoretical_efficiency_flow,
            expected_capacity
        )
    )

    collection_diag_rows.append({

        "Scenario ID":
            scenario["id"],

        "Scenario":
            scenario["name"],

        "Formal E-waste Mean (kg)":
            actual_formal,

        "Effective Collection Efficiency":
            effective_efficiency,

        "Theoretical Collection Before Capacity (kg)":
            theoretical_efficiency_flow,

        "Collector Capacity (kg/period)":
            expected_capacity,

        "Collected Mean (kg)":
            actual_collected,

        "Uncollected Mean (kg)":
            actual_uncollected,

        "Collection Rate Mean (%)":
            actual_rate,

        "Capacity Utilization Mean (%)":
            capacity_utilization,

        "Collection Mechanism Error (kg)":
            collection_mechanism_error,
    })


collection_diagnostic_df = pd.DataFrame(
    collection_diag_rows
)


print(
    collection_diagnostic_df.to_string(
        index=False
    )
)


max_collection_error = (
    collection_diagnostic_df[
        "Collection Mechanism Error (kg)"
    ]
    .abs()
    .max()
)


if max_collection_error <= 1e-8:

    print(
        "\n[PASS] Collection mechanism "
        "is internally consistent."
    )

else:

    print(
        "\n[WARNING] Collection mechanism "
        "requires review."
    )


# ============================================================
# STEP 2.12 - COST DIAGNOSTIC
# ============================================================

banner(
    "STEP 2.12 - COST DIAGNOSTIC"
)


cost_diag_rows = []


for scenario in SCENARIOS:

    subset = raw_df[
        raw_df["Scenario ID"]
        ==
        scenario["id"]
    ]

    collected_mean = (
        subset[
            "Collected (kg)"
        ]
        .mean()
    )

    processed_mean = (
        subset[
            "Processed (kg)"
        ]
        .mean()
    )

    collection_cost_mean = (
        subset[
            "Collection Cost (USD)"
        ]
        .mean()
    )

    processing_cost_mean = (
        subset[
            "Processing Cost (USD)"
        ]
        .mean()
    )

    system_cost_mean = (
        subset[
            "System Cost (USD)"
        ]
        .mean()
    )

    expected_collection_cost = (
        collected_mean
        * COLLECTION_COST_PER_KG
    )

    expected_processing_cost = (
        processed_mean
        * PROCESSING_COST_PER_KG
    )

    expected_system_cost = (
        expected_collection_cost
        + expected_processing_cost
    )

    collection_error = (
        collection_cost_mean
        -
        expected_collection_cost
    )

    processing_error = (
        processing_cost_mean
        -
        expected_processing_cost
    )

    system_error = (
        system_cost_mean
        -
        expected_system_cost
    )

    cost_diag_rows.append({

        "Scenario ID":
            scenario["id"],

        "Scenario":
            scenario["name"],

        "Collected Mean (kg)":
            collected_mean,

        "Processed Mean (kg)":
            processed_mean,

        "Collection Cost Mean (USD)":
            collection_cost_mean,

        "Expected Collection Cost (USD)":
            expected_collection_cost,

        "Processing Cost Mean (USD)":
            processing_cost_mean,

        "Expected Processing Cost (USD)":
            expected_processing_cost,

        "System Cost Mean (USD)":
            system_cost_mean,

        "Expected System Cost (USD)":
            expected_system_cost,

        "Collection Cost Error (USD)":
            collection_error,

        "Processing Cost Error (USD)":
            processing_error,

        "System Cost Error (USD)":
            system_error,
    })


cost_diagnostic_df = pd.DataFrame(
    cost_diag_rows
)


print(
    cost_diagnostic_df.to_string(
        index=False
    )
)


max_cost_error = max(

    cost_diagnostic_df[
        "Collection Cost Error (USD)"
    ]
    .abs()
    .max(),

    cost_diagnostic_df[
        "Processing Cost Error (USD)"
    ]
    .abs()
    .max(),

    cost_diagnostic_df[
        "System Cost Error (USD)"
    ]
    .abs()
    .max(),
)


if max_cost_error <= 1e-8:

    print(
        "\n[PASS] Cost calculation "
        "is internally consistent."
    )

else:

    print(
        "\n[WARNING] Cost calculation "
        "requires review."
    )


# ============================================================
# STEP 2.13 - SCENARIO DIFFERENTIATION STATUS
# ============================================================

banner(
    "STEP 2.13 - FINAL SCENARIO VALIDATION"
)


expected_rows = (
    len(SCENARIOS)
    * NUM_REPLICATES
    * NUM_PERIODS
)

row_count_pass = (
    len(raw_df) == expected_rows
)

parameter_profiles_pass = (
    unique_profiles
    >=
    len(SCENARIOS)
)


collection_pass = (
    max_collection_error
    <=
    1e-8
)


cost_pass = (
    max_cost_error
    <=
    1e-8
)


mass_balance_pass = (
    mass_balance_failures == 0
    and bool(
        (
            mass_balance_audit_df["Status"]
            == "PASS"
        ).all()
    )
)


# Cost should vary when actual collected/processed
# mass differs between scenarios.

system_cost_mean_column = None

for candidate in [
    "System Cost Mean",
    "System Cost Mean (USD)",
]:
    if candidate in cost_diagnostic_df.columns:
        system_cost_mean_column = candidate
        break

if system_cost_mean_column is None:
    raise KeyError(
        "STEP 2.13 could not find the system-cost mean column. "
        f"Available columns: {list(cost_diagnostic_df.columns)}"
    )

cost_variation = (
    pd.to_numeric(
        cost_diagnostic_df[system_cost_mean_column],
        errors="coerce",
    ).max()
    -
    pd.to_numeric(
        cost_diagnostic_df[system_cost_mean_column],
        errors="coerce",
    ).min()
)


cost_varies = (
    abs(cost_variation)
    > 1e-10
)


# Collection should vary across scenarios
collection_variation = (
    raw_df
    .groupby("Scenario")[
        "Collected (kg)"
    ]
    .mean()
    .max()
    -
    raw_df
    .groupby("Scenario")[
        "Collected (kg)"
    ]
    .mean()
    .min()
)


collection_varies = (
    abs(collection_variation)
    > 1e-10
)


print(
    f"Row count                  : "
    f"{'PASS' if row_count_pass else 'FAIL'}"
)

print(
    f"Parameter differentiation : "
    f"{'PASS' if parameter_profiles_pass else 'REVIEW'}"
)

print(
    f"Mass balance               : "
    f"{'PASS' if mass_balance_pass else 'FAIL'}"
)

print(
    f"Collection mechanism       : "
    f"{'PASS' if collection_pass else 'REVIEW'}"
)

print(
    f"Collection varies          : "
    f"{'PASS' if collection_varies else 'REVIEW'}"
)

print(
    f"Cost calculation           : "
    f"{'PASS' if cost_pass else 'REVIEW'}"
)

print(
    f"System cost varies         : "
    f"{'PASS' if cost_varies else 'REVIEW'}"
)


# ============================================================
# EXPORT
# ============================================================

banner(
    "STEP 2.14 - EXPORT"
)


raw_output = (
    OUTPUT_DIR
    /
    "STEP02_RAW_SIMULATION_RESULTS.csv"
)


summary_output = (
    OUTPUT_DIR
    /
    "STEP02_SCENARIO_SUMMARY.csv"
)


period_output = (
    OUTPUT_DIR
    /
    "STEP02_PERIOD_RESULTS.csv"
)


scenario_output = (
    OUTPUT_DIR
    /
    "STEP02_SCENARIO_PARAMETERS.csv"
)


differentiation_output = (
    OUTPUT_DIR
    /
    "STEP02_SCENARIO_DIFFERENTIATION_DIAGNOSTIC.csv"
)


baseline_combined_output = (
    OUTPUT_DIR
    /
    "STEP02_BASELINE_VS_COMBINED.csv"
)


collection_diagnostic_output = (
    OUTPUT_DIR
    /
    "STEP02_COLLECTION_DIAGNOSTIC.csv"
)


cost_diagnostic_output = (
    OUTPUT_DIR
    /
    "STEP02_COST_DIAGNOSTIC.csv"
)


mass_balance_audit_output = (
    OUTPUT_DIR
    /
    "STEP02_MASS_BALANCE_AUDIT.csv"
)


report_output = (
    OUTPUT_DIR
    /
    "STEP02_SIMULATION_REPORT.txt"
)


raw_df.to_csv(
    raw_output,
    index=False,
    encoding="utf-8-sig"
)


summary_df.to_csv(
    summary_output,
    index=False,
    encoding="utf-8-sig"
)


period_summary_df.to_csv(
    period_output,
    index=False,
    encoding="utf-8-sig"
)


scenario_parameter_df.to_csv(
    scenario_output,
    index=False,
    encoding="utf-8-sig"
)


differentiation_df.to_csv(
    differentiation_output,
    index=False,
    encoding="utf-8-sig"
)


baseline_combined_df.to_csv(
    baseline_combined_output,
    index=False,
    encoding="utf-8-sig"
)


collection_diagnostic_df.to_csv(
    collection_diagnostic_output,
    index=False,
    encoding="utf-8-sig"
)


cost_diagnostic_df.to_csv(
    cost_diagnostic_output,
    index=False,
    encoding="utf-8-sig"
)


mass_balance_audit_df.to_csv(
    mass_balance_audit_output,
    index=False,
    encoding="utf-8-sig"
)


# ============================================================
# REPORT
# ============================================================

with open(
    report_output,
    "w",
    encoding="utf-8"
) as f:

    f.write(
        "E-WASTE ABM\n"
    )

    f.write(
        "STEP 2: MODEL IMPLEMENTATION "
        "& SCENARIO SIMULATION\n"
    )

    f.write(
        "FINAL REVISION BEFORE STEP 3\n"
    )

    f.write(
        "=" * 100
        + "\n\n"
    )

    f.write(
        f"Project root: "
        f"{PROJECT_ROOT}\n"
    )

    f.write(
        f"Consumers: "
        f"{NUM_CONSUMERS}\n"
    )

    f.write(
        f"Collectors: "
        f"{NUM_COLLECTORS}\n"
    )

    f.write(
        f"Recyclers: "
        f"{NUM_RECYCLERS}\n"
    )

    f.write(
        f"Periods: "
        f"{NUM_PERIODS}\n"
    )

    f.write(
        f"Replicates: "
        f"{NUM_REPLICATES}\n"
    )

    f.write(
        f"Base random seed: "
        f"{RANDOM_SEED}\n"
    )

    f.write(
        f"E-waste generation: "
        f"{EWASTE_PER_CONSUMER_YEAR:.4f} "
        f"kg/consumer/year\n"
    )

    f.write(
        f"E-waste per period: "
        f"{EWASTE_PER_CONSUMER_PERIOD:.4f} "
        f"kg/consumer/period\n"
    )

    f.write(
        f"Collector capacity: "
        f"{COLLECTOR_CAPACITY_PER_DAY:.4f} "
        f"kg/collector/day\n"
    )

    f.write(
        f"Collector capacity period: "
        f"{COLLECTOR_CAPACITY_PER_PERIOD:.4f} "
        f"kg/collector/period\n"
    )

    f.write(
        f"Collection cost: "
        f"USD {COLLECTION_COST_PER_KG:.4f}/kg\n"
    )

    f.write(
        f"Processing cost: "
        f"USD {PROCESSING_COST_PER_KG:.4f}/kg\n\n"
    )

    # --------------------------------------------------------
    # Scenarios
    # --------------------------------------------------------

    f.write(
        "SCENARIOS\n"
    )

    f.write(
        "-" * 100
        + "\n"
    )

    for scenario in SCENARIOS:

        f.write(
            f"{scenario['id']}. "
            f"{scenario['name']}\n"
        )

    f.write("\n")

    # --------------------------------------------------------
    # Validation
    # --------------------------------------------------------

    f.write(
        "VALIDATION\n"
    )

    f.write(
        "-" * 100
        + "\n"
    )

    f.write(
        f"Total simulation rows: "
        f"{len(raw_df)}\n"
    )

    f.write(
        f"Expected simulation rows: "
        f"{len(SCENARIOS) * NUM_REPLICATES * NUM_PERIODS}\n"
    )

    f.write(
        f"Row-count validation: "
        f"{'PASS' if row_count_pass else 'FAIL'}\n"
    )

    f.write(
        f"Mass-balance failures: "
        f"{mass_balance_failures}\n"
    )

    f.write(
        f"Maximum mass-balance error: "
        f"{maximum_mass_balance_error:.12f} kg\n"
    )

    f.write(
        f"Mass-balance checks passed: "
        f"{int((mass_balance_audit_df['Status'] == 'PASS').sum())}/"
        f"{len(mass_balance_audit_df)}\n"
    )

    f.write(
        f"Unique scenario parameter profiles: "
        f"{unique_profiles}\n"
    )

    f.write(
        f"Collection mechanism error: "
        f"{max_collection_error:.12f} kg\n"
    )

    f.write(
        f"Maximum cost calculation error: "
        f"{max_cost_error:.12f} USD\n"
    )

    f.write(
        f"Collection variation: "
        f"{collection_variation:.8f} kg\n"
    )

    f.write(
        f"System cost variation: "
        f"{cost_variation:.8f} USD\n\n"
    )

    # --------------------------------------------------------
    # Status
    # --------------------------------------------------------

    overall_pass = (

        row_count_pass

        and parameter_profiles_pass

        and mass_balance_pass

        and collection_pass

        and collection_varies

        and cost_pass

        and cost_varies
    )

    f.write(
        "OVERALL STATUS: "
        +
        (
            "PASS - READY FOR STEP 3"
            if overall_pass
            else "NOT READY - REVIEW REQUIRED"
        )
        +
        "\n\n"
    )

    # --------------------------------------------------------
    # Summary
    # --------------------------------------------------------

    f.write(
        "SCENARIO SUMMARY\n"
    )

    f.write(
        "-" * 100
        + "\n"
    )

    for _, row in summary_df.iterrows():

        f.write(
            f"\n{row['Scenario']}\n"
        )

        f.write(
            f"  Generated            : "
            f"{row['Generated E-waste (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Formal e-waste       : "
            f"{row['Formal E-waste (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Informal e-waste     : "
            f"{row['Informal E-waste (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Collected            : "
            f"{row['Collected (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Processed            : "
            f"{row['Processed (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Recovered            : "
            f"{row['Recovered Material (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Residual             : "
            f"{row['Residual Waste (kg) Mean']:.6f} kg\n"
        )

        f.write(
            f"  Collection rate      : "
            f"{row['Collection Rate (%) Mean']:.6f}%\n"
        )

        f.write(
            f"  Recovery rate        : "
            f"{row['Recovery Rate (%) Mean']:.6f}%\n"
        )

        f.write(
            f"  Formal participation : "
            f"{row['Formal Participation (%) Mean']:.6f}%\n"
        )

        f.write(
            f"  Collection cost      : "
            f"USD {row['Collection Cost (USD) Mean']:.6f}\n"
        )

        f.write(
            f"  Processing cost      : "
            f"USD {row['Processing Cost (USD) Mean']:.6f}\n"
        )

        f.write(
            f"  System cost          : "
            f"USD {row['System Cost (USD) Mean']:.6f}\n"
        )


# ============================================================
# FINAL CONSOLE SUMMARY
# ============================================================

banner(
    "STEP 2 FINAL SUMMARY"
)


expected_rows = (
    len(SCENARIOS)
    *
    NUM_REPLICATES
    *
    NUM_PERIODS
)


print(
    f"Total raw rows            : "
    f"{len(raw_df)}"
)

print(
    f"Expected raw rows         : "
    f"{expected_rows}"
)

print(
    f"Scenarios                 : "
    f"{len(SCENARIOS)}"
)

print(
    f"Replicates/scenario       : "
    f"{NUM_REPLICATES}"
)

print(
    f"Periods/replicate         : "
    f"{NUM_PERIODS}"
)

print(
    f"Mass-balance failures     : "
    f"{mass_balance_failures}"
)

print(
    f"Unique parameter profiles : "
    f"{unique_profiles}"
)

print(
    f"Collection variation      : "
    f"{collection_variation:.6f} kg"
)

print(
    f"System cost variation     : "
    f"{cost_variation:.6f} USD"
)


print(
    "\nVALIDATION STATUS"
)

print(
    f"  Row count          : "
    f"{'PASS' if row_count_pass else 'FAIL'}"
)

print(
    f"  Parameter profiles : "
    f"{'PASS' if parameter_profiles_pass else 'REVIEW'}"
)

print(
    f"  Mass balance       : "
    f"{'PASS' if mass_balance_pass else 'FAIL'}"
)

print(
    f"  Collection logic   : "
    f"{'PASS' if collection_pass else 'REVIEW'}"
)

print(
    f"  Collection varies  : "
    f"{'PASS' if collection_varies else 'REVIEW'}"
)

print(
    f"  Cost calculation   : "
    f"{'PASS' if cost_pass else 'REVIEW'}"
)

print(
    f"  Cost varies        : "
    f"{'PASS' if cost_varies else 'REVIEW'}"
)


print(
    f"\n[SAVED] {raw_output}"
)

print(
    f"[SAVED] {summary_output}"
)

print(
    f"[SAVED] {period_output}"
)

print(
    f"[SAVED] {scenario_output}"
)

print(
    f"[SAVED] {differentiation_output}"
)

print(
    f"[SAVED] {baseline_combined_output}"
)

print(
    f"[SAVED] {collection_diagnostic_output}"
)

print(
    f"[SAVED] {cost_diagnostic_output}"
)

print(
    f"[SAVED] {mass_balance_audit_output}"
)

print(
    f"[SAVED] {report_output}"
)


if overall_pass:

    final_status = "PASS - READY FOR STEP 3"

else:

    final_status = "NOT READY - REVIEW REQUIRED"


print(
    f"\nFINAL STATUS: {final_status}"
)


if overall_pass:

    print(
        "MODEL SIMULATION : PASS"
    )

else:

    print(
        "MODEL SIMULATION : REVIEW REQUIRED"
    )


banner(
    "STEP 2 COMPLETE - FINAL REVISION"
)