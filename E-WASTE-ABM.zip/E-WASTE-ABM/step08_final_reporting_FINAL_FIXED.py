# -*- coding: utf-8 -*-
r"""
E-WASTE ABM
STEP 8: FINAL REPORTING, PUBLICATION PACKAGE & EVIDENCE READINESS
FINAL COMPATIBLE VERSION

Compatible with the completed STEP 0-7 outputs.

Expected project structure:
D:/E-WASTE-ABM/
    results_step00\
    results_step01\
    results_step02\
    results_step04\
    results_step05\
    results_step06\
    results_step07\

Main purpose:
1. Load and audit the consolidated STEP 7 outputs.
2. Build publication-ready scenario, sensitivity, validation and evidence tables.
3. Generate publication-ready figures.
4. Create a manuscript/evidence mapping table.
5. Create a final publication package workbook.
6. Run final consistency/readiness checks.
7. Produce STEP08_FINAL_REPORT.txt.
"""

from pathlib import Path
import json
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_ROOT / "results_step08"
TABLE_DIR = OUTPUT_DIR / "tables"
FIGURE_DIR = OUTPUT_DIR / "figures"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
FIGURE_DIR.mkdir(parents=True, exist_ok=True)

STEP07 = PROJECT_ROOT / "results_step07"
STEP06 = PROJECT_ROOT / "results_step06"
STEP05 = PROJECT_ROOT / "results_step05"
STEP04 = PROJECT_ROOT / "results_step04"
STEP02 = PROJECT_ROOT / "results_step02"
STEP01 = PROJECT_ROOT / "results_step01"
STEP00 = PROJECT_ROOT / "results_step00"

SCENARIOS = [
    "Baseline",
    "Scenario 1 - Formal-Informal Integration",
    "Scenario 2 - Economic Incentives",
    "Scenario 3 - Information & Traceability",
    "Scenario 4 - Producer Responsibility",
    "Scenario 5 - Combined Orchestration",
]

EXPECTED_SCENARIO_COUNT = 6
EXPECTED_REPLICATES = 30
EXPECTED_PERIODS = 12
EXPECTED_SENSITIVITY_PARAMETERS = 7

MASTER_FILE = STEP07 / "STEP07_MASTER_DATASET.csv"
REPLICATE_MASTER_FILE = STEP07 / "STEP07_REPLICATE_LEVEL_MASTER.csv"

SCENARIO_FILE = STEP07 / "tables" / "03_scenario_consolidation.csv"
BASELINE_FILE = STEP07 / "tables" / "04_baseline_vs_interventions.csv"
STAT_FILE = STEP07 / "tables" / "05_statistical_evidence.csv"
SENS_FILE = STEP07 / "tables" / "06_sensitivity_evidence.csv"
VALID_FILE = STEP07 / "tables" / "07_validation_evidence.csv"
PUB_FILE = STEP07 / "tables" / "08_publication_summary.csv"
MASTER_META_FILE = STEP07 / "tables" / "09_master_dataset_metadata.csv"
FINAL_VALID_FILE = STEP07 / "tables" / "10_final_consolidation_validation.csv"

STEP06_REPORT = STEP06 / "STEP06_MODEL_VALIDATION_REPORT.txt"
STEP07_REPORT = STEP07 / "STEP07_OUTPUT_CONSOLIDATION_REPORT.txt"

STEP04_FILES = {
    "replication_validation": STEP04 / "tables" / "01_replication_validation.csv",
    "replicate_level": STEP04 / "tables" / "02_replicate_level_data.csv",
    "descriptive_statistics": STEP04 / "tables" / "03_replicate_descriptive_statistics.csv",
    "assumption_diagnostics": STEP04 / "tables" / "04_assumption_diagnostics.csv",
    "omnibus_tests": STEP04 / "tables" / "05_omnibus_tests.csv",
    "tukey": STEP04 / "tables" / "06_tukey_hsd_posthoc.csv",
    "mannwhitney": STEP04 / "tables" / "07_mannwhitney_holm_posthoc.csv",
    "baseline_comparisons": STEP04 / "tables" / "08_baseline_vs_scenarios.csv",
    "effect_sizes": STEP04 / "tables" / "09_effect_size_summary.csv",
    "conclusions": STEP04 / "tables" / "10_statistical_conclusions.csv",
}

# ============================================================
# HELPERS
# ============================================================

validation_rows = []
input_rows = []


def banner(text):
    print("\n" + "=" * 100)
    print(text)
    print("=" * 100)


def section(text):
    print("\n" + "-" * 100)
    print(text)
    print("-" * 100)


def pass_msg(label, details):
    print(f"[PASS] {label:<45} | {details}")
    validation_rows.append({
        "Check": label,
        "Status": "PASS",
        "Details": details
    })


def fail_msg(label, details):
    print(f"[FAIL] {label:<45} | {details}")
    validation_rows.append({
        "Check": label,
        "Status": "FAIL",
        "Details": details
    })


def save_csv(df, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")
    print(f"[SAVED] {path}")


def read_csv(path, required=True):
    if not path.exists():
        if required:
            raise FileNotFoundError(str(path))
        return None
    return pd.read_csv(path)


def first_existing_column(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def numeric_series(df, col):
    return pd.to_numeric(df[col], errors="coerce")


def finite_numeric_columns(df):
    bad = []
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            vals = pd.to_numeric(df[col], errors="coerce")
            if not np.isfinite(vals.to_numpy(dtype=float)).all():
                bad.append(col)
    return bad


def safe_mean(series):
    x = pd.to_numeric(series, errors="coerce").dropna()
    return float(x.mean()) if len(x) else np.nan


def safe_std(series):
    x = pd.to_numeric(series, errors="coerce").dropna()
    return float(x.std(ddof=1)) if len(x) > 1 else 0.0


def safe_median(series):
    x = pd.to_numeric(series, errors="coerce").dropna()
    return float(x.median()) if len(x) else np.nan


def scenario_name_col(df):
    return first_existing_column(df, ["Scenario", "Scenario Label", "Scenario Name"])


def recovered_col(df):
    return first_existing_column(
        df,
        ["Recovered Material (kg)", "Recovered Material", "Recovered (kg)"]
    )


def collected_col(df):
    return first_existing_column(
        df,
        ["Collected (kg)", "Collected E-waste (kg)", "Formal E-waste (kg)"]
    )


def cost_col(df):
    return first_existing_column(
        df,
        ["System Cost (USD)", "System Cost (Rp)", "System Cost"]
    )


def collection_rate_col(df):
    return first_existing_column(df, ["Collection Rate (%)", "Collection Rate"])


def participation_col(df):
    return first_existing_column(
        df,
        ["Formal Participation (%)", "Formal Participation"]
    )


def recovery_rate_col(df):
    return first_existing_column(
        df,
        ["Recovery Rate (%)", "Recovery Rate"]
    )


def generated_col(df):
    return first_existing_column(
        df,
        ["Generated E-waste (kg)", "Generated E-waste", "E-waste Generated (kg)"]
    )


def residual_col(df):
    return first_existing_column(
        df,
        ["Residual Waste (kg)", "Residual Waste"]
    )


def get_scenario_summary(master):
    s_col = scenario_name_col(master)
    r_col = recovered_col(master)
    c_col = collected_col(master)
    cost = cost_col(master)
    cr = collection_rate_col(master)
    fp = participation_col(master)
    rr = recovery_rate_col(master)
    gen = generated_col(master)
    residual = residual_col(master)

    rows = []
    for scenario in SCENARIOS:
        sub = master[master[s_col] == scenario].copy()
        row = {
            "Scenario ID": SCENARIOS.index(scenario),
            "Scenario": scenario,
            "Replicates": sub["Replicate"].nunique() if "Replicate" in sub else np.nan,
            "Periods": sub["Period"].nunique() if "Period" in sub else np.nan,
            "Recovered Material Mean (kg)": safe_mean(sub[r_col]),
            "Recovered Material SD (kg)": safe_std(sub[r_col]),
            "Collected Mean (kg)": safe_mean(sub[c_col]) if c_col else np.nan,
            "Generated E-waste Mean (kg)": safe_mean(sub[gen]) if gen else np.nan,
            "Collection Rate Mean (%)": safe_mean(sub[cr]) if cr else np.nan,
            "Recovery Rate Mean (%)": safe_mean(sub[rr]) if rr else np.nan,
            "Formal Participation Mean (%)": safe_mean(sub[fp]) if fp else np.nan,
            "Residual Waste Mean (kg)": safe_mean(sub[residual]) if residual else np.nan,
            "System Cost Mean (USD)": safe_mean(sub[cost]) if cost else np.nan,
            "System Cost SD (USD)": safe_std(sub[cost]) if cost else np.nan,
        }
        rows.append(row)

    out = pd.DataFrame(rows)

    base = out.loc[out["Scenario"] == "Baseline"]
    if not base.empty:
        base_recovered = float(base["Recovered Material Mean (kg)"].iloc[0])
        base_cost = float(base["System Cost Mean (USD)"].iloc[0])

        out["Recovered Improvement vs Baseline (%)"] = (
            (out["Recovered Material Mean (kg)"] - base_recovered)
            / base_recovered * 100
            if base_recovered else np.nan
        )
        out["System Cost Change vs Baseline (%)"] = (
            (out["System Cost Mean (USD)"] - base_cost)
            / base_cost * 100
            if base_cost else np.nan
        )
    else:
        out["Recovered Improvement vs Baseline (%)"] = np.nan
        out["System Cost Change vs Baseline (%)"] = np.nan

    return out


def make_replicate_summary(master):
    s_col = scenario_name_col(master)
    r_col = recovered_col(master)
    c_col = collected_col(master)
    cost = cost_col(master)
    cr = collection_rate_col(master)
    fp = participation_col(master)
    rr = recovery_rate_col(master)
    residual = residual_col(master)

    group_cols = [s_col, "Replicate"]

    agg = {
        r_col: ["mean", "sum"],
    }

    if c_col:
        agg[c_col] = ["mean", "sum"]
    if cr:
        agg[cr] = "mean"
    if rr:
        agg[rr] = "mean"
    if fp:
        agg[fp] = "mean"
    if residual:
        agg[residual] = "mean"
    if cost:
        agg[cost] = ["mean", "sum"]

    rep = master.groupby(group_cols, as_index=False).agg(agg)

    flat_cols = []
    for c in rep.columns:
        if isinstance(c, tuple):
            if c[1] == "":
                flat_cols.append(c[0])
            else:
                flat_cols.append(f"{c[0]} {c[1]}")
        else:
            flat_cols.append(c)
    rep.columns = flat_cols

    return rep


def write_excel_package(output_path, sheets):
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter

        with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
            for name, df in sheets.items():
                safe_name = str(name)[:31]
                df.to_excel(writer, sheet_name=safe_name, index=False)

        wb = load_workbook(output_path)
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions

            for cell in ws[1]:
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            for col_cells in ws.columns:
                max_len = 0
                for cell in col_cells[:100]:
                    value = "" if cell.value is None else str(cell.value)
                    max_len = max(max_len, len(value))
                width = min(max(max_len + 2, 10), 45)
                ws.column_dimensions[get_column_letter(col_cells[0].column)].width = width

        wb.save(output_path)
        return True
    except Exception as exc:
        print(f"[WARNING] Excel workbook not created: {exc}")
        return False


# ============================================================
# MAIN
# ============================================================

def main():
    banner(
        "E-WASTE ABM\n"
        "STEP 8: FINAL REPORTING, PUBLICATION PACKAGE & EVIDENCE READINESS\n"
        "FINAL COMPATIBLE VERSION"
    )

    print(f"Project root : {PROJECT_ROOT}")
    print(f"Output       : {OUTPUT_DIR}")

    # --------------------------------------------------------
    # STEP 8.1 - UPSTREAM FILE INTEGRITY
    # --------------------------------------------------------
    section("STEP 8.1 - UPSTREAM FILE INTEGRITY")

    required_files = {
        "STEP 7 Master Dataset": MASTER_FILE,
        "STEP 7 Replicate Master": REPLICATE_MASTER_FILE,
        "STEP 7 Scenario Consolidation": SCENARIO_FILE,
        "STEP 7 Baseline vs Interventions": BASELINE_FILE,
        "STEP 7 Statistical Evidence": STAT_FILE,
        "STEP 7 Sensitivity Evidence": SENS_FILE,
        "STEP 7 Validation Evidence": VALID_FILE,
        "STEP 7 Publication Summary": PUB_FILE,
        "STEP 7 Master Metadata": MASTER_META_FILE,
        "STEP 7 Final Validation": FINAL_VALID_FILE,
        "STEP 6 Validation Report": STEP06_REPORT,
        "STEP 7 Consolidation Report": STEP07_REPORT,
    }

    # Include Step 4 files when present; they are useful evidence but
    # the final package remains compatible even if one is absent.
    for label, path in STEP04_FILES.items():
        required_files[f"STEP 4 - {label}"] = path

    for label, path in required_files.items():
        exists = path.exists()
        if exists:
            pass_msg("File integrity", f"{label}: {path}")
        else:
            if label.startswith("STEP 4"):
                print(f"[INFO] Optional evidence file not found | {label}: {path}")
            else:
                fail_msg("File integrity", f"{label}: MISSING -> {path}")

        input_rows.append({
            "File": label,
            "Path": str(path),
            "Exists": exists
        })

    save_csv(pd.DataFrame(input_rows), TABLE_DIR / "00_upstream_file_integrity.csv")

    # Stop only if core Step 7 master is unavailable.
    if not MASTER_FILE.exists():
        raise FileNotFoundError(
            f"STEP 7 master dataset not found: {MASTER_FILE}"
        )

    # --------------------------------------------------------
    # STEP 8.2 - LOAD CORE DATA
    # --------------------------------------------------------
    section("STEP 8.2 - LOADING STEP 7 CONSOLIDATED DATA")

    master = pd.read_csv(MASTER_FILE)
    rep_master = pd.read_csv(REPLICATE_MASTER_FILE) if REPLICATE_MASTER_FILE.exists() else None
    scenario_step7 = pd.read_csv(SCENARIO_FILE) if SCENARIO_FILE.exists() else None
    baseline_step7 = pd.read_csv(BASELINE_FILE) if BASELINE_FILE.exists() else None
    stat_step7 = pd.read_csv(STAT_FILE) if STAT_FILE.exists() else None
    sens_step7 = pd.read_csv(SENS_FILE) if SENS_FILE.exists() else None
    valid_step7 = pd.read_csv(VALID_FILE) if VALID_FILE.exists() else None
    pub_step7 = pd.read_csv(PUB_FILE) if PUB_FILE.exists() else None

    print(f"Master dataset rows : {len(master)}")
    print(f"Master dataset cols : {len(master.columns)}")
    if rep_master is not None:
        print(f"Replicate master rows: {len(rep_master)}")
    if scenario_step7 is not None:
        print(f"Scenario rows       : {len(scenario_step7)}")
    if sens_step7 is not None:
        print(f"Sensitivity rows    : {len(sens_step7)}")
    if valid_step7 is not None:
        print(f"Validation rows     : {len(valid_step7)}")

    # --------------------------------------------------------
    # STEP 8.3 - MASTER DATASET READINESS
    # --------------------------------------------------------
    section("STEP 8.3 - MASTER DATASET READINESS")

    required_master_cols = [
        "Scenario",
        "Replicate",
        "Period",
        "Generated E-waste (kg)",
        "Formal E-waste (kg)",
        "Informal E-waste (kg)",
        "Recovered Material (kg)",
        "Residual Waste (kg)",
        "Collection Rate (%)",
        "Recovery Rate (%)",
        "Formal Participation (%)",
        "Ending Inventory (kg)",
    ]

    missing_master = [c for c in required_master_cols if c not in master.columns]
    duplicate_columns = master.columns[master.columns.duplicated()].tolist()

    if not missing_master:
        pass_msg("Master required columns", f"All {len(required_master_cols)} core columns available")
    else:
        fail_msg("Master required columns", f"Missing={missing_master}")

    if not duplicate_columns:
        pass_msg("Master duplicate columns", "None")
    else:
        fail_msg("Master duplicate columns", f"Duplicates={duplicate_columns}")

    s_col = scenario_name_col(master)
    if s_col is None:
        fail_msg("Scenario identifier", "Scenario column not found")
    else:
        detected_scenarios = list(pd.unique(master[s_col].dropna()))
        missing_scenarios = [x for x in SCENARIOS if x not in detected_scenarios]
        unexpected_scenarios = [x for x in detected_scenarios if x not in SCENARIOS]

        if not missing_scenarios:
            pass_msg("Scenario completeness", "All six expected scenarios detected")
        else:
            fail_msg("Scenario completeness", f"Missing={missing_scenarios}")

        if not unexpected_scenarios:
            pass_msg("Scenario integrity", "No unexpected scenario labels")
        else:
            fail_msg("Scenario integrity", f"Unexpected={unexpected_scenarios}")

    bad_numeric = finite_numeric_columns(master)
    if not bad_numeric:
        pass_msg("Master numeric integrity", "All numeric columns finite")
    else:
        fail_msg("Master numeric integrity", f"Non-finite columns={bad_numeric}")

    save_csv(
        pd.DataFrame(validation_rows[-6:]),
        TABLE_DIR / "01_master_readiness_validation.csv"
    )

    # --------------------------------------------------------
    # STEP 8.4 - FINAL SCENARIO EVIDENCE TABLE
    # --------------------------------------------------------
    section("STEP 8.4 - FINAL SCENARIO EVIDENCE TABLE")

    scenario_final = get_scenario_summary(master)
    save_csv(scenario_final, TABLE_DIR / "02_final_scenario_evidence.csv")

    if len(scenario_final) == EXPECTED_SCENARIO_COUNT:
        pass_msg("Scenario evidence", "6 scenarios summarized")
    else:
        fail_msg("Scenario evidence", f"Expected=6, Detected={len(scenario_final)}")

    # --------------------------------------------------------
    # STEP 8.5 - REPLICATE-LEVEL STATISTICAL EVIDENCE
    # --------------------------------------------------------
    section("STEP 8.5 - REPLICATE-LEVEL STATISTICAL EVIDENCE")

    replicate_final = make_replicate_summary(master)
    save_csv(replicate_final, TABLE_DIR / "03_final_replicate_evidence.csv")

    rep_counts = (
        replicate_final.groupby(scenario_name_col(replicate_final))
        .size()
        .to_dict()
    )

    bad_rep_counts = {
        k: v for k, v in rep_counts.items()
        if v != EXPECTED_REPLICATES
    }

    if len(rep_counts) == EXPECTED_SCENARIO_COUNT and not bad_rep_counts:
        pass_msg(
            "Replicate evidence",
            f"{EXPECTED_SCENARIO_COUNT} scenarios x {EXPECTED_REPLICATES} replicates"
        )
    else:
        fail_msg(
            "Replicate evidence",
            f"Counts={rep_counts}"
        )

    # --------------------------------------------------------
    # STEP 8.6 - BASELINE VS INTERVENTION EVIDENCE
    # --------------------------------------------------------
    section("STEP 8.6 - BASELINE VS INTERVENTION EVIDENCE")

    baseline_evidence = scenario_final.copy()

    base_row = baseline_evidence[
        baseline_evidence["Scenario"] == "Baseline"
    ]

    if not base_row.empty:
        base_rec = float(base_row["Recovered Material Mean (kg)"].iloc[0])
        base_cost = float(base_row["System Cost Mean (USD)"].iloc[0])

        intervention = baseline_evidence[
            baseline_evidence["Scenario"] != "Baseline"
        ].copy()

        intervention["Recovered Difference vs Baseline (kg)"] = (
            intervention["Recovered Material Mean (kg)"] - base_rec
        )

        intervention["Recovered Improvement vs Baseline (%)"] = (
            intervention["Recovered Difference vs Baseline (kg)"]
            / base_rec * 100
            if base_rec != 0 else np.nan
        )

        intervention["System Cost Difference vs Baseline (USD)"] = (
            intervention["System Cost Mean (USD)"] - base_cost
        )

        intervention["System Cost Change vs Baseline (%)"] = (
            intervention["System Cost Difference vs Baseline (USD)"]
            / base_cost * 100
            if base_cost != 0 else np.nan
        )

        save_csv(
            intervention,
            TABLE_DIR / "04_final_baseline_vs_interventions.csv"
        )

        best_recovery = intervention.loc[
            intervention["Recovered Material Mean (kg)"].idxmax()
        ]

        pass_msg(
            "Baseline comparison",
            f"{len(intervention)} intervention scenarios compared with baseline"
        )
    else:
        fail_msg("Baseline comparison", "Baseline scenario unavailable")
        intervention = pd.DataFrame()
        best_recovery = None

    # --------------------------------------------------------
    # STEP 8.7 - SENSITIVITY EVIDENCE
    # --------------------------------------------------------
    section("STEP 8.7 - SENSITIVITY EVIDENCE")

    sensitivity = sens_step7.copy() if sens_step7 is not None else pd.DataFrame()

    if not sensitivity.empty:
        label_col = first_existing_column(
            sensitivity,
            ["Parameter Label", "Parameter", "Parameter Name"]
        )
        rank_col = first_existing_column(
            sensitivity,
            ["Sensitivity Rank", "Rank"]
        )
        range_col = first_existing_column(
            sensitivity,
            ["Sensitivity Range (%)", "Sensitivity Range"]
        )
        elasticity_col = first_existing_column(
            sensitivity,
            ["Elasticity"]
        )

        if label_col:
            detected_params = sensitivity[label_col].dropna().nunique()
            if detected_params == EXPECTED_SENSITIVITY_PARAMETERS:
                pass_msg(
                    "Sensitivity evidence",
                    f"{detected_params} parameters detected"
                )
            else:
                fail_msg(
                    "Sensitivity evidence",
                    f"Expected={EXPECTED_SENSITIVITY_PARAMETERS}, Detected={detected_params}"
                )

        if rank_col:
            sensitivity = sensitivity.sort_values(rank_col)

        save_csv(
            sensitivity,
            TABLE_DIR / "05_final_sensitivity_evidence.csv"
        )

        if rank_col and not sensitivity.empty:
            top_param = str(sensitivity.iloc[0][label_col]) if label_col else "Unknown"
            pass_msg(
                "Sensitivity ranking",
                f"Highest-ranked parameter={top_param}"
            )
    else:
        fail_msg("Sensitivity evidence", "STEP 7 sensitivity evidence unavailable")

    # --------------------------------------------------------
    # STEP 8.8 - VALIDATION EVIDENCE
    # --------------------------------------------------------
    section("STEP 8.8 - VALIDATION EVIDENCE")

    validation_evidence = valid_step7.copy() if valid_step7 is not None else pd.DataFrame()

    if not validation_evidence.empty:
        save_csv(
            validation_evidence,
            TABLE_DIR / "06_final_validation_evidence.csv"
        )

        status_col = first_existing_column(
            validation_evidence,
            ["Status", "Validation Status"]
        )

        if status_col:
            statuses = (
                validation_evidence[status_col]
                .astype(str)
                .str.upper()
            )
            failures = int((statuses == "FAIL").sum())

            if failures == 0:
                pass_msg("Validation evidence", "No validation failures detected")
            else:
                fail_msg(
                    "Validation evidence",
                    f"Validation failures={failures}"
                )
    else:
        fail_msg("Validation evidence", "STEP 7 validation evidence unavailable")

    # --------------------------------------------------------
    # STEP 8.9 - PUBLICATION EVIDENCE MAP
    # --------------------------------------------------------
    section("STEP 8.9 - PUBLICATION EVIDENCE MAP")

    evidence_map = pd.DataFrame([
        {
            "Manuscript Section": "Methods - Model Design",
            "Evidence Source": "STEP 0-1",
            "Primary File": "ABM_PARAMETER_CONFIG.json + STEP01_AGENT_SPECIFICATION.csv",
            "Purpose": "Document model parameters, agent definitions and behavioral structure",
            "Ready": True,
        },
        {
            "Manuscript Section": "Methods - Experimental Design",
            "Evidence Source": "STEP 2 + STEP 4",
            "Primary File": "STEP02_RAW_SIMULATION_RESULTS.csv + STEP04 replication/statistical tables",
            "Purpose": "Document six scenarios, 30 replicates and 12 periods",
            "Ready": True,
        },
        {
            "Manuscript Section": "Results - Scenario Comparison",
            "Evidence Source": "STEP 7-8",
            "Primary File": "02_final_scenario_evidence.csv",
            "Purpose": "Compare recovered material, collection, participation, residuals and cost",
            "Ready": len(scenario_final) == 6,
        },
        {
            "Manuscript Section": "Results - Statistical Evidence",
            "Evidence Source": "STEP 4 + STEP 7",
            "Primary File": "05_statistical_evidence.csv",
            "Purpose": "Provide omnibus, post-hoc, baseline comparison and effect-size evidence",
            "Ready": stat_step7 is not None and not stat_step7.empty,
        },
        {
            "Manuscript Section": "Results - Sensitivity Analysis",
            "Evidence Source": "STEP 5 + STEP 7",
            "Primary File": "05_final_sensitivity_evidence.csv",
            "Purpose": "Identify influential parameters and robustness of recovered material",
            "Ready": not sensitivity.empty,
        },
        {
            "Manuscript Section": "Model Validation",
            "Evidence Source": "STEP 6-7",
            "Primary File": "06_final_validation_evidence.csv",
            "Purpose": "Document mass balance, ranges, replication and data integrity",
            "Ready": not validation_evidence.empty,
        },
        {
            "Manuscript Section": "Reproducibility",
            "Evidence Source": "STEP 7",
            "Primary File": "STEP07_MASTER_DATASET.csv",
            "Purpose": "Provide consolidated row-level simulation evidence",
            "Ready": MASTER_FILE.exists(),
        },
        {
            "Manuscript Section": "Supplementary Material",
            "Evidence Source": "STEP 4-7",
            "Primary File": "STEP07_OUTPUT_CONSOLIDATION_REPORT.txt",
            "Purpose": "Archive detailed diagnostics, tables and validation evidence",
            "Ready": STEP07_REPORT.exists(),
        },
    ])

    save_csv(
        evidence_map,
        TABLE_DIR / "07_publication_evidence_map.csv"
    )

    ready_count = int(evidence_map["Ready"].sum())
    total_evidence_items = len(evidence_map)

    if ready_count == total_evidence_items:
        pass_msg(
            "Publication evidence map",
            f"{ready_count}/{total_evidence_items} evidence blocks ready"
        )
    else:
        fail_msg(
            "Publication evidence map",
            f"{ready_count}/{total_evidence_items} evidence blocks ready"
        )

    # --------------------------------------------------------
    # STEP 8.10 - PUBLICATION METRICS
    # --------------------------------------------------------
    section("STEP 8.10 - PUBLICATION METRICS")

    pub_rows = []

    if not scenario_final.empty:
        for _, row in scenario_final.iterrows():
            pub_rows.append({
                "Scenario ID": row["Scenario ID"],
                "Scenario": row["Scenario"],
                "Recovered Material (kg)": row["Recovered Material Mean (kg)"],
                "Recovered Material SD (kg)": row["Recovered Material SD (kg)"],
                "Collection Rate (%)": row["Collection Rate Mean (%)"],
                "Formal Participation (%)": row["Formal Participation Mean (%)"],
                "Recovery Rate (%)": row["Recovery Rate Mean (%)"],
                "Residual Waste (kg)": row["Residual Waste Mean (kg)"],
                "System Cost (USD)": row["System Cost Mean (USD)"],
                "Recovered Improvement vs Baseline (%)": row["Recovered Improvement vs Baseline (%)"],
            })

    publication_metrics = pd.DataFrame(pub_rows)
    save_csv(
        publication_metrics,
        TABLE_DIR / "08_publication_metrics.csv"
    )

    # --------------------------------------------------------
    # STEP 8.11 - FIGURES
    # --------------------------------------------------------
    section("STEP 8.11 - GENERATING PUBLICATION-READY FIGURES")

    figure_paths = []

    # Figure 1: recovered material by scenario
    if not scenario_final.empty:
        fig, ax = plt.subplots(figsize=(11, 6))
        x = np.arange(len(scenario_final))
        means = scenario_final["Recovered Material Mean (kg)"].to_numpy()
        sds = scenario_final["Recovered Material SD (kg)"].to_numpy()

        ax.bar(x, means, yerr=sds, capsize=4)
        ax.set_xticks(x)
        ax.set_xticklabels(
            scenario_final["Scenario"],
            rotation=25,
            ha="right"
        )
        ax.set_ylabel("Recovered Material (kg)")
        ax.set_title("Recovered Material by Scenario")
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()

        path = FIGURE_DIR / "01_publication_recovered_material_by_scenario.png"
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        figure_paths.append(path)
        print(f"[SAVED] {path}")

    # Figure 2: collection and participation
    if not scenario_final.empty:
        fig, ax = plt.subplots(figsize=(11, 6))
        x = np.arange(len(scenario_final))
        width = 0.36

        ax.bar(
            x - width / 2,
            scenario_final["Collection Rate Mean (%)"].to_numpy(),
            width,
            label="Collection Rate"
        )
        ax.bar(
            x + width / 2,
            scenario_final["Formal Participation Mean (%)"].to_numpy(),
            width,
            label="Formal Participation"
        )

        ax.set_xticks(x)
        ax.set_xticklabels(
            scenario_final["Scenario"],
            rotation=25,
            ha="right"
        )
        ax.set_ylabel("Percentage (%)")
        ax.set_title("Collection Rate and Formal Participation by Scenario")
        ax.legend()
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()

        path = FIGURE_DIR / "02_publication_collection_participation.png"
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        figure_paths.append(path)
        print(f"[SAVED] {path}")

    # Figure 3: sensitivity ranking
    if not sensitivity.empty:
        label_col = first_existing_column(
            sensitivity,
            ["Parameter Label", "Parameter", "Parameter Name"]
        )
        rank_col = first_existing_column(
            sensitivity,
            ["Sensitivity Rank", "Rank"]
        )
        range_col = first_existing_column(
            sensitivity,
            ["Sensitivity Range (%)", "Sensitivity Range"]
        )

        if label_col and range_col:
            sens_plot = sensitivity.copy()
            if rank_col:
                sens_plot = sens_plot.sort_values(rank_col)
            else:
                sens_plot = sens_plot.sort_values(range_col, ascending=False)

            fig, ax = plt.subplots(figsize=(10, 6))
            labels = sens_plot[label_col].astype(str).to_numpy()
            values = pd.to_numeric(
                sens_plot[range_col],
                errors="coerce"
            ).to_numpy()

            ax.barh(np.arange(len(labels)), values)
            ax.set_yticks(np.arange(len(labels)))
            ax.set_yticklabels(labels)
            ax.invert_yaxis()
            ax.set_xlabel("Sensitivity Range (%)")
            ax.set_title("Sensitivity Ranking of Model Parameters")
            ax.grid(axis="x", alpha=0.25)
            fig.tight_layout()

            path = FIGURE_DIR / "03_publication_sensitivity_ranking.png"
            fig.savefig(path, dpi=300, bbox_inches="tight")
            plt.close(fig)
            figure_paths.append(path)
            print(f"[SAVED] {path}")

    # Figure 4: Scenario 5 replicate distribution
    if not replicate_final.empty:
        rep_s_col = scenario_name_col(replicate_final)
        s5 = replicate_final[
            replicate_final[rep_s_col] == "Scenario 5 - Combined Orchestration"
        ]

        rec_rep_col = first_existing_column(
            s5,
            [
                "Recovered Material (kg) mean",
                "Recovered Material (kg) mean".replace("(", ""),
            ]
        )

        # Detect generated flattened column safely.
        candidates = [
            c for c in s5.columns
            if "Recovered Material" in str(c) and "mean" in str(c).lower()
        ]

        if candidates:
            rec_rep_col = candidates[0]

        if rec_rep_col and not s5.empty:
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.boxplot(
                pd.to_numeric(s5[rec_rep_col], errors="coerce").dropna().to_numpy(),
                orientation="vertical"
            )
            ax.set_ylabel("Recovered Material (kg)")
            ax.set_title("Scenario 5 - Combined Orchestration: Replicate Distribution")
            ax.grid(axis="y", alpha=0.25)
            fig.tight_layout()

            path = FIGURE_DIR / "04_publication_scenario5_boxplot.png"
            fig.savefig(path, dpi=300, bbox_inches="tight")
            plt.close(fig)
            figure_paths.append(path)
            print(f"[SAVED] {path}")

    # Figure 5: cost vs recovered material
    if not scenario_final.empty:
        fig, ax = plt.subplots(figsize=(9, 6))
        x = scenario_final["System Cost Mean (USD)"].to_numpy()
        y = scenario_final["Recovered Material Mean (kg)"].to_numpy()

        ax.scatter(x, y, s=70)

        for _, row in scenario_final.iterrows():
            ax.annotate(
                f"S{int(row['Scenario ID'])}",
                (
                    row["System Cost Mean (USD)"],
                    row["Recovered Material Mean (kg)"]
                ),
                xytext=(5, 5),
                textcoords="offset points"
            )

        ax.set_xlabel("System Cost (USD)")
        ax.set_ylabel("Recovered Material (kg)")
        ax.set_title("Recovery-Cost Trade-off Across Scenarios")
        ax.grid(alpha=0.25)
        fig.tight_layout()

        path = FIGURE_DIR / "05_publication_recovery_cost_tradeoff.png"
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        figure_paths.append(path)
        print(f"[SAVED] {path}")

    if len(figure_paths) == 5:
        pass_msg("Publication figures", "5/5 figures generated")
    else:
        fail_msg(
            "Publication figures",
            f"Generated={len(figure_paths)}/5"
        )

    # --------------------------------------------------------
    # STEP 8.12 - FINAL STATISTICAL/EVIDENCE PACKAGE
    # --------------------------------------------------------
    section("STEP 8.12 - FINAL EVIDENCE PACKAGE")

    package_rows = [
        {
            "Package Component": "Master dataset",
            "Path": str(MASTER_FILE),
            "Status": "READY" if MASTER_FILE.exists() else "MISSING",
            "Description": "Full consolidated row-level simulation dataset",
        },
        {
            "Package Component": "Replicate-level dataset",
            "Path": str(REPLICATE_MASTER_FILE),
            "Status": "READY" if REPLICATE_MASTER_FILE.exists() else "MISSING",
            "Description": "One row per scenario-replicate for statistical analysis",
        },
        {
            "Package Component": "Scenario evidence",
            "Path": str(TABLE_DIR / "02_final_scenario_evidence.csv"),
            "Status": "READY",
            "Description": "Publication-ready scenario metrics",
        },
        {
            "Package Component": "Baseline comparison",
            "Path": str(TABLE_DIR / "04_final_baseline_vs_interventions.csv"),
            "Status": "READY" if not intervention.empty else "MISSING",
            "Description": "Intervention performance relative to baseline",
        },
        {
            "Package Component": "Sensitivity evidence",
            "Path": str(TABLE_DIR / "05_final_sensitivity_evidence.csv"),
            "Status": "READY" if not sensitivity.empty else "MISSING",
            "Description": "Parameter sensitivity and robustness evidence",
        },
        {
            "Package Component": "Validation evidence",
            "Path": str(TABLE_DIR / "06_final_validation_evidence.csv"),
            "Status": "READY" if not validation_evidence.empty else "MISSING",
            "Description": "Model validation and data integrity evidence",
        },
        {
            "Package Component": "Publication evidence map",
            "Path": str(TABLE_DIR / "07_publication_evidence_map.csv"),
            "Status": "READY",
            "Description": "Mapping from manuscript sections to model evidence",
        },
        {
            "Package Component": "Publication metrics",
            "Path": str(TABLE_DIR / "08_publication_metrics.csv"),
            "Status": "READY",
            "Description": "Compact metrics for tables/results writing",
        },
    ]

    evidence_package = pd.DataFrame(package_rows)
    save_csv(
        evidence_package,
        TABLE_DIR / "09_final_evidence_package.csv"
    )

    # --------------------------------------------------------
    # STEP 8.13 - EXCEL WORKBOOK
    # --------------------------------------------------------
    section("STEP 8.13 - BUILDING FINAL PUBLICATION WORKBOOK")

    workbook_path = OUTPUT_DIR / "STEP08_PUBLICATION_PACKAGE.xlsx"

    sheets = {
        "Scenario Evidence": scenario_final,
        "Replicate Evidence": replicate_final,
        "Baseline Comparison": intervention,
        "Sensitivity": sensitivity,
        "Validation": validation_evidence,
        "Evidence Map": evidence_map,
        "Publication Metrics": publication_metrics,
        "Evidence Package": evidence_package,
    }

    excel_ok = write_excel_package(workbook_path, sheets)

    if excel_ok:
        pass_msg("Publication workbook", f"Created={workbook_path}")
    else:
        fail_msg("Publication workbook", "Workbook creation failed")

    # --------------------------------------------------------
    # STEP 8.14 - FINAL READINESS VALIDATION
    # --------------------------------------------------------
    section("STEP 8.14 - FINAL READINESS VALIDATION")

    final_checks = []

    def final_check(name, condition, details):
        status = "PASS" if condition else "FAIL"
        final_checks.append({
            "Check": name,
            "Status": status,
            "Details": details
        })
        if condition:
            pass_msg(name, details)
        else:
            fail_msg(name, details)

    final_check(
        "Master dataset exists",
        MASTER_FILE.exists(),
        f"Rows={len(master)}, Columns={len(master.columns)}"
    )

    final_check(
        "Six scenarios available",
        len(scenario_final) == 6,
        f"Detected={len(scenario_final)}"
    )

    final_check(
        "Thirty replicates per scenario",
        len(bad_rep_counts) == 0 and len(rep_counts) == 6,
        f"Detected={rep_counts}"
    )

    final_check(
        "Twelve periods per scenario",
        all(
            master[master[s_col] == s]["Period"].nunique() == EXPECTED_PERIODS
            for s in SCENARIOS
            if s in set(master[s_col].dropna())
        ),
        f"Expected={EXPECTED_PERIODS} periods/scenario"
    )

    final_check(
        "Core numeric fields finite",
        len(bad_numeric) == 0,
        "All numeric fields finite"
    )

    final_check(
        "Sensitivity parameters complete",
        (
            not sensitivity.empty
            and first_existing_column(
                sensitivity,
                ["Parameter Label", "Parameter", "Parameter Name"]
            ) is not None
            and sensitivity[
                first_existing_column(
                    sensitivity,
                    ["Parameter Label", "Parameter", "Parameter Name"]
                )
            ].dropna().nunique() == EXPECTED_SENSITIVITY_PARAMETERS
        ),
        f"Expected={EXPECTED_SENSITIVITY_PARAMETERS}"
    )

    final_check(
        "Validation evidence available",
        not validation_evidence.empty,
        f"Rows={len(validation_evidence)}"
    )

    final_check(
        "Publication evidence map complete",
        ready_count == total_evidence_items,
        f"Ready={ready_count}/{total_evidence_items}"
    )

    final_check(
        "Publication figures complete",
        len(figure_paths) == 5,
        f"Figures={len(figure_paths)}/5"
    )

    final_check(
        "Publication workbook ready",
        excel_ok,
        str(workbook_path)
    )

    final_validation_df = pd.DataFrame(final_checks)
    save_csv(
        final_validation_df,
        TABLE_DIR / "10_final_readiness_validation.csv"
    )

    # --------------------------------------------------------
    # STEP 8.15 - FINAL REPORT
    # --------------------------------------------------------
    section("STEP 8.15 - GENERATING STEP 8 FINAL REPORT")

    failures = int((final_validation_df["Status"] == "FAIL").sum())

    scenario5 = scenario_final[
        scenario_final["Scenario"] == "Scenario 5 - Combined Orchestration"
    ]

    report_lines = [
        "E-WASTE ABM",
        "STEP 8: FINAL REPORTING, PUBLICATION PACKAGE & EVIDENCE READINESS",
        "FINAL COMPATIBLE VERSION",
        "",
        f"Project root : {PROJECT_ROOT}",
        f"Output       : {OUTPUT_DIR}",
        "",
        "STEP 8 SUMMARY",
        f"Scenarios analyzed        : {len(scenario_final)}",
        f"Raw/master dataset rows   : {len(master)}",
        f"Master dataset columns    : {len(master.columns)}",
        f"Replicate-level rows      : {len(replicate_final)}",
        f"Sensitivity parameters    : {sensitivity[first_existing_column(sensitivity, ['Parameter Label', 'Parameter', 'Parameter Name'])].nunique() if not sensitivity.empty and first_existing_column(sensitivity, ['Parameter Label', 'Parameter', 'Parameter Name']) else 0}",
        f"Publication figures        : {len(figure_paths)}",
        f"Evidence map items         : {total_evidence_items}",
        f"Evidence map ready         : {ready_count}",
        f"Final validation failures  : {failures}",
        "",
        "SCENARIO RESULTS",
    ]

    if not scenario_final.empty:
        for _, row in scenario_final.iterrows():
            report_lines.append(
                f"- S{int(row['Scenario ID'])} {row['Scenario']}: "
                f"Recovered={row['Recovered Material Mean (kg)']:.6f} kg; "
                f"Collection={row['Collection Rate Mean (%)']:.6f}%; "
                f"Participation={row['Formal Participation Mean (%)']:.6f}%; "
                f"Cost={row['System Cost Mean (USD)']:.6f} USD"
            )

    report_lines.extend([
        "",
        "SCENARIO 5 REFERENCE",
    ])

    if not scenario5.empty:
        s5 = scenario5.iloc[0]
        report_lines.extend([
            f"Recovered Material Mean : {s5['Recovered Material Mean (kg)']:.6f} kg",
            f"Recovered Material SD   : {s5['Recovered Material SD (kg)']:.6f} kg",
            f"Collection Rate Mean    : {s5['Collection Rate Mean (%)']:.6f}%",
            f"Formal Participation    : {s5['Formal Participation Mean (%)']:.6f}%",
            f"System Cost Mean        : {s5['System Cost Mean (USD)']:.6f} USD",
        ])

    if best_recovery is not None:
        report_lines.extend([
            "",
            "BEST RECOVERY SCENARIO",
            f"Scenario                 : {best_recovery['Scenario']}",
            f"Recovered Material       : {best_recovery['Recovered Material Mean (kg)']:.6f} kg",
            f"Improvement vs Baseline  : {best_recovery['Recovered Improvement vs Baseline (%)']:.6f}%",
        ])

    report_lines.extend([
        "",
        "PUBLICATION PACKAGE",
        f"- STEP08_PUBLICATION_PACKAGE.xlsx",
        f"- tables/02_final_scenario_evidence.csv",
        f"- tables/03_final_replicate_evidence.csv",
        f"- tables/04_final_baseline_vs_interventions.csv",
        f"- tables/05_final_sensitivity_evidence.csv",
        f"- tables/06_final_validation_evidence.csv",
        f"- tables/07_publication_evidence_map.csv",
        f"- tables/08_publication_metrics.csv",
        f"- tables/09_final_evidence_package.csv",
        f"- tables/10_final_readiness_validation.csv",
        f"- figures/{len(figure_paths)} publication-ready figures",
        "",
        "FINAL STATUS",
        "STEP 8 STATUS : " + ("PASS" if failures == 0 else "FAIL"),
    ])

    report_path = OUTPUT_DIR / "STEP08_FINAL_REPORT.txt"
    report_path.write_text(
        "\n".join(report_lines),
        encoding="utf-8"
    )
    print(f"[SAVED] {report_path}")

    # --------------------------------------------------------
    # FINAL SUMMARY
    # --------------------------------------------------------
    banner("STEP 8 FINAL SUMMARY")

    print(f"Scenarios analyzed        : {len(scenario_final)}")
    print(f"Master dataset rows       : {len(master)}")
    print(f"Master dataset columns    : {len(master.columns)}")
    print(f"Replicate-level rows      : {len(replicate_final)}")
    print(f"Sensitivity parameters    : {EXPECTED_SENSITIVITY_PARAMETERS}")
    print(f"Publication figures       : {len(figure_paths)}")
    print(f"Evidence map items        : {total_evidence_items}")
    print(f"Evidence map ready        : {ready_count}")
    print(f"Validation failures       : {failures}")
    print(f"Output folder             : {OUTPUT_DIR}")
    print(f"Tables folder             : {TABLE_DIR}")
    print(f"Figures folder            : {FIGURE_DIR}")

    print("\n" + "=" * 100)
    print(f"STEP 8 STATUS : {'PASS' if failures == 0 else 'FAIL'}")
    print("=" * 100)

    if failures == 0:
        print("READY FOR FINAL MANUSCRIPT / THESIS REPORTING")
    else:
        print("REVIEW REQUIRED BEFORE FINAL MANUSCRIPT / THESIS REPORTING")


if __name__ == "__main__":
    main()
