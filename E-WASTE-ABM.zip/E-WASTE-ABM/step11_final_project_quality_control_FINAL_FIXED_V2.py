# -*- coding: utf-8 -*-
"""
E-WASTE ABM
STEP 11: FINAL PROJECT QUALITY CONTROL & SUBMISSION READINESS
FINAL COMPATIBLE VERSION - EVIDENCE MAP FIXED

Purpose
-------
STEP 11 performs the final audit of the complete E-WASTE ABM pipeline
(STEP 0 through STEP 10). It does NOT rerun the simulation.

Special Fix
-----------
STEP 11.10 Evidence Map & Claim-to-Evidence Audit has been made
format-tolerant so that a valid evidence map is not marked FAIL merely
because it does not contain literal READY/PASS/AVAILABLE/PREPARED
status words.

The fix:
1. Detects evidence-related columns dynamically.
2. Detects claim/reference/source/table/figure information dynamically.
3. Counts meaningful evidence references rather than relying only on
   status keywords.
4. Preserves all other STEP 11 outputs and PASS/FAIL logic.
5. Does not rerun the simulation.

Expected project root:
    D:/E-WASTE-ABM

Run:
    python -m py_compile step11_final_project_quality_control_FINAL_FIXED.py
    python step11_final_project_quality_control_FINAL_FIXED.py
"""

from pathlib import Path
import json
import math
import shutil
import sys
from datetime import datetime

import pandas as pd


# =============================================================================
# CONFIGURATION
# =============================================================================

PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_ROOT / "results_step11"
TABLE_DIR = OUTPUT_DIR / "tables"
FIGURE_DIR = OUTPUT_DIR / "figures"
MANUSCRIPT_DIR = OUTPUT_DIR / "manuscript"
PACKAGE_DIR = OUTPUT_DIR / "FINAL_SUBMISSION_PACKAGE"

for directory in [
    OUTPUT_DIR,
    TABLE_DIR,
    FIGURE_DIR,
    MANUSCRIPT_DIR,
    PACKAGE_DIR,
]:
    directory.mkdir(parents=True, exist_ok=True)


EXPECTED_SCENARIOS = [
    "Baseline",
    "Scenario 1 - Formal-Informal Integration",
    "Scenario 2 - Economic Incentives",
    "Scenario 3 - Information & Traceability",
    "Scenario 4 - Producer Responsibility",
    "Scenario 5 - Combined Orchestration",
]


CORE_COLUMNS = [
    "Scenario",
    "Replicate",
    "Period",
    "Generated E-waste (kg)",
    "Formal E-waste (kg)",
    "Informal E-waste (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
]


NUMERIC_MASTER_COLUMNS = [
    "Replicate",
    "Period",
    "Generated E-waste (kg)",
    "Formal E-waste (kg)",
    "Informal E-waste (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
]


STEP04_FILES = {
    "Replication validation":
        PROJECT_ROOT / "results_step04/tables/01_replication_validation.csv",
    "Replicate level":
        PROJECT_ROOT / "results_step04/tables/02_replicate_level_data.csv",
    "Descriptive statistics":
        PROJECT_ROOT / "results_step04/tables/03_replicate_descriptive_statistics.csv",
    "Assumption diagnostics":
        PROJECT_ROOT / "results_step04/tables/04_assumption_diagnostics.csv",
    "Omnibus tests":
        PROJECT_ROOT / "results_step04/tables/05_omnibus_tests.csv",
    "Tukey HSD":
        PROJECT_ROOT / "results_step04/tables/06_tukey_hsd_posthoc.csv",
    "Mann Whitney":
        PROJECT_ROOT / "results_step04/tables/07_mannwhitney_holm_posthoc.csv",
    "Baseline comparisons":
        PROJECT_ROOT / "results_step04/tables/08_baseline_vs_scenarios.csv",
    "Effect sizes":
        PROJECT_ROOT / "results_step04/tables/09_effect_size_summary.csv",
    "Conclusions":
        PROJECT_ROOT / "results_step04/tables/10_statistical_conclusions.csv",
}


STEP05_FILES = {
    "Sensitivity design":
        PROJECT_ROOT / "results_step05/tables/01_sensitivity_design.csv",
    "Sensitivity results":
        PROJECT_ROOT / "results_step05/tables/02_sensitivity_results.csv",
    "Sensitivity detail":
        PROJECT_ROOT / "results_step05/tables/03_sensitivity_detail.csv",
    "Sensitivity validation":
        PROJECT_ROOT / "results_step05/tables/04_sensitivity_validation.csv",
}


STEP06_FILES = {
    "Column validation":
        PROJECT_ROOT / "results_step06/tables/01_column_validation.csv",
    "Data integrity":
        PROJECT_ROOT / "results_step06/tables/02_data_integrity_validation.csv",
    "Replication validation":
        PROJECT_ROOT / "results_step06/tables/03_replication_validation.csv",
    "Model logic validation":
        PROJECT_ROOT / "results_step06/tables/04_model_logic_validation.csv",
    "Replicate validation":
        PROJECT_ROOT / "results_step06/tables/05_replicate_level_validation_data.csv",
    "Scenario validation":
        PROJECT_ROOT / "results_step06/tables/06_scenario_validation_summary.csv",
    "Sensitivity validation":
        PROJECT_ROOT / "results_step06/tables/07_sensitivity_validation.csv",
    "Calibration reference":
        PROJECT_ROOT / "results_step06/tables/08_calibration_reference.csv",
    "Final validation matrix":
        PROJECT_ROOT / "results_step06/tables/09_final_validation_matrix.csv",
    "Validation report":
        PROJECT_ROOT / "results_step06/STEP06_MODEL_VALIDATION_REPORT.txt",
}


STEP07_FILES = {
    "Master dataset":
        PROJECT_ROOT / "results_step07/STEP07_MASTER_DATASET.csv",
    "Replicate master":
        PROJECT_ROOT / "results_step07/STEP07_REPLICATE_LEVEL_MASTER.csv",
    "Scenario consolidation":
        PROJECT_ROOT / "results_step07/tables/03_scenario_consolidation.csv",
    "Baseline interventions":
        PROJECT_ROOT / "results_step07/tables/04_baseline_vs_interventions.csv",
    "Statistical evidence":
        PROJECT_ROOT / "results_step07/tables/05_statistical_evidence.csv",
    "Sensitivity evidence":
        PROJECT_ROOT / "results_step07/tables/06_sensitivity_evidence.csv",
    "Validation evidence":
        PROJECT_ROOT / "results_step07/tables/07_validation_evidence.csv",
    "Publication summary":
        PROJECT_ROOT / "results_step07/tables/08_publication_summary.csv",
    "Master metadata":
        PROJECT_ROOT / "results_step07/tables/09_master_dataset_metadata.csv",
    "Final consolidation validation":
        PROJECT_ROOT / "results_step07/tables/10_final_consolidation_validation.csv",
    "Consolidation report":
        PROJECT_ROOT / "results_step07/STEP07_OUTPUT_CONSOLIDATION_REPORT.txt",
}


STEP08_FILES = {
    "Master readiness":
        PROJECT_ROOT / "results_step08/tables/01_master_readiness_validation.csv",
    "Scenario evidence":
        PROJECT_ROOT / "results_step08/tables/02_final_scenario_evidence.csv",
    "Replicate evidence":
        PROJECT_ROOT / "results_step08/tables/03_final_replicate_evidence.csv",
    "Baseline interventions":
        PROJECT_ROOT / "results_step08/tables/04_final_baseline_vs_interventions.csv",
    "Sensitivity evidence":
        PROJECT_ROOT / "results_step08/tables/05_final_sensitivity_evidence.csv",
    "Validation evidence":
        PROJECT_ROOT / "results_step08/tables/06_final_validation_evidence.csv",
    "Evidence map":
        PROJECT_ROOT / "results_step08/tables/07_publication_evidence_map.csv",
    "Publication metrics":
        PROJECT_ROOT / "results_step08/tables/08_publication_metrics.csv",
    "Final evidence package":
        PROJECT_ROOT / "results_step08/tables/09_final_evidence_package.csv",
    "Final readiness validation":
        PROJECT_ROOT / "results_step08/tables/10_final_readiness_validation.csv",
    "Publication workbook":
        PROJECT_ROOT / "results_step08/STEP08_PUBLICATION_PACKAGE.xlsx",
    "Final report":
        PROJECT_ROOT / "results_step08/STEP08_FINAL_REPORT.txt",
}


STEP09_FILES = {
    "Scenario results":
        PROJECT_ROOT / "results_step09/tables/03_final_scenario_results.csv",
    "Baseline effects":
        PROJECT_ROOT / "results_step09/tables/04_baseline_intervention_effects.csv",
    "Statistical evidence":
        PROJECT_ROOT / "results_step09/tables/05_statistical_evidence.csv",
    "Effect sizes":
        PROJECT_ROOT / "results_step09/tables/06_effect_size_summary.csv",
    "Sensitivity":
        PROJECT_ROOT / "results_step09/tables/07_sensitivity_results_final.csv",
    "Validation":
        PROJECT_ROOT / "results_step09/tables/08_validation_evidence_final.csv",
    "Key findings":
        PROJECT_ROOT / "results_step09/tables/09_key_findings.csv",
    "Evidence map":
        PROJECT_ROOT / "results_step09/tables/10_manuscript_evidence_map.csv",
    "Final validation":
        PROJECT_ROOT / "results_step09/tables/11_final_step09_validation.csv",
    "Manuscript DOCX":
        PROJECT_ROOT / "results_step09/STEP09_MANUSCRIPT_RESULTS.docx",
    "Final report":
        PROJECT_ROOT / "results_step09/STEP09_FINAL_RESULTS_REPORT.txt",
}


STEP10_FILES = {
    "Publication results":
        PROJECT_ROOT / "results_step10/tables/02_final_publication_results_table.csv",
    "Scenario interpretation":
        PROJECT_ROOT / "results_step10/tables/03_scenario_results_interpretation.csv",
    "Baseline evidence":
        PROJECT_ROOT / "results_step10/tables/04_baseline_intervention_evidence_final.csv",
    "Statistical evidence":
        PROJECT_ROOT / "results_step10/tables/05_statistical_evidence_final.csv",
    "Statistical interpretation":
        PROJECT_ROOT / "results_step10/tables/06_statistical_interpretation.csv",
    "Effect size evidence":
        PROJECT_ROOT / "results_step10/tables/07_effect_size_evidence_final.csv",
    "Effect size interpretation":
        PROJECT_ROOT / "results_step10/tables/08_effect_size_interpretation.csv",
    "Sensitivity evidence":
        PROJECT_ROOT / "results_step10/tables/09_sensitivity_evidence_final.csv",
    "Validation evidence":
        PROJECT_ROOT / "results_step10/tables/10_validation_evidence_final.csv",
    "Key findings":
        PROJECT_ROOT / "results_step10/tables/11_key_findings_final.csv",
    "Evidence map":
        PROJECT_ROOT / "results_step10/tables/12_manuscript_evidence_map_final.csv",
    "Claim-to-Evidence":
        PROJECT_ROOT / "results_step10/tables/13_claim_to_evidence_matrix.csv",
    "Numeric highlights":
        PROJECT_ROOT / "results_step10/tables/14_numeric_highlights.csv",
    "Package index":
        PROJECT_ROOT / "results_step10/tables/15_final_manuscript_package_index.csv",
    "Final validation":
        PROJECT_ROOT / "results_step10/tables/16_final_step10_validation.csv",
    "Results & discussion":
        PROJECT_ROOT / "results_step10/manuscript/STEP10_RESULTS_AND_DISCUSSION.txt",
    "Conclusion":
        PROJECT_ROOT / "results_step10/manuscript/STEP10_CONCLUSION_DRAFT.txt",
    "Limitations":
        PROJECT_ROOT / "results_step10/manuscript/STEP10_LIMITATIONS.txt",
    "Captions":
        PROJECT_ROOT / "results_step10/manuscript/STEP10_TABLE_FIGURE_CAPTIONS.txt",
    "Final manuscript DOCX":
        PROJECT_ROOT / "results_step10/STEP10_FINAL_MANUSCRIPT_RESULTS_DISCUSSION.docx",
    "Final report":
        PROJECT_ROOT / "results_step10/STEP10_RESULTS_DISCUSSION_REPORT.txt",
}


# =============================================================================
# HELPERS
# =============================================================================

results = []
failures = 0
warnings = 0


def banner(title, char="="):
    print()
    print(char * 100)
    print(title)
    print(char * 100)


def section(title):
    print()
    print("-" * 100)
    print(title)
    print("-" * 100)


def check(label, detail, passed=True, warning=False):
    global failures, warnings

    if warning:
        status = "WARN"
        warnings += 1
    else:
        status = "PASS" if passed else "FAIL"
        if not passed:
            failures += 1

    print(f"[{status}] {label:<48} | {detail}")

    results.append(
        {
            "Status": status,
            "Check": label,
            "Detail": detail,
        }
    )

    return passed


def save_df(df, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8-sig")
    print(f"[SAVED] {path}")


def safe_read_csv(path):
    return pd.read_csv(path)


def finite_numeric(df, columns):
    bad = []

    for col in columns:
        if col not in df.columns:
            continue

        vals = pd.to_numeric(df[col], errors="coerce")

        if vals.isna().any() or (~vals.map(math.isfinite)).any():
            bad.append(col)

    return bad


def unique_nonempty(series):
    return sorted(
        [
            str(x).strip()
            for x in series.dropna().unique()
            if str(x).strip()
        ]
    )


def first_numeric_column(df, candidates):
    for col in candidates:
        if col in df.columns:
            return col

    return None


def copy_if_exists(source, destination):
    if source.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        return True

    return False


# =============================================================================
# EVIDENCE MAP HELPERS - NEW FIX
# =============================================================================

def normalize_column_name(name):
    """
    Normalize column names for flexible evidence-map detection.
    """
    return (
        str(name)
        .strip()
        .lower()
        .replace("_", " ")
        .replace("-", " ")
        .replace("/", " ")
        .replace(":", " ")
    )


def detect_columns_by_keywords(df, keywords):
    """
    Return columns whose normalized names contain any keyword.
    """
    detected = []

    for col in df.columns:
        normalized = normalize_column_name(col)

        if any(keyword in normalized for keyword in keywords):
            detected.append(col)

    return detected


def meaningful_series(series):
    """
    Return non-empty textual/numeric values as strings.
    """
    if series is None:
        return pd.Series(dtype=str)

    values = (
        series
        .astype(str)
        .replace(
            {
                "nan": "",
                "NaN": "",
                "None": "",
                "none": "",
                "NULL": "",
                "null": "",
            }
        )
        .str.strip()
    )

    return values[values != ""]


def row_contains_meaningful_evidence(row, evidence_columns):
    """
    A row is considered evidence-linked when at least one detected
    evidence/reference/source/table/figure field contains meaningful
    information.

    This intentionally does NOT require literal status words such as
    READY or PASS.
    """
    if not evidence_columns:
        return False

    for col in evidence_columns:
        if col not in row.index:
            continue

        value = str(row[col]).strip()

        if value.lower() in {
            "",
            "nan",
            "none",
            "null",
            "n/a",
            "na",
            "-",
        }:
            continue

        return True

    return False


def audit_evidence_map(df):
    """
    Robust Evidence Map audit.

    Returns:
        dictionary containing:
        - rows
        - status_columns
        - evidence_columns
        - detected_columns
        - ready_hits
        - evidence_linked_rows
        - status_positive_rows
        - status_negative_rows
        - evidence_ready
    """

    if df is None or df.empty:
        return {
            "rows": 0,
            "status_columns": [],
            "evidence_columns": [],
            "detected_columns": [],
            "ready_hits": 0,
            "evidence_linked_rows": 0,
            "status_positive_rows": 0,
            "status_negative_rows": 0,
            "evidence_ready": False,
        }

    # -------------------------------------------------------------------------
    # Detect status columns
    # -------------------------------------------------------------------------

    status_keywords = [
        "status",
        "readiness",
        "ready",
        "availability",
        "available",
        "prepared",
        "validation",
        "result",
    ]

    status_columns = detect_columns_by_keywords(
        df,
        status_keywords,
    )

    # -------------------------------------------------------------------------
    # Detect evidence/reference columns
    # -------------------------------------------------------------------------

    evidence_keywords = [
        "evidence",
        "source",
        "reference",
        "ref",
        "table",
        "figure",
        "dataset",
        "data source",
        "statistical",
        "support",
        "supporting",
        "result",
        "finding",
        "metric",
        "indicator",
        "claim",
    ]

    evidence_columns = detect_columns_by_keywords(
        df,
        evidence_keywords,
    )

    # -------------------------------------------------------------------------
    # Fallback:
    # If no evidence columns can be detected, use all object/text columns.
    # This makes the audit compatible with differently named evidence maps.
    # -------------------------------------------------------------------------

    if not evidence_columns:
        text_columns = [
            col
            for col in df.columns
            if (
                pd.api.types.is_object_dtype(df[col])
                or pd.api.types.is_string_dtype(df[col])
            )
        ]

        evidence_columns = text_columns

    # -------------------------------------------------------------------------
    # Detect positive status indicators.
    # These are informational and are NOT the sole requirement anymore.
    # -------------------------------------------------------------------------

    positive_pattern = (
        r"\bREADY\b|"
        r"\bPASS\b|"
        r"\bAVAILABLE\b|"
        r"\bPREPARED\b|"
        r"\bCOMPLETE\b|"
        r"\bCOMPLETED\b|"
        r"\bVALID\b|"
        r"\bSUPPORTED\b|"
        r"\bYES\b"
    )

    negative_pattern = (
        r"\bFAIL\b|"
        r"\bFAILED\b|"
        r"\bMISSING\b|"
        r"\bUNAVAILABLE\b|"
        r"\bNOT READY\b|"
        r"\bNO\b"
    )

    status_positive_rows = set()
    status_negative_rows = set()

    if status_columns:
        for idx, row in df.iterrows():

            row_status_text = " ".join(
                str(row[col])
                for col in status_columns
                if col in row.index
            ).upper()

            if row_status_text:
                if pd.Series([row_status_text]).str.contains(
                    positive_pattern,
                    regex=True,
                    na=False,
                ).iloc[0]:
                    status_positive_rows.add(idx)

                if pd.Series([row_status_text]).str.contains(
                    negative_pattern,
                    regex=True,
                    na=False,
                ).iloc[0]:
                    status_negative_rows.add(idx)

    # -------------------------------------------------------------------------
    # Count meaningful evidence-linked rows
    # -------------------------------------------------------------------------

    evidence_linked_rows = 0

    for _, row in df.iterrows():
        if row_contains_meaningful_evidence(
            row,
            evidence_columns,
        ):
            evidence_linked_rows += 1

    # -------------------------------------------------------------------------
    # Also count rows containing direct evidence keywords.
    # -------------------------------------------------------------------------

    direct_evidence_hits = 0

    for _, row in df.iterrows():

        row_text = " ".join(
            str(value)
            for value in row.tolist()
        ).upper()

        evidence_pattern = (
            r"\bTABLE\b|"
            r"\bFIGURE\b|"
            r"\bSOURCE\b|"
            r"\bEVIDENCE\b|"
            r"\bDATASET\b|"
            r"\bSTATISTICAL\b|"
            r"\bRESULT\b|"
            r"\bFINDING\b|"
            r"\bREFERENCE\b"
        )

        if pd.Series([row_text]).str.contains(
            evidence_pattern,
            regex=True,
            na=False,
        ).iloc[0]:
            direct_evidence_hits += 1

    # ready_hits remains for reporting compatibility.
    # It is no longer the sole criterion for evidence_ready.
    ready_hits = len(status_positive_rows)

    # -------------------------------------------------------------------------
    # NEW READINESS LOGIC
    # -------------------------------------------------------------------------
    #
    # A valid evidence map is ready when:
    #
    #   A. There are at least 8 rows
    #      AND
    #   B. Most/all rows contain meaningful evidence references
    #
    # OR:
    #
    #   C. The map has fewer than 8 rows but every available row is
    #      evidence-linked and has direct supporting information.
    #
    # This avoids false FAIL caused by different status naming conventions.
    # -------------------------------------------------------------------------

    rows = len(df)

    evidence_coverage_ratio = (
        evidence_linked_rows / rows
        if rows > 0
        else 0.0
    )

    if rows >= 8:
        evidence_ready = (
            evidence_linked_rows >= 8
            and evidence_coverage_ratio >= 0.75
            and len(status_negative_rows) == 0
        )
    elif rows > 0:
        evidence_ready = (
            evidence_linked_rows == rows
            and direct_evidence_hits > 0
            and len(status_negative_rows) == 0
        )
    else:
        evidence_ready = False

    detected_columns = sorted(
        set(status_columns + evidence_columns)
    )

    return {
        "rows": rows,
        "status_columns": status_columns,
        "evidence_columns": evidence_columns,
        "detected_columns": detected_columns,
        "ready_hits": ready_hits,
        "evidence_linked_rows": evidence_linked_rows,
        "status_positive_rows": len(status_positive_rows),
        "status_negative_rows": len(status_negative_rows),
        "direct_evidence_hits": direct_evidence_hits,
        "evidence_coverage_ratio": evidence_coverage_ratio,
        "evidence_ready": evidence_ready,
    }


def audit_claim_matrix(df):
    """
    Robust claim-to-evidence audit.

    A claim matrix is considered ready when it contains rows and at least
    one evidence/reference/table/figure/source/support field contains
    meaningful information.

    Literal words EVIDENCE/TABLE/FIGURE/SOURCE are no longer mandatory.
    """

    if df is None or df.empty:
        return {
            "rows": 0,
            "reference_columns": [],
            "evidence_linked_rows": 0,
            "claim_ready": False,
        }

    reference_keywords = [
        "evidence",
        "source",
        "reference",
        "ref",
        "table",
        "figure",
        "support",
        "supporting",
        "dataset",
        "result",
        "finding",
        "claim",
        "basis",
    ]

    reference_columns = detect_columns_by_keywords(
        df,
        reference_keywords,
    )

    if not reference_columns:
        reference_columns = [
            col
            for col in df.columns
            if (
                pd.api.types.is_object_dtype(df[col])
                or pd.api.types.is_string_dtype(df[col])
            )
        ]

    evidence_linked_rows = 0

    for _, row in df.iterrows():
        if row_contains_meaningful_evidence(
            row,
            reference_columns,
        ):
            evidence_linked_rows += 1

    claim_ready = (
        len(df) > 0
        and evidence_linked_rows > 0
    )

    return {
        "rows": len(df),
        "reference_columns": reference_columns,
        "evidence_linked_rows": evidence_linked_rows,
        "claim_ready": claim_ready,
    }


# =============================================================================
# HEADER
# =============================================================================

banner("E-WASTE ABM")

print("STEP 11: FINAL PROJECT QUALITY CONTROL & SUBMISSION READINESS")
print("FINAL COMPATIBLE VERSION - EVIDENCE MAP FIXED")

print("=" * 100)
print(f"Project root : {PROJECT_ROOT}")
print(f"Output       : {OUTPUT_DIR}")


# =============================================================================
# STEP 11.1 - REQUIRED UPSTREAM FILE INVENTORY
# =============================================================================

section("STEP 11.1 - UPSTREAM FILE INTEGRITY")

all_upstream = {}

all_upstream.update(
    {f"STEP 4 - {k}": v for k, v in STEP04_FILES.items()}
)

all_upstream.update(
    {f"STEP 5 - {k}": v for k, v in STEP05_FILES.items()}
)

all_upstream.update(
    {f"STEP 6 - {k}": v for k, v in STEP06_FILES.items()}
)

all_upstream.update(
    {f"STEP 7 - {k}": v for k, v in STEP07_FILES.items()}
)

all_upstream.update(
    {f"STEP 8 - {k}": v for k, v in STEP08_FILES.items()}
)

all_upstream.update(
    {f"STEP 9 - {k}": v for k, v in STEP09_FILES.items()}
)

all_upstream.update(
    {f"STEP 10 - {k}": v for k, v in STEP10_FILES.items()}
)


integrity_rows = []

for label, path in all_upstream.items():

    exists = path.exists() and path.is_file()

    check(
        "File integrity",
        f"{label}: {path}",
        exists,
    )

    integrity_rows.append(
        {
            "Step": label.split(" - ")[0],
            "File": label,
            "Path": str(path),
            "Exists": exists,
            "Size (bytes)": path.stat().st_size if exists else 0,
        }
    )


save_df(
    pd.DataFrame(integrity_rows),
    TABLE_DIR / "01_upstream_file_integrity.csv",
)


# =============================================================================
# STEP 11.2 - LOAD AUTHORITATIVE DATA
# =============================================================================

section("STEP 11.2 - LOADING AUTHORITATIVE DATA")

load_errors = []


def load_authoritative(label, path):

    try:
        return pd.read_csv(path)

    except Exception as exc:

        load_errors.append(
            f"{label}: {exc}"
        )

        return pd.DataFrame()


master = load_authoritative(
    "STEP 7 Master Dataset",
    STEP07_FILES["Master dataset"],
)

rep_master = load_authoritative(
    "STEP 7 Replicate Master",
    STEP07_FILES["Replicate master"],
)

s8_scenario = load_authoritative(
    "STEP 8 Scenario Evidence",
    STEP08_FILES["Scenario evidence"],
)

s8_rep = load_authoritative(
    "STEP 8 Replicate Evidence",
    STEP08_FILES["Replicate evidence"],
)

s8_base = load_authoritative(
    "STEP 8 Baseline Interventions",
    STEP08_FILES["Baseline interventions"],
)

s8_sens = load_authoritative(
    "STEP 8 Sensitivity Evidence",
    STEP08_FILES["Sensitivity evidence"],
)

s8_val = load_authoritative(
    "STEP 8 Validation Evidence",
    STEP08_FILES["Validation evidence"],
)

s8_map = load_authoritative(
    "STEP 8 Evidence Map",
    STEP08_FILES["Evidence map"],
)

s9_scenario = load_authoritative(
    "STEP 9 Scenario Results",
    STEP09_FILES["Scenario results"],
)

s9_base = load_authoritative(
    "STEP 9 Baseline Effects",
    STEP09_FILES["Baseline effects"],
)

s9_stat = load_authoritative(
    "STEP 9 Statistical Evidence",
    STEP09_FILES["Statistical evidence"],
)

s9_effect = load_authoritative(
    "STEP 9 Effect Sizes",
    STEP09_FILES["Effect sizes"],
)

s9_sens = load_authoritative(
    "STEP 9 Sensitivity",
    STEP09_FILES["Sensitivity"],
)

s9_val = load_authoritative(
    "STEP 9 Validation",
    STEP09_FILES["Validation"],
)

s9_key = load_authoritative(
    "STEP 9 Key Findings",
    STEP09_FILES["Key findings"],
)

s9_map = load_authoritative(
    "STEP 9 Evidence Map",
    STEP09_FILES["Evidence map"],
)

s10_pub = load_authoritative(
    "STEP 10 Publication Results",
    STEP10_FILES["Publication results"],
)

s10_scenario = load_authoritative(
    "STEP 10 Scenario Interpretation",
    STEP10_FILES["Scenario interpretation"],
)

s10_base = load_authoritative(
    "STEP 10 Baseline Evidence",
    STEP10_FILES["Baseline evidence"],
)

s10_stat = load_authoritative(
    "STEP 10 Statistical Evidence",
    STEP10_FILES["Statistical evidence"],
)

s10_stat_int = load_authoritative(
    "STEP 10 Statistical Interpretation",
    STEP10_FILES["Statistical interpretation"],
)

s10_effect = load_authoritative(
    "STEP 10 Effect Size Evidence",
    STEP10_FILES["Effect size evidence"],
)

s10_effect_int = load_authoritative(
    "STEP 10 Effect Size Interpretation",
    STEP10_FILES["Effect size interpretation"],
)

s10_sens = load_authoritative(
    "STEP 10 Sensitivity Evidence",
    STEP10_FILES["Sensitivity evidence"],
)

s10_val = load_authoritative(
    "STEP 10 Validation Evidence",
    STEP10_FILES["Validation evidence"],
)

s10_key = load_authoritative(
    "STEP 10 Key Findings",
    STEP10_FILES["Key findings"],
)

s10_map = load_authoritative(
    "STEP 10 Evidence Map",
    STEP10_FILES["Evidence map"],
)

s10_claim = load_authoritative(
    "STEP 10 Claim-to-Evidence",
    STEP10_FILES["Claim-to-Evidence"],
)

s10_numeric = load_authoritative(
    "STEP 10 Numeric Highlights",
    STEP10_FILES["Numeric highlights"],
)


check(
    "Authoritative data loading",
    "All critical CSV files readable",
    len(load_errors) == 0,
    warning=False if len(load_errors) == 0 else False,
)


for err in load_errors:
    print(f"  LOAD ERROR: {err}")


print(f"Master dataset rows       : {len(master)}")
print(f"Master dataset columns    : {len(master.columns)}")
print(f"Replicate master rows     : {len(rep_master)}")
print(f"STEP 8 scenario rows      : {len(s8_scenario)}")
print(f"STEP 9 scenario rows      : {len(s9_scenario)}")
print(f"STEP 10 publication rows  : {len(s10_pub)}")


# =============================================================================
# STEP 11.3 - MASTER DATASET QUALITY
# =============================================================================

section("STEP 11.3 - MASTER DATASET QUALITY CONTROL")

missing_core = [
    c for c in CORE_COLUMNS
    if c not in master.columns
]

check(
    "Master core columns",
    "All 12 core columns available"
    if not missing_core
    else f"Missing={missing_core}",
    not missing_core,
)


duplicate_columns = (
    master.columns[
        master.columns.duplicated()
    ].tolist()
)


check(
    "Master duplicate columns",
    "None"
    if not duplicate_columns
    else f"Duplicates={duplicate_columns}",
    not duplicate_columns,
)


scenario_values = (
    unique_nonempty(master["Scenario"])
    if "Scenario" in master.columns
    else []
)


missing_scenarios = [
    s
    for s in EXPECTED_SCENARIOS
    if s not in scenario_values
]


unexpected_scenarios = [
    s
    for s in scenario_values
    if s not in EXPECTED_SCENARIOS
]


check(
    "Scenario completeness",
    "All six expected scenarios detected"
    if not missing_scenarios
    else f"Missing={missing_scenarios}",
    not missing_scenarios,
)


check(
    "Scenario labels",
    "No unexpected scenario labels"
    if not unexpected_scenarios
    else f"Unexpected={unexpected_scenarios}",
    not unexpected_scenarios,
)


bad_numeric = finite_numeric(
    master,
    NUMERIC_MASTER_COLUMNS,
)


check(
    "Master numeric integrity",
    "All required numeric fields finite"
    if not bad_numeric
    else f"Invalid={bad_numeric}",
    not bad_numeric,
)


save_df(
    pd.DataFrame(
        [
            {
                "Check": "Core columns",
                "Status": "PASS"
                if not missing_core
                else "FAIL",
                "Detail": str(missing_core)
                if missing_core
                else "All 12 available",
            },
            {
                "Check": "Duplicate columns",
                "Status": "PASS"
                if not duplicate_columns
                else "FAIL",
                "Detail": str(duplicate_columns)
                if duplicate_columns
                else "None",
            },
            {
                "Check": "Scenario completeness",
                "Status": "PASS"
                if not missing_scenarios
                else "FAIL",
                "Detail": str(missing_scenarios)
                if missing_scenarios
                else "6/6",
            },
            {
                "Check": "Unexpected scenarios",
                "Status": "PASS"
                if not unexpected_scenarios
                else "FAIL",
                "Detail": str(unexpected_scenarios)
                if unexpected_scenarios
                else "None",
            },
            {
                "Check": "Numeric integrity",
                "Status": "PASS"
                if not bad_numeric
                else "FAIL",
                "Detail": str(bad_numeric)
                if bad_numeric
                else "All finite",
            },
        ]
    ),
    TABLE_DIR / "02_master_quality_control.csv",
)


# =============================================================================
# STEP 11.4 - REPLICATION CONSISTENCY
# =============================================================================

section("STEP 11.4 - CROSS-STEP REPLICATION CONSISTENCY")

replication_rows = []


if (
    not master.empty
    and {"Scenario", "Replicate", "Period"}.issubset(
        master.columns
    )
):

    grouped = master.groupby("Scenario")

    for scenario in EXPECTED_SCENARIOS:

        if scenario not in grouped.groups:
            continue

        subset = grouped.get_group(scenario)

        reps = subset["Replicate"].nunique()
        periods = subset["Period"].nunique()
        rows = len(subset)

        passed = (
            reps == 30
            and periods == 12
            and rows == 360
        )

        check(
            "Replication structure",
            f"{scenario} | "
            f"Replicates={reps} | "
            f"Periods={periods} | "
            f"Rows={rows}",
            passed,
        )

        replication_rows.append(
            {
                "Scenario": scenario,
                "Replicates": reps,
                "Periods": periods,
                "Rows": rows,
                "Expected Replicates": 30,
                "Expected Periods": 12,
                "Expected Rows": 360,
                "Status": "PASS"
                if passed
                else "FAIL",
            }
        )


save_df(
    pd.DataFrame(replication_rows),
    TABLE_DIR / "03_replication_consistency.csv",
)


# =============================================================================
# STEP 11.5 - MASS BALANCE AND PHYSICAL CONSISTENCY
# =============================================================================

section("STEP 11.5 - MASS BALANCE & PHYSICAL CONSISTENCY")

physical_rows = []


if not master.empty:

    required_physical = [
        "Generated E-waste (kg)",
        "Formal E-waste (kg)",
        "Informal E-waste (kg)",
        "Recovered Material (kg)",
        "Residual Waste (kg)",
        "Ending Inventory (kg)",
    ]

    available = [
        c
        for c in required_physical
        if c in master.columns
    ]

    nonnegative_failures = {}

    for col in available:

        vals = pd.to_numeric(
            master[col],
            errors="coerce",
        )

        minimum = vals.min()

        passed = bool(
            (vals >= -1e-9).all()
        )

        if not passed:
            nonnegative_failures[col] = minimum

        physical_rows.append(
            {
                "Validation": "Non-negative",
                "Metric": col,
                "Minimum": minimum,
                "Maximum": vals.max(),
                "Status": "PASS"
                if passed
                else "FAIL",
            }
        )

    source_error = (
        master["Generated E-waste (kg)"]
        - master["Formal E-waste (kg)"]
        - master["Informal E-waste (kg)"]
    ).abs().max()

    process_error = (
        (
            master["Collected (kg)"]
            - master["Recovered Material (kg)"]
            - master["Residual Waste (kg)"]
        ).abs().max()
        if "Collected (kg)" in master.columns
        else 0.0
    )

    check(
        "Source mass balance",
        f"Maximum error={source_error:.12f} kg",
        source_error <= 1e-8,
    )

    check(
        "Processing/recycling mass balance",
        f"Maximum error={process_error:.12f} kg",
        process_error <= 1e-8,
    )

    collection_rate = pd.to_numeric(
        master["Collection Rate (%)"],
        errors="coerce",
    )

    recovery_rate = pd.to_numeric(
        master["Recovery Rate (%)"],
        errors="coerce",
    )

    participation = pd.to_numeric(
        master["Formal Participation (%)"],
        errors="coerce",
    )

    range_checks = [
        (
            "Collection Rate (%)",
            collection_rate,
            0,
            100,
        ),
        (
            "Recovery Rate (%)",
            recovery_rate,
            0,
            100,
        ),
        (
            "Formal Participation (%)",
            participation,
            0,
            100,
        ),
    ]

    for name, vals, low, high in range_checks:

        passed = bool(
            ((vals >= low) & (vals <= high)).all()
        )

        check(
            "Physical range",
            f"{name}: "
            f"min={vals.min():.6f}, "
            f"max={vals.max():.6f}",
            passed,
        )

    if nonnegative_failures:

        for col, minimum in nonnegative_failures.items():

            check(
                "Non-negative physical value",
                f"{col}: minimum={minimum}",
                False,
            )


save_df(
    pd.DataFrame(physical_rows),
    TABLE_DIR / "04_physical_consistency.csv",
)


# =============================================================================
# STEP 11.6 - SCENARIO CROSS-STEP NUMERICAL CONSISTENCY
# =============================================================================

section("STEP 11.6 - CROSS-STEP SCENARIO NUMERICAL CONSISTENCY")

scenario_consistency_rows = []


def scenario_metric(
    df,
    scenario_col="Scenario",
    metric=None,
):

    if (
        df.empty
        or scenario_col not in df.columns
        or metric not in df.columns
    ):
        return {}

    out = {}

    for scenario, subset in df.groupby(
        scenario_col
    ):

        vals = pd.to_numeric(
            subset[metric],
            errors="coerce",
        ).dropna()

        if len(vals):
            out[str(scenario)] = float(
                vals.mean()
            )

    return out


master_recovered = scenario_metric(
    master,
    metric="Recovered Material (kg)",
)

s8_recovered = scenario_metric(
    s8_scenario,
    metric="Recovered Material (kg)",
)

s9_recovered = scenario_metric(
    s9_scenario,
    metric="Recovered Material (kg)",
)

s10_recovered = scenario_metric(
    s10_pub,
    metric="Recovered Material (kg)",
)


for scenario in EXPECTED_SCENARIOS:

    vals = {
        "STEP7 Master":
            master_recovered.get(scenario),

        "STEP8":
            s8_recovered.get(scenario),

        "STEP9":
            s9_recovered.get(scenario),

        "STEP10":
            s10_recovered.get(scenario),
    }

    numeric_vals = [
        v
        for v in vals.values()
        if v is not None
        and math.isfinite(v)
    ]

    if len(numeric_vals) >= 2:

        spread = (
            max(numeric_vals)
            - min(numeric_vals)
        )

        passed = spread <= 1e-6

        detail = (
            f"Recovered mean spread="
            f"{spread:.12f} kg"
        )

    else:

        passed = True
        spread = 0.0

        detail = (
            "Insufficient directly comparable "
            "fields; no contradiction detected"
        )

        check(
            "Scenario numeric comparability",
            f"{scenario} | {detail}",
            True,
            warning=True,
        )

    if len(numeric_vals) >= 2:

        check(
            "Scenario numeric consistency",
            f"{scenario} | {detail}",
            passed,
        )

    scenario_consistency_rows.append(
        {
            "Scenario": scenario,
            "STEP7 Recovered Mean":
                vals["STEP7 Master"],
            "STEP8 Recovered Mean":
                vals["STEP8"],
            "STEP9 Recovered Mean":
                vals["STEP9"],
            "STEP10 Recovered Mean":
                vals["STEP10"],
            "Spread": spread,
            "Status": "PASS"
            if passed
            else "FAIL",
        }
    )


save_df(
    pd.DataFrame(
        scenario_consistency_rows
    ),
    TABLE_DIR /
    "05_cross_step_scenario_consistency.csv",
)


# =============================================================================
# STEP 11.7 - SENSITIVITY CONSISTENCY
# =============================================================================

section("STEP 11.7 - SENSITIVITY & ROBUSTNESS CONSISTENCY")

sensitivity_label_candidates = [
    "Parameter Label",
    "Parameter",
    "Parameter Name",
]

rank_candidates = [
    "Sensitivity Rank",
    "Rank",
]

elasticity_candidates = [
    "Elasticity",
]


sens_label_col = first_numeric_column(
    s10_sens,
    sensitivity_label_candidates,
)

sens_rank_col = first_numeric_column(
    s10_sens,
    rank_candidates,
)

sens_elasticity_col = first_numeric_column(
    s10_sens,
    elasticity_candidates,
)


for c in sensitivity_label_candidates:

    if c in s10_sens.columns:
        sens_label_col = c
        break


for c in rank_candidates:

    if c in s10_sens.columns:
        sens_rank_col = c
        break


for c in elasticity_candidates:

    if c in s10_sens.columns:
        sens_elasticity_col = c
        break


sensitivity_ok = False
highest_parameter = None
highest_elasticity = None


if (
    sens_label_col
    and sens_rank_col
    and not s10_sens.empty
):

    temp = s10_sens.copy()

    temp["_rank"] = pd.to_numeric(
        temp[sens_rank_col],
        errors="coerce",
    )

    temp = temp.dropna(
        subset=["_rank"]
    )

    if not temp.empty:

        top = (
            temp
            .sort_values("_rank")
            .iloc[0]
        )

        highest_parameter = str(
            top[sens_label_col]
        )

        if sens_elasticity_col:

            highest_elasticity = pd.to_numeric(
                top[sens_elasticity_col],
                errors="coerce",
            )

            highest_elasticity = (
                float(highest_elasticity)
                if pd.notna(highest_elasticity)
                else None
            )

        sensitivity_ok = (
            len(temp) == 7
        )


check(
    "Sensitivity parameter count",
    f"Detected={len(s10_sens)}; Expected=7",
    len(s10_sens) == 7,
)


check(
    "Sensitivity ranking",
    f"Highest-ranked parameter="
    f"{highest_parameter}"
    if highest_parameter
    else "Ranking not detectable",
    sensitivity_ok
    and highest_parameter is not None,
)


save_df(
    pd.DataFrame(
        [
            {
                "Detected Parameters":
                    len(s10_sens),
                "Expected Parameters":
                    7,
                "Highest-ranked Parameter":
                    highest_parameter,
                "Highest-ranked Elasticity":
                    highest_elasticity,
                "Status":
                    "PASS"
                    if sensitivity_ok
                    else "FAIL",
            }
        ]
    ),
    TABLE_DIR /
    "06_sensitivity_consistency.csv",
)


# =============================================================================
# STEP 11.8 - STATISTICAL / EFFECT-SIZE EVIDENCE
# =============================================================================

section("STEP 11.8 - STATISTICAL & EFFECT-SIZE EVIDENCE")

stat_rows = len(s10_stat)
effect_rows = len(s10_effect)


check(
    "Statistical evidence",
    f"Rows={stat_rows}; "
    f"source STEP 9={len(s9_stat)}",
    stat_rows > 0
    and len(s9_stat) > 0,
)


check(
    "Effect-size evidence",
    f"Rows={effect_rows}; expected >= 1",
    effect_rows > 0,
)


scenario_in_stat = []


for df in [s9_stat, s10_stat]:

    if "Scenario" in df.columns:

        scenario_in_stat.extend(
            unique_nonempty(
                df["Scenario"]
            )
        )


scenario_in_stat = sorted(
    set(scenario_in_stat)
)


missing_stat_scenarios = [
    s
    for s in EXPECTED_SCENARIOS
    if s not in scenario_in_stat
]


check(
    "Statistical scenario coverage",
    "All scenarios represented"
    if not missing_stat_scenarios
    else f"Missing={missing_stat_scenarios}",
    not missing_stat_scenarios,
)


save_df(
    pd.DataFrame(
        [
            {
                "STEP9 Statistical Rows":
                    len(s9_stat),

                "STEP10 Statistical Rows":
                    len(s10_stat),

                "STEP9 Effect Size Rows":
                    len(s9_effect),

                "STEP10 Effect Size Rows":
                    len(s10_effect),

                "Missing Statistical Scenarios":
                    str(
                        missing_stat_scenarios
                    ),

                "Status":
                    "PASS"
                    if (
                        stat_rows > 0
                        and effect_rows > 0
                        and not missing_stat_scenarios
                    )
                    else "FAIL",
            }
        ]
    ),
    TABLE_DIR /
    "07_statistical_evidence_audit.csv",
)


# =============================================================================
# STEP 11.9 - VALIDATION CHAIN
# =============================================================================

section("STEP 11.9 - VALIDATION CHAIN AUDIT")

validation_failure_text = []


for df in [
    s8_val,
    s9_val,
    s10_val,
]:

    if df.empty:
        continue

    for col in df.columns:

        if (
            "status" in str(col).lower()
            or "result" in str(col).lower()
        ):

            vals = (
                df[col]
                .astype(str)
                .str.upper()
            )

            validation_failure_text.extend(
                vals[
                    vals.str.contains(
                        "FAIL",
                        na=False,
                    )
                ].tolist()
            )


report_texts = []


for path in [
    STEP06_FILES["Validation report"],
    STEP07_FILES["Consolidation report"],
    STEP08_FILES["Final report"],
    STEP09_FILES["Final report"],
    STEP10_FILES["Final report"],
]:

    if path.exists():

        try:

            report_texts.append(
                path.read_text(
                    encoding="utf-8",
                    errors="ignore",
                )
            )

        except Exception:
            pass


report_fail_mentions = sum(
    1
    for txt in report_texts
    if "STATUS : FAIL"
    in txt.upper()
)


validation_pass = (
    len(validation_failure_text) == 0
    and report_fail_mentions == 0
)


check(
    "Validation chain",
    f"Detected validation failures="
    f"{len(validation_failure_text)}; "
    f"report FAIL statuses="
    f"{report_fail_mentions}",
    validation_pass,
)


save_df(
    pd.DataFrame(
        [
            {
                "Validation failure entries":
                    len(validation_failure_text),

                "Reports with FAIL status":
                    report_fail_mentions,

                "Status":
                    "PASS"
                    if validation_pass
                    else "FAIL",
            }
        ]
    ),
    TABLE_DIR /
    "08_validation_chain_audit.csv",
)


# =============================================================================
# STEP 11.10 - EVIDENCE MAP & CLAIM AUDIT
# =============================================================================

section(
    "STEP 11.10 - EVIDENCE MAP & CLAIM-TO-EVIDENCE AUDIT"
)

# -------------------------------------------------------------------------
# NEW ROBUST EVIDENCE MAP AUDIT
# -------------------------------------------------------------------------

evidence_audit = audit_evidence_map(
    s10_map
)

evidence_map_count = evidence_audit["rows"]

ready_hits = evidence_audit[
    "ready_hits"
]

evidence_linked_rows = evidence_audit[
    "evidence_linked_rows"
]

status_positive_rows = evidence_audit[
    "status_positive_rows"
]

status_negative_rows = evidence_audit[
    "status_negative_rows"
]

direct_evidence_hits = evidence_audit[
    "direct_evidence_hits"
]

evidence_columns_detected = evidence_audit[
    "evidence_columns"
]

status_columns_detected = evidence_audit[
    "status_columns"
]

evidence_coverage_ratio = evidence_audit[
    "evidence_coverage_ratio"
]

evidence_ready = evidence_audit[
    "evidence_ready"
]


# -------------------------------------------------------------------------
# NEW ROBUST CLAIM-TO-EVIDENCE AUDIT
# -------------------------------------------------------------------------

claim_audit = audit_claim_matrix(
    s10_claim
)

claim_count = claim_audit[
    "rows"
]

evidence_ref_hits = claim_audit[
    "evidence_linked_rows"
]

claim_reference_columns = claim_audit[
    "reference_columns"
]

claim_ready = claim_audit[
    "claim_ready"
]


# -------------------------------------------------------------------------
# Print diagnostic information
# -------------------------------------------------------------------------

print(
    f"Evidence Map rows                : "
    f"{evidence_map_count}"
)

print(
    f"Evidence-linked rows             : "
    f"{evidence_linked_rows}"
)

print(
    f"Evidence coverage                : "
    f"{evidence_coverage_ratio:.2%}"
)

print(
    f"Positive status rows             : "
    f"{status_positive_rows}"
)

print(
    f"Negative status rows             : "
    f"{status_negative_rows}"
)

print(
    f"Direct evidence keyword hits     : "
    f"{direct_evidence_hits}"
)

print(
    f"Detected evidence columns       : "
    f"{evidence_columns_detected}"
)

print(
    f"Detected status columns         : "
    f"{status_columns_detected}"
)

print(
    f"Claim-to-evidence rows           : "
    f"{claim_count}"
)

print(
    f"Claim evidence-linked rows       : "
    f"{evidence_ref_hits}"
)

print(
    f"Detected claim reference columns : "
    f"{claim_reference_columns}"
)


# -------------------------------------------------------------------------
# IMPORTANT:
# The old logic was:
#
#     evidence_map_count >= 8
#     AND ready_hits >= 8
#
# That was too strict.
#
# The new logic relies on actual evidence linkage and coverage.
# -------------------------------------------------------------------------

if evidence_ready:

    evidence_detail = (
        f"Rows={evidence_map_count}; "
        f"evidence-linked rows={evidence_linked_rows}; "
        f"coverage={evidence_coverage_ratio:.1%}; "
        f"positive status rows={status_positive_rows}; "
        f"negative status rows={status_negative_rows}"
    )

else:

    evidence_detail = (
        f"Rows={evidence_map_count}; "
        f"evidence-linked rows={evidence_linked_rows}; "
        f"coverage={evidence_coverage_ratio:.1%}; "
        f"positive status rows={status_positive_rows}; "
        f"negative status rows={status_negative_rows}"
    )


check(
    "Evidence map completeness",
    evidence_detail,
    evidence_ready,
)


claim_detail = (
    f"Rows={claim_count}; "
    f"evidence-linked rows={evidence_ref_hits}"
)


check(
    "Claim-to-evidence matrix",
    claim_detail,
    claim_ready,
)


# -------------------------------------------------------------------------
# Preserve the original output filename.
# Add diagnostic fields without removing the original fields.
# -------------------------------------------------------------------------

save_df(
    pd.DataFrame(
        [
            {
                "Evidence map rows":
                    evidence_map_count,

                "Ready indicators":
                    ready_hits,

                "Evidence-linked rows":
                    evidence_linked_rows,

                "Evidence coverage (%)":
                    evidence_coverage_ratio * 100,

                "Positive status rows":
                    status_positive_rows,

                "Negative status rows":
                    status_negative_rows,

                "Direct evidence keyword hits":
                    direct_evidence_hits,

                "Detected evidence columns":
                    "; ".join(
                        map(
                            str,
                            evidence_columns_detected,
                        )
                    ),

                "Detected status columns":
                    "; ".join(
                        map(
                            str,
                            status_columns_detected,
                        )
                    ),

                "Evidence map status":
                    "PASS"
                    if evidence_ready
                    else "FAIL",

                "Claim matrix rows":
                    claim_count,

                "Evidence-linked rows":
                    evidence_ref_hits,

                "Detected claim reference columns":
                    "; ".join(
                        map(
                            str,
                            claim_reference_columns,
                        )
                    ),

                "Claim matrix status":
                    "PASS"
                    if claim_ready
                    else "FAIL",
            }
        ]
    ),
    TABLE_DIR /
    "09_evidence_claim_audit.csv",
)


# =============================================================================
# STEP 11.11 - MANUSCRIPT PACKAGE AUDIT
# =============================================================================

section(
    "STEP 11.11 - MANUSCRIPT & PUBLICATION PACKAGE AUDIT"
)


manuscript_required = {
    "STEP 9 manuscript DOCX":
        STEP09_FILES["Manuscript DOCX"],

    "STEP 10 final manuscript DOCX":
        STEP10_FILES["Final manuscript DOCX"],

    "STEP 10 Results & Discussion":
        STEP10_FILES["Results & discussion"],

    "STEP 10 Conclusion":
        STEP10_FILES["Conclusion"],

    "STEP 10 Limitations":
        STEP10_FILES["Limitations"],

    "STEP 10 Captions":
        STEP10_FILES["Captions"],

    "STEP 8 publication workbook":
        STEP08_FILES["Publication workbook"],
}


manuscript_rows = []


for label, path in manuscript_required.items():

    exists = (
        path.exists()
        and path.is_file()
        and path.stat().st_size > 0
    )

    check(
        "Manuscript package",
        f"{label}: {path}",
        exists,
    )

    manuscript_rows.append(
        {
            "Artifact": label,
            "Path": str(path),
            "Exists": exists,
            "Size (bytes)":
                path.stat().st_size
                if exists
                else 0,
        }
    )


save_df(
    pd.DataFrame(manuscript_rows),
    TABLE_DIR /
    "10_manuscript_package_audit.csv",
)


# =============================================================================
# STEP 11.12 - FIGURE PACKAGE AUDIT
# =============================================================================

section("STEP 11.12 - FIGURE PACKAGE AUDIT")

figure_paths = []


for step_dir in [
    PROJECT_ROOT / "results_step07/figures",
    PROJECT_ROOT / "results_step08/figures",
    PROJECT_ROOT / "results_step09/figures",
    PROJECT_ROOT / "results_step10/figures",
]:

    if step_dir.exists():

        figure_paths.extend(
            sorted(
                step_dir.glob("*.png")
            )
        )


figure_rows = []


for path in figure_paths:

    valid = (
        path.exists()
        and path.stat().st_size > 0
    )

    figure_rows.append(
        {
            "Figure": path.name,
            "Source folder":
                str(path.parent),
            "Size (bytes)":
                path.stat().st_size
                if valid
                else 0,
            "Status":
                "PASS"
                if valid
                else "FAIL",
        }
    )


check(
    "Figure package",
    f"Valid PNG figures={len(figure_rows)}",
    len(figure_rows) >= 4,
)


save_df(
    pd.DataFrame(figure_rows),
    TABLE_DIR /
    "11_figure_package_audit.csv",
)


# =============================================================================
# STEP 11.13 - REPRODUCIBILITY AUDIT
# =============================================================================

section("STEP 11.13 - REPRODUCIBILITY READINESS")

reproducibility_items = [

    (
        "STEP 0 parameter JSON",
        PROJECT_ROOT /
        "results_step00/ABM_PARAMETER_CONFIG.json",
    ),

    (
        "STEP 0 base parameters",
        PROJECT_ROOT /
        "results_step00/ABM_BASE_PARAMETERS.csv",
    ),

    (
        "STEP 0 scenario parameters",
        PROJECT_ROOT /
        "results_step00/ABM_SCENARIO_PARAMETERS.csv",
    ),

    (
        "STEP 1 agent specification",
        PROJECT_ROOT /
        "results_step01/STEP01_AGENT_SPECIFICATION.csv",
    ),

    (
        "STEP 1 agent parameters",
        PROJECT_ROOT /
        "results_step01/STEP01_AGENT_PARAMETERS.csv",
    ),

    (
        "STEP 2 raw simulation",
        PROJECT_ROOT /
        "results_step02/STEP02_RAW_SIMULATION_RESULTS.csv",
    ),
]


repro_rows = []


for label, path in reproducibility_items:

    exists = (
        path.exists()
        and path.is_file()
    )

    check(
        "Reproducibility input",
        f"{label}: {path}",
        exists,
    )

    repro_rows.append(
        {
            "Artifact": label,
            "Path": str(path),
            "Available": exists,
        }
    )


repro_ok = all(
    x["Available"]
    for x in repro_rows
)


save_df(
    pd.DataFrame(repro_rows),
    TABLE_DIR /
    "12_reproducibility_audit.csv",
)


# =============================================================================
# STEP 11.14 - FINAL NUMERIC HIGHLIGHTS
# =============================================================================

section("STEP 11.14 - FINAL NUMERIC HIGHLIGHTS")

numeric_highlights = []


if not s10_pub.empty:

    for _, row in s10_pub.iterrows():

        record = {
            "Scenario":
                row.get(
                    "Scenario",
                    "",
                )
        }

        for col in [
            "Recovered Material (kg)",
            "Collection Rate (%)",
            "Formal Participation (%)",
            "System Cost (USD)",
            "Recovery Rate (%)",
        ]:

            if col in s10_pub.columns:

                value = pd.to_numeric(
                    pd.Series(
                        [row[col]]
                    ),
                    errors="coerce",
                ).iloc[0]

                record[col] = (
                    float(value)
                    if pd.notna(value)
                    else None
                )

        numeric_highlights.append(
            record
        )


if numeric_highlights:

    final_numeric_df = pd.DataFrame(
        numeric_highlights
    )

else:

    final_numeric_df = pd.DataFrame(
        columns=[
            "Scenario",
            "Recovered Material (kg)",
            "Collection Rate (%)",
        ]
    )


save_df(
    final_numeric_df,
    TABLE_DIR /
    "13_final_numeric_highlights.csv",
)


if (
    not final_numeric_df.empty
    and "Recovered Material (kg)"
    in final_numeric_df.columns
):

    temp = final_numeric_df.dropna(
        subset=[
            "Recovered Material (kg)"
        ]
    )

    if not temp.empty:

        best_row = temp.loc[
            temp[
                "Recovered Material (kg)"
            ].idxmax()
        ]

        check(
            "Highest recovered material",
            f"{best_row['Scenario']} = "
            f"{best_row['Recovered Material (kg)']:.6f} kg",
            True,
        )


# =============================================================================
# STEP 11.15 - FINAL SUBMISSION PACKAGE
# =============================================================================

section(
    "STEP 11.15 - BUILDING FINAL SUBMISSION PACKAGE"
)


if PACKAGE_DIR.exists():

    for item in PACKAGE_DIR.iterdir():

        if item.is_dir():
            shutil.rmtree(item)

        else:
            item.unlink()


package_subdirs = [
    PACKAGE_DIR / "01_RESULTS_TABLES",
    PACKAGE_DIR / "02_FIGURES",
    PACKAGE_DIR / "03_MANUSCRIPT",
    PACKAGE_DIR / "04_VALIDATION",
    PACKAGE_DIR / "05_REPRODUCIBILITY",
]


for d in package_subdirs:
    d.mkdir(
        parents=True,
        exist_ok=True,
    )


package_manifest = []


# Tables
for path in sorted(
    (
        PROJECT_ROOT /
        "results_step10/tables"
    ).glob("*.csv")
):

    destination = (
        PACKAGE_DIR /
        "01_RESULTS_TABLES" /
        path.name
    )

    if copy_if_exists(
        path,
        destination,
    ):

        package_manifest.append(
            {
                "Category":
                    "Results tables",
                "Source":
                    str(path),
                "Package path":
                    str(destination),
            }
        )


# Figures
for source_dir in [
    PROJECT_ROOT /
    "results_step10/figures",

    PROJECT_ROOT /
    "results_step09/figures",

    PROJECT_ROOT /
    "results_step08/figures",
]:

    if source_dir.exists():

        for path in sorted(
            source_dir.glob("*.png")
        ):

            destination = (
                PACKAGE_DIR /
                "02_FIGURES" /
                f"{source_dir.parent.name}_"
                f"{path.name}"
            )

            if copy_if_exists(
                path,
                destination,
            ):

                package_manifest.append(
                    {
                        "Category":
                            "Figures",
                        "Source":
                            str(path),
                        "Package path":
                            str(destination),
                    }
                )


# Manuscripts and reports
for label, path in {

    "STEP10 Final manuscript":
        STEP10_FILES[
            "Final manuscript DOCX"
        ],

    "STEP9 Manuscript":
        STEP09_FILES[
            "Manuscript DOCX"
        ],

    "STEP10 Results Discussion":
        STEP10_FILES[
            "Results & discussion"
        ],

    "STEP10 Conclusion":
        STEP10_FILES[
            "Conclusion"
        ],

    "STEP10 Limitations":
        STEP10_FILES[
            "Limitations"
        ],

    "STEP10 Captions":
        STEP10_FILES[
            "Captions"
        ],

}.items():

    destination = (
        PACKAGE_DIR /
        "03_MANUSCRIPT" /
        path.name
    )

    if copy_if_exists(
        path,
        destination,
    ):

        package_manifest.append(
            {
                "Category":
                    "Manuscript",
                "Source":
                    str(path),
                "Package path":
                    str(destination),
            }
        )


# Validation artifacts
for label, path in {

    "STEP6 report":
        STEP06_FILES[
            "Validation report"
        ],

    "STEP7 report":
        STEP07_FILES[
            "Consolidation report"
        ],

    "STEP8 report":
        STEP08_FILES[
            "Final report"
        ],

    "STEP9 report":
        STEP09_FILES[
            "Final report"
        ],

    "STEP10 report":
        STEP10_FILES[
            "Final report"
        ],

}.items():

    destination = (
        PACKAGE_DIR /
        "04_VALIDATION" /
        path.name
    )

    if copy_if_exists(
        path,
        destination,
    ):

        package_manifest.append(
            {
                "Category":
                    "Validation",
                "Source":
                    str(path),
                "Package path":
                    str(destination),
            }
        )


# Reproducibility
for label, path in reproducibility_items:

    destination = (
        PACKAGE_DIR /
        "05_REPRODUCIBILITY" /
        path.name
    )

    if copy_if_exists(
        path,
        destination,
    ):

        package_manifest.append(
            {
                "Category":
                    "Reproducibility",
                "Source":
                    str(path),
                "Package path":
                    str(destination),
            }
        )


package_manifest_df = pd.DataFrame(
    package_manifest
)


save_df(
    package_manifest_df,
    TABLE_DIR /
    "14_final_submission_package_manifest.csv",
)


package_count = len(
    package_manifest_df
)


check(
    "Submission package",
    f"Artifacts packaged={package_count}",
    package_count >= 10,
)


# =============================================================================
# STEP 11.16 - FINAL CHECKLIST
# =============================================================================

section(
    "STEP 11.16 - FINAL SUBMISSION CHECKLIST"
)


checklist = [

    (
        "Upstream files",
        all(
            p.exists()
            for p in all_upstream.values()
        ),
    ),

    (
        "Master dataset",
        not master.empty
        and not missing_core
        and not duplicate_columns,
    ),

    (
        "Six scenarios",
        len(scenario_values) == 6
        and not missing_scenarios
        and not unexpected_scenarios,
    ),

    (
        "30 replicates/scenario",
        all(
            x["Replicates"] == 30
            for x in replication_rows
        )
        if replication_rows
        else False,
    ),

    (
        "12 periods/scenario",
        all(
            x["Periods"] == 12
            for x in replication_rows
        )
        if replication_rows
        else False,
    ),

    (
        "Mass balance",
        bool(
            not master.empty
            and source_error <= 1e-8
            and process_error <= 1e-8
        ),
    ),

    (
        "Sensitivity",
        sensitivity_ok,
    ),

    (
        "Validation chain",
        validation_pass,
    ),

    (
        "Evidence map",
        evidence_ready,
    ),

    (
        "Claim-to-evidence",
        claim_ready,
    ),

    (
        "Manuscript package",
        all(
            x["Exists"]
            for x in manuscript_rows
        ),
    ),

    (
        "Figures",
        len(figure_rows) >= 4,
    ),

    (
        "Reproducibility",
        repro_ok,
    ),

    (
        "Submission package",
        package_count >= 10,
    ),
]


checklist_rows = []


for item, passed in checklist:

    check(
        "Final checklist",
        item,
        passed,
    )

    checklist_rows.append(
        {
            "Checklist item": item,
            "Status":
                "PASS"
                if passed
                else "FAIL",
        }
    )


save_df(
    pd.DataFrame(checklist_rows),
    TABLE_DIR /
    "15_final_submission_checklist.csv",
)


# =============================================================================
# STEP 11.17 - FINAL QUALITY CONTROL MATRIX
# =============================================================================

section(
    "STEP 11.17 - FINAL QUALITY CONTROL MATRIX"
)


final_pass = all(
    status == "PASS"
    for status in [
        r["Status"]
        for r in results
        if r["Status"] != "WARN"
    ]
)


final_pass = (
    final_pass
    and all(
        passed
        for _, passed in checklist
    )
)


matrix = [

    {
        "Domain":
            "Upstream integrity",
        "Requirement":
            "STEP 4-10 required artifacts available",
        "Status":
            "PASS"
            if all(
                p.exists()
                for p in all_upstream.values()
            )
            else "FAIL",
    },

    {
        "Domain":
            "Master dataset",
        "Requirement":
            "Core columns, duplicate columns, "
            "scenarios, numeric integrity",
        "Status":
            "PASS"
            if (
                not missing_core
                and not duplicate_columns
                and not missing_scenarios
                and not unexpected_scenarios
                and not bad_numeric
            )
            else "FAIL",
    },

    {
        "Domain":
            "Replication",
        "Requirement":
            "6 scenarios x 30 replicates x 12 periods",
        "Status":
            "PASS"
            if checklist[3][1]
            and checklist[4][1]
            else "FAIL",
    },

    {
        "Domain":
            "Physical logic",
        "Requirement":
            "Mass balance and physical ranges",
        "Status":
            "PASS"
            if checklist[5][1]
            else "FAIL",
    },

    {
        "Domain":
            "Statistics",
        "Requirement":
            "Statistical and effect-size evidence available",
        "Status":
            "PASS"
            if (
                stat_rows > 0
                and effect_rows > 0
                and not missing_stat_scenarios
            )
            else "FAIL",
    },

    {
        "Domain":
            "Sensitivity",
        "Requirement":
            "7 parameters and ranked sensitivity evidence",
        "Status":
            "PASS"
            if sensitivity_ok
            else "FAIL",
    },

    {
        "Domain":
            "Validation",
        "Requirement":
            "No upstream validation failure",
        "Status":
            "PASS"
            if validation_pass
            else "FAIL",
    },

    {
        "Domain":
            "Evidence",
        "Requirement":
            "Evidence map and claim-to-evidence matrix",
        "Status":
            "PASS"
            if evidence_ready
            and claim_ready
            else "FAIL",
    },

    {
        "Domain":
            "Manuscript",
        "Requirement":
            "DOCX, Results, Discussion, Conclusion, Limitations",
        "Status":
            "PASS"
            if all(
                x["Exists"]
                for x in manuscript_rows
            )
            else "FAIL",
    },

    {
        "Domain":
            "Figures",
        "Requirement":
            "Publication-ready figures available",
        "Status":
            "PASS"
            if len(figure_rows) >= 4
            else "FAIL",
    },

    {
        "Domain":
            "Reproducibility",
        "Requirement":
            "Parameter, agent and raw simulation inputs retained",
        "Status":
            "PASS"
            if repro_ok
            else "FAIL",
    },

    {
        "Domain":
            "Submission package",
        "Requirement":
            "Final package assembled",
        "Status":
            "PASS"
            if package_count >= 10
            else "FAIL",
    },
]


matrix_df = pd.DataFrame(
    matrix
)


save_df(
    matrix_df,
    TABLE_DIR /
    "16_final_quality_control_matrix.csv",
)


matrix_failures = int(
    (
        matrix_df["Status"]
        == "FAIL"
    ).sum()
)


check(
    "Final quality control matrix",
    f"Failures={matrix_failures}",
    matrix_failures == 0,
)


# =============================================================================
# STEP 11.18 - FINAL PROJECT REPORT
# =============================================================================

section(
    "STEP 11.18 - GENERATING FINAL PROJECT READINESS REPORT"
)


report_path = (
    OUTPUT_DIR /
    "STEP11_FINAL_PROJECT_READINESS_REPORT.txt"
)


report_lines = [

    "=" * 100,

    "E-WASTE ABM",

    "STEP 11: FINAL PROJECT QUALITY CONTROL & "
    "SUBMISSION READINESS",

    "=" * 100,

    "",

    f"Project root : {PROJECT_ROOT}",

    f"Generated    : "
    f"{datetime.now().isoformat(timespec='seconds')}",

    "",

    "PIPELINE STATUS",

    "-" * 100,

    "STEP 0  : PARAMETER DESIGN / CONFIGURATION",

    "STEP 1  : AGENT SPECIFICATION",

    "STEP 2  : MODEL IMPLEMENTATION & SCENARIO SIMULATION",

    "STEP 3  : INTERMEDIATE MODEL DEVELOPMENT",

    "STEP 4  : REPLICATION & STATISTICAL ANALYSIS",

    "STEP 5  : SENSITIVITY & ROBUSTNESS ANALYSIS",

    "STEP 6  : MODEL VALIDATION & CALIBRATION",

    "STEP 7  : OUTPUT CONSOLIDATION & EVIDENCE INTEGRATION",

    "STEP 8  : PUBLICATION PACKAGE & EVIDENCE READINESS",

    "STEP 9  : FINAL RESULTS & MANUSCRIPT INTEGRATION",

    "STEP 10 : RESULTS, DISCUSSION & CONCLUSION INTEGRATION",

    "STEP 11 : FINAL PROJECT QUALITY CONTROL",

    "",

    "DATASET SUMMARY",

    "-" * 100,

    f"Master dataset rows       : {len(master)}",

    f"Master dataset columns    : {len(master.columns)}",

    f"Replicate-level rows      : {len(rep_master)}",

    f"Scenarios analyzed        : {len(scenario_values)}",

    f"Sensitivity parameters    : {len(s10_sens)}",

    f"Statistical evidence rows : {len(s10_stat)}",

    f"Effect-size rows          : {len(s10_effect)}",

    f"Validation evidence rows  : {len(s10_val)}",

    f"Evidence map rows         : {len(s10_map)}",

    f"Claim-to-evidence rows    : {len(s10_claim)}",

    f"Figures available         : {len(figure_rows)}",

    f"Package artifacts         : {package_count}",

    "",

    "QUALITY CONTROL",

    "-" * 100,

    f"Upstream failures         : "
    f"{sum(not p.exists() for p in all_upstream.values())}",

    f"Validation failures       : "
    f"{len(validation_failure_text) + report_fail_mentions}",

    f"Checklist failures        : "
    f"{sum(not passed for _, passed in checklist)}",

    f"Matrix failures           : "
    f"{matrix_failures}",

    f"Warnings                  : "
    f"{warnings}",

    "",

    "KEY EVIDENCE",

    "-" * 100,

    f"Highest sensitivity parameter : "
    f"{highest_parameter}",

    f"Highest sensitivity elasticity: "
    f"{highest_elasticity}",

    f"Evidence map ready            : "
    f"{'YES' if evidence_ready else 'NO'}",

    f"Evidence-linked rows          : "
    f"{evidence_linked_rows}",

    f"Evidence coverage             : "
    f"{evidence_coverage_ratio:.2%}",

    f"Claim-to-evidence ready       : "
    f"{'YES' if claim_ready else 'NO'}",

    f"Reproducibility ready         : "
    f"{'YES' if repro_ok else 'NO'}",

    f"Manuscript package ready      : "
    f"{'YES' if all(x['Exists'] for x in manuscript_rows) else 'NO'}",

    "",

    "FINAL DECISION",

    "-" * 100,
]


if final_pass:

    report_lines.extend(
        [

            "FINAL PROJECT STATUS : PASS",

            "",

            "The E-WASTE ABM pipeline has passed "
            "the final quality-control audit.",

            "The project is ready for final thesis/"
            "journal manuscript preparation,",

            "submission formatting, supervisor review, "
            "or journal submission workflow.",
        ]
    )

else:

    report_lines.extend(
        [

            "FINAL PROJECT STATUS : FAIL",

            "",

            "One or more final quality-control "
            "requirements failed.",

            "Review STEP11 tables before using the "
            "package for final submission.",
        ]
    )


report_lines.extend(
    [

        "",

        "OUTPUT PACKAGE",

        "-" * 100,

        f"Tables      : {TABLE_DIR}",

        f"Figures     : {FIGURE_DIR}",

        f"Manuscript  : {MANUSCRIPT_DIR}",

        f"Submission  : {PACKAGE_DIR}",

        "",

        "=" * 100,
    ]
)


report_path.write_text(
    "\n".join(report_lines),
    encoding="utf-8",
)


print(
    f"[SAVED] {report_path}"
)


# =============================================================================
# STEP 11.19 - FINAL VALIDATION FILE
# =============================================================================

section(
    "STEP 11.19 - FINAL STEP 11 VALIDATION"
)


final_validation_rows = [

    {
        "Criterion":
            "Upstream files",
        "Status":
            "PASS"
            if all(
                p.exists()
                for p in all_upstream.values()
            )
            else "FAIL",
    },

    {
        "Criterion":
            "Master dataset",
        "Status":
            "PASS"
            if not master.empty
            else "FAIL",
    },

    {
        "Criterion":
            "Core columns",
        "Status":
            "PASS"
            if not missing_core
            else "FAIL",
    },

    {
        "Criterion":
            "Duplicate columns",
        "Status":
            "PASS"
            if not duplicate_columns
            else "FAIL",
    },

    {
        "Criterion":
            "Six scenarios",
        "Status":
            "PASS"
            if (
                len(scenario_values) == 6
                and not missing_scenarios
                and not unexpected_scenarios
            )
            else "FAIL",
    },

    {
        "Criterion":
            "30 replicates per scenario",
        "Status":
            "PASS"
            if checklist[3][1]
            else "FAIL",
    },

    {
        "Criterion":
            "12 periods per scenario",
        "Status":
            "PASS"
            if checklist[4][1]
            else "FAIL",
    },

    {
        "Criterion":
            "Mass balance",
        "Status":
            "PASS"
            if checklist[5][1]
            else "FAIL",
    },

    {
        "Criterion":
            "Statistical evidence",
        "Status":
            "PASS"
            if stat_rows > 0
            else "FAIL",
    },

    {
        "Criterion":
            "Sensitivity",
        "Status":
            "PASS"
            if sensitivity_ok
            else "FAIL",
    },

    {
        "Criterion":
            "Validation chain",
        "Status":
            "PASS"
            if validation_pass
            else "FAIL",
    },

    {
        "Criterion":
            "Evidence map",
        "Status":
            "PASS"
            if evidence_ready
            else "FAIL",
    },

    {
        "Criterion":
            "Claim-to-evidence",
        "Status":
            "PASS"
            if claim_ready
            else "FAIL",
    },

    {
        "Criterion":
            "Manuscript package",
        "Status":
            "PASS"
            if all(
                x["Exists"]
                for x in manuscript_rows
            )
            else "FAIL",
    },

    {
        "Criterion":
            "Figure package",
        "Status":
            "PASS"
            if len(figure_rows) >= 4
            else "FAIL",
    },

    {
        "Criterion":
            "Reproducibility",
        "Status":
            "PASS"
            if repro_ok
            else "FAIL",
    },

    {
        "Criterion":
            "Submission package",
        "Status":
            "PASS"
            if package_count >= 10
            else "FAIL",
    },

    {
        "Criterion":
            "Final project",
        "Status":
            "PASS"
            if final_pass
            else "FAIL",
    },
]


save_df(
    pd.DataFrame(
        final_validation_rows
    ),
    TABLE_DIR /
    "17_final_step11_validation.csv",
)


# =============================================================================
# FINAL SUMMARY
# =============================================================================

banner(
    "STEP 11 FINAL SUMMARY"
)


print(
    f"Scenarios analyzed        : "
    f"{len(scenario_values)}"
)

print(
    f"Master dataset rows       : "
    f"{len(master)}"
)

print(
    f"Master dataset columns    : "
    f"{len(master.columns)}"
)

print(
    f"Replicate-level rows      : "
    f"{len(rep_master)}"
)

print(
    f"Sensitivity parameters    : "
    f"{len(s10_sens)}"
)

print(
    f"Statistical evidence rows : "
    f"{len(s10_stat)}"
)

print(
    f"Evidence map rows         : "
    f"{len(s10_map)}"
)

print(
    f"Evidence-linked rows      : "
    f"{evidence_linked_rows}"
)

print(
    f"Evidence coverage         : "
    f"{evidence_coverage_ratio:.2%}"
)

print(
    f"Claim-to-evidence rows    : "
    f"{len(s10_claim)}"
)

print(
    f"Figures available         : "
    f"{len(figure_rows)}"
)

print(
    f"Submission artifacts      : "
    f"{package_count}"
)

print(
    f"Validation failures       : "
    f"{len(validation_failure_text) + report_fail_mentions}"
)

print(
    f"Checklist failures        : "
    f"{sum(not passed for _, passed in checklist)}"
)

print(
    f"Output folder             : "
    f"{OUTPUT_DIR}"
)

print(
    f"Tables folder             : "
    f"{TABLE_DIR}"
)

print(
    f"Figures folder            : "
    f"{FIGURE_DIR}"
)

print(
    f"Manuscript folder         : "
    f"{MANUSCRIPT_DIR}"
)

print(
    f"Submission package        : "
    f"{PACKAGE_DIR}"
)

print()


if final_pass:

    print("=" * 100)
    print("STEP 11 STATUS : PASS")
    print("=" * 100)
    print(
        "FINAL PROJECT READY FOR THESIS / "
        "JOURNAL SUBMISSION"
    )

    sys.exit(0)

else:

    print("=" * 100)
    print("STEP 11 STATUS : FAIL")
    print("=" * 100)
    print(
        "REVIEW results_step11 TABLES BEFORE "
        "FINAL SUBMISSION"
    )

    sys.exit(1)