r"""
E-WASTE ABM
STEP 9: FINAL RESULTS & MANUSCRIPT INTEGRATION
Compatible with STEP 0-8 outputs.

Input:
    results_step04/
    results_step05/
    results_step06/
    results_step07/
    results_step08/

Output:
    results_step09/
        STEP09_FINAL_RESULTS_REPORT.txt
        STEP09_MANUSCRIPT_RESULTS.docx
        tables/
        figures/

Run:
    python -m py_compile .\step09_final_results_manuscript_FINAL.py
    python .\step09_final_results_manuscript_FINAL.py
"""

from __future__ import annotations

import math
import re
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception:
    plt = None

# Load python-docx dynamically. This avoids false Pylance unresolved-import
# warnings when VS Code is pointing at a different interpreter than the terminal.
try:
    import importlib

    _docx = importlib.import_module("docx")
    _docx_shared = importlib.import_module("docx.shared")
    _docx_text = importlib.import_module("docx.enum.text")
    _docx_table = importlib.import_module("docx.enum.table")

    Document = _docx.Document
    Inches = _docx_shared.Inches
    Pt = _docx_shared.Pt
    WD_ALIGN_PARAGRAPH = _docx_text.WD_ALIGN_PARAGRAPH
    WD_TABLE_ALIGNMENT = _docx_table.WD_TABLE_ALIGNMENT
    DOCX_AVAILABLE = True
    DOCX_IMPORT_ERROR = ""
except Exception as exc:
    Document = None
    Inches = None
    Pt = None
    WD_ALIGN_PARAGRAPH = None
    WD_TABLE_ALIGNMENT = None
    DOCX_AVAILABLE = False
    DOCX_IMPORT_ERROR = str(exc)


# ---------------------------------------------------------------------
# PATHS
# ---------------------------------------------------------------------
ROOT = Path.cwd()
OUT = ROOT / "results_step09"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
OUT.mkdir(exist_ok=True)
TABLES.mkdir(exist_ok=True)
FIGURES.mkdir(exist_ok=True)

SCENARIOS = {
    0: "Baseline",
    1: "Scenario 1 - Formal-Informal Integration",
    2: "Scenario 2 - Economic Incentives",
    3: "Scenario 3 - Information & Traceability",
    4: "Scenario 4 - Producer Responsibility",
    5: "Scenario 5 - Combined Orchestration",
}
SCENARIO_ORDER = list(SCENARIOS.values())

CORE = [
    "Scenario", "Replicate", "Period", "Generated E-waste (kg)",
    "Formal E-waste (kg)", "Informal E-waste (kg)",
    "Recovered Material (kg)", "Residual Waste (kg)",
    "Collection Rate (%)", "Recovery Rate (%)",
    "Formal Participation (%)", "Ending Inventory (kg)",
]

STEP7_MASTER = ROOT / "results_step07" / "STEP07_MASTER_DATASET.csv"
STEP7_REP = ROOT / "results_step07" / "STEP07_REPLICATE_LEVEL_MASTER.csv"
STEP8_SCEN = ROOT / "results_step08" / "tables" / "02_final_scenario_evidence.csv"
STEP8_REP = ROOT / "results_step08" / "tables" / "03_final_replicate_evidence.csv"
STEP8_BASE = ROOT / "results_step08" / "tables" / "04_final_baseline_vs_interventions.csv"
STEP8_SENS = ROOT / "results_step08" / "tables" / "05_final_sensitivity_evidence.csv"
STEP8_VAL = ROOT / "results_step08" / "tables" / "06_final_validation_evidence.csv"
STEP8_MAP = ROOT / "results_step08" / "tables" / "07_publication_evidence_map.csv"
STEP8_METRICS = ROOT / "results_step08" / "tables" / "08_publication_metrics.csv"
STEP8_REPORT = ROOT / "results_step08" / "STEP08_FINAL_REPORT.txt"

STEP4 = ROOT / "results_step04" / "tables"
STEP5 = ROOT / "results_step05" / "tables"
STEP6 = ROOT / "results_step06" / "tables"


# ---------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------
def banner(title: str):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def section(title: str):
    print("\n" + "-" * 100)
    print(title)
    print("-" * 100)


def saved(path: Path):
    print(f"[SAVED] {path}")


def passmsg(label: str, detail: str):
    print(f"[PASS] {label:<45} | {detail}")


def failmsg(label: str, detail: str):
    print(f"[FAIL] {label:<45} | {detail}")


def read_csv(path: Path, required=False):
    if not path.exists():
        if required:
            raise FileNotFoundError(f"Required file missing: {path}")
        return pd.DataFrame()
    return pd.read_csv(path)


def numeric_series(df, col):
    if col not in df.columns:
        return pd.Series(dtype=float)
    return pd.to_numeric(df[col], errors="coerce")


def safe_mean(s):
    s = pd.to_numeric(s, errors="coerce").dropna()
    return float(s.mean()) if len(s) else np.nan


def safe_sd(s):
    s = pd.to_numeric(s, errors="coerce").dropna()
    return float(s.std(ddof=1)) if len(s) > 1 else 0.0


def safe_median(s):
    s = pd.to_numeric(s, errors="coerce").dropna()
    return float(s.median()) if len(s) else np.nan


def pct_change(new, old):
    if old is None or not np.isfinite(old) or old == 0:
        return np.nan
    return (new - old) / old * 100.0


def fmt(x, digits=3):
    try:
        if pd.isna(x):
            return "NA"
        return f"{float(x):,.{digits}f}"
    except Exception:
        return str(x)


def find_col(df, candidates):
    lower = {str(c).strip().lower(): c for c in df.columns}
    for candidate in candidates:
        key = candidate.strip().lower()
        if key in lower:
            return lower[key]
    for c in df.columns:
        cl = str(c).strip().lower()
        if any(candidate.strip().lower() in cl for candidate in candidates):
            return c
    return None


def save(df, path):
    df.to_csv(path, index=False)
    saved(path)


def add_table(doc, df, max_rows=15, max_cols=10):
    if Document is None:
        return
    view = df.head(max_rows).copy()
    cols = list(view.columns[:max_cols])
    table = doc.add_table(rows=1, cols=len(cols))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for j, c in enumerate(cols):
        table.rows[0].cells[j].text = str(c)
    for _, row in view.iterrows():
        cells = table.add_row().cells
        for j, c in enumerate(cols):
            val = row[c]
            if isinstance(val, float):
                text = f"{val:.4f}"
            else:
                text = str(val)
            cells[j].text = text


# ---------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------
def main():
    banner("E-WASTE ABM\nSTEP 9: FINAL RESULTS & MANUSCRIPT INTEGRATION\nFINAL COMPATIBLE VERSION")
    print(f"Project root : {ROOT}")
    print(f"Output       : {OUT}")

    failures = []

    # ================================================================
    # 9.1 UPSTREAM INTEGRITY
    # ================================================================
    section("STEP 9.1 - UPSTREAM FILE INTEGRITY")

    required = {
        "STEP 7 Master Dataset": STEP7_MASTER,
        "STEP 7 Replicate Master": STEP7_REP,
        "STEP 8 Scenario Evidence": STEP8_SCEN,
        "STEP 8 Replicate Evidence": STEP8_REP,
        "STEP 8 Baseline vs Interventions": STEP8_BASE,
        "STEP 8 Sensitivity Evidence": STEP8_SENS,
        "STEP 8 Validation Evidence": STEP8_VAL,
        "STEP 8 Evidence Map": STEP8_MAP,
        "STEP 8 Publication Metrics": STEP8_METRICS,
        "STEP 8 Final Report": STEP8_REPORT,
    }

    integrity = []
    for label, path in required.items():
        ok = path.exists()
        integrity.append({"Input": label, "Status": "PASS" if ok else "FAIL", "Path": str(path)})
        if ok:
            passmsg("File integrity", f"{label}: {path}")
        else:
            failmsg("File integrity", f"{label}: {path}")
            failures.append(label)

    integrity_df = pd.DataFrame(integrity)
    save(integrity_df, TABLES / "01_upstream_file_integrity.csv")

    if failures:
        raise FileNotFoundError("Required Step 7/8 inputs are missing.")

    # ================================================================
    # LOAD
    # ================================================================
    master = read_csv(STEP7_MASTER, True)
    rep_master = read_csv(STEP7_REP, True)
    scen_evidence = read_csv(STEP8_SCEN, True)
    rep_evidence = read_csv(STEP8_REP, True)
    base_evidence = read_csv(STEP8_BASE, True)
    sens = read_csv(STEP8_SENS, True)
    validation = read_csv(STEP8_VAL, True)
    evidence_map = read_csv(STEP8_MAP, True)
    metrics = read_csv(STEP8_METRICS, True)

    print(f"Master dataset rows       : {len(master)}")
    print(f"Master dataset columns    : {len(master.columns)}")
    print(f"Replicate master rows     : {len(rep_master)}")
    print(f"Scenario evidence rows    : {len(scen_evidence)}")
    print(f"Baseline evidence rows    : {len(base_evidence)}")
    print(f"Sensitivity rows          : {len(sens)}")
    print(f"Validation evidence rows  : {len(validation)}")

    # ================================================================
    # 9.2 MASTER READINESS
    # ================================================================
    section("STEP 9.2 - MASTER DATASET READINESS")

    missing_core = [c for c in CORE if c not in master.columns]
    duplicate_cols = master.columns[master.columns.duplicated()].tolist()

    if missing_core:
        failmsg("Core columns", f"Missing={missing_core}")
        failures.append("Core columns")
    else:
        passmsg("Core columns", "All 12 core columns available")

    if duplicate_cols:
        failmsg("Duplicate columns", str(duplicate_cols))
        failures.append("Duplicate columns")
    else:
        passmsg("Duplicate columns", "None")

    scenarios = master["Scenario"].astype(str).unique().tolist()
    missing_scen = [x for x in SCENARIO_ORDER if x not in scenarios]
    unexpected = [x for x in scenarios if x not in SCENARIO_ORDER]

    if missing_scen or unexpected:
        failmsg("Scenario integrity", f"Missing={missing_scen}; Unexpected={unexpected}")
        failures.append("Scenario integrity")
    else:
        passmsg("Scenario integrity", "All six expected scenarios detected")

    numeric_cols = master.select_dtypes(include=[np.number]).columns
    finite_ok = True
    if len(numeric_cols):
        finite_ok = np.isfinite(master[numeric_cols].to_numpy(dtype=float)).all()
    if finite_ok:
        passmsg("Numeric integrity", "All numeric master fields finite")
    else:
        failmsg("Numeric integrity", "Non-finite numeric values detected")
        failures.append("Numeric integrity")

    readiness = pd.DataFrame([
        ["Core columns", "PASS" if not missing_core else "FAIL", str(missing_core)],
        ["Duplicate columns", "PASS" if not duplicate_cols else "FAIL", str(duplicate_cols)],
        ["Scenario integrity", "PASS" if not (missing_scen or unexpected) else "FAIL",
         f"Missing={missing_scen}; Unexpected={unexpected}"],
        ["Numeric integrity", "PASS" if finite_ok else "FAIL", ""],
    ], columns=["Check", "Status", "Details"])
    save(readiness, TABLES / "02_master_readiness.csv")

    # ================================================================
    # 9.3 FINAL SCENARIO RESULTS
    # ================================================================
    section("STEP 9.3 - FINAL SCENARIO RESULTS")

    rows = []
    for sid, scenario in SCENARIOS.items():
        d = master[master["Scenario"].astype(str) == scenario].copy()
        if d.empty:
            continue

        generated = safe_mean(d["Generated E-waste (kg)"])
        formal = safe_mean(d["Formal E-waste (kg)"])
        informal = safe_mean(d["Informal E-waste (kg)"])
        recovered = safe_mean(d["Recovered Material (kg)"])
        residual = safe_mean(d["Residual Waste (kg)"])
        collection = safe_mean(d["Collection Rate (%)"])
        recovery = safe_mean(d["Recovery Rate (%)"])
        participation = safe_mean(d["Formal Participation (%)"])
        inventory = safe_mean(d["Ending Inventory (kg)"])

        cost_col = find_col(d, ["System Cost (USD)", "System Cost", "System Cost (Rp)"])
        cost = safe_mean(d[cost_col]) if cost_col else np.nan

        rows.append({
            "Scenario ID": sid,
            "Scenario": scenario,
            "Generated E-waste (kg)": generated,
            "Formal E-waste (kg)": formal,
            "Informal E-waste (kg)": informal,
            "Recovered Material (kg)": recovered,
            "Residual Waste (kg)": residual,
            "Collection Rate (%)": collection,
            "Recovery Rate (%)": recovery,
            "Formal Participation (%)": participation,
            "Ending Inventory (kg)": inventory,
            "System Cost": cost,
            "Recovered SD (kg)": safe_sd(d["Recovered Material (kg)"]),
            "Participation SD (%)": safe_sd(d["Formal Participation (%)"]),
            "Replicates": d["Replicate"].nunique(),
            "Periods": d["Period"].nunique(),
        })

    scenario_results = pd.DataFrame(rows).sort_values("Scenario ID")
    save(scenario_results, TABLES / "03_final_scenario_results.csv")
    passmsg("Scenario results", f"{len(scenario_results)} scenarios summarized")

    # ================================================================
    # 9.4 BASELINE VS INTERVENTIONS
    # ================================================================
    section("STEP 9.4 - BASELINE VS INTERVENTION EFFECTS")

    if not scenario_results.empty:
        baseline = scenario_results.iloc[0]
        comp = []
        for _, r in scenario_results.iloc[1:].iterrows():
            comp.append({
                "Scenario ID": r["Scenario ID"],
                "Scenario": r["Scenario"],
                "Baseline Recovered (kg)": baseline["Recovered Material (kg)"],
                "Scenario Recovered (kg)": r["Recovered Material (kg)"],
                "Recovered Change (kg)": r["Recovered Material (kg)"] - baseline["Recovered Material (kg)"],
                "Recovered Change (%)": pct_change(
                    r["Recovered Material (kg)"], baseline["Recovered Material (kg)"]
                ),
                "Baseline Participation (%)": baseline["Formal Participation (%)"],
                "Scenario Participation (%)": r["Formal Participation (%)"],
                "Participation Change (percentage points)": (
                    r["Formal Participation (%)"] - baseline["Formal Participation (%)"]
                ),
                "Baseline Collection Rate (%)": baseline["Collection Rate (%)"],
                "Scenario Collection Rate (%)": r["Collection Rate (%)"],
                "Collection Change (percentage points)": (
                    r["Collection Rate (%)"] - baseline["Collection Rate (%)"]
                ),
                "Baseline Residual (kg)": baseline["Residual Waste (kg)"],
                "Scenario Residual (kg)": r["Residual Waste (kg)"],
                "Residual Change (kg)": r["Residual Waste (kg)"] - baseline["Residual Waste (kg)"],
            })
        baseline_effects = pd.DataFrame(comp)
    else:
        baseline_effects = pd.DataFrame()

    save(baseline_effects, TABLES / "04_baseline_intervention_effects.csv")
    passmsg("Baseline comparison", f"{len(baseline_effects)} intervention scenarios compared")

    # ================================================================
    # 9.5 STATISTICAL EVIDENCE
    # ================================================================
    section("STEP 9.5 - STATISTICAL EVIDENCE")

    stat_frames = []
    for path in [
        STEP4 / "03_replicate_descriptive_statistics.csv",
        STEP4 / "04_assumption_diagnostics.csv",
        STEP4 / "05_omnibus_tests.csv",
        STEP4 / "06_tukey_hsd_posthoc.csv",
        STEP4 / "07_mannwhitney_holm_posthoc.csv",
        STEP4 / "08_baseline_vs_scenarios.csv",
        STEP4 / "09_effect_size_summary.csv",
        STEP4 / "10_statistical_conclusions.csv",
    ]:
        if path.exists():
            x = pd.read_csv(path)
            x.insert(0, "Source File", path.name)
            stat_frames.append(x)

    if stat_frames:
        statistical = pd.concat(stat_frames, ignore_index=True, sort=False)
    else:
        statistical = pd.DataFrame(columns=["Source File"])

    save(statistical, TABLES / "05_statistical_evidence.csv")
    passmsg("Statistical evidence", f"{len(statistical)} rows consolidated")

    # ================================================================
    # 9.6 EFFECT SIZE SUMMARY
    # ================================================================
    section("STEP 9.6 - EFFECT SIZE SUMMARY")

    effect_path = STEP4 / "09_effect_size_summary.csv"
    if effect_path.exists():
        effects = pd.read_csv(effect_path)
    else:
        effects = pd.DataFrame()

    save(effects, TABLES / "06_effect_size_summary.csv")
    passmsg("Effect sizes", f"{len(effects)} rows available")

    # ================================================================
    # 9.7 SENSITIVITY
    # ================================================================
    section("STEP 9.7 - SENSITIVITY & ROBUSTNESS RESULTS")

    sens_out = sens.copy()
    rank_col = find_col(sens_out, ["Sensitivity Rank", "Rank"])
    param_col = find_col(sens_out, ["Parameter Label", "Parameter"])
    range_col = find_col(sens_out, ["Sensitivity Range (%)", "Sensitivity Range"])
    elast_col = find_col(sens_out, ["Elasticity"])

    if rank_col:
        sens_out = sens_out.sort_values(rank_col)
    save(sens_out, TABLES / "07_sensitivity_results_final.csv")

    top_parameter = str(sens_out.iloc[0][param_col]) if (
        len(sens_out) and param_col
    ) else "Unavailable"

    top_elasticity = (
        float(pd.to_numeric(sens_out.iloc[0][elast_col], errors="coerce"))
        if len(sens_out) and elast_col else np.nan
    )

    passmsg("Sensitivity analysis", f"Highest-ranked parameter={top_parameter}")

    # ================================================================
    # 9.8 VALIDATION
    # ================================================================
    section("STEP 9.8 - MODEL VALIDATION EVIDENCE")

    val_out = validation.copy()
    status_col = find_col(val_out, ["Status"])
    validation_failures = 0
    if status_col:
        validation_failures = int(
            (val_out[status_col].astype(str).str.upper() == "FAIL").sum()
        )

    save(val_out, TABLES / "08_validation_evidence_final.csv")

    if validation_failures == 0:
        passmsg("Validation evidence", "No validation failures detected")
    else:
        failmsg("Validation evidence", f"Failures={validation_failures}")
        failures.append("Validation evidence")

    # ================================================================
    # 9.9 KEY FINDINGS
    # ================================================================
    section("STEP 9.9 - KEY FINDINGS EXTRACTION")

    findings = []

    if not scenario_results.empty:
        best_rec = scenario_results.loc[
            scenario_results["Recovered Material (kg)"].idxmax()
        ]
        best_part = scenario_results.loc[
            scenario_results["Formal Participation (%)"].idxmax()
        ]
        best_coll = scenario_results.loc[
            scenario_results["Collection Rate (%)"].idxmax()
        ]

        findings.extend([
            {
                "Finding ID": "F1",
                "Category": "Scenario performance",
                "Finding": "Scenario with highest recovered material",
                "Scenario": best_rec["Scenario"],
                "Value": best_rec["Recovered Material (kg)"],
                "Unit": "kg",
                "Interpretation": "Highest mean recovered material among the six modeled scenarios."
            },
            {
                "Finding ID": "F2",
                "Category": "Formal participation",
                "Finding": "Scenario with highest formal participation",
                "Scenario": best_part["Scenario"],
                "Value": best_part["Formal Participation (%)"],
                "Unit": "%",
                "Interpretation": "Highest mean formal participation among the six modeled scenarios."
            },
            {
                "Finding ID": "F3",
                "Category": "Collection",
                "Finding": "Scenario with highest collection rate",
                "Scenario": best_coll["Scenario"],
                "Value": best_coll["Collection Rate (%)"],
                "Unit": "%",
                "Interpretation": "Highest mean collection rate among the six modeled scenarios."
            },
        ])

        base_rec = baseline["Recovered Material (kg)"]
        s5 = scenario_results[scenario_results["Scenario ID"] == 5]
        if not s5.empty:
            s5_rec = float(s5.iloc[0]["Recovered Material (kg)"])
            findings.append({
                "Finding ID": "F4",
                "Category": "Combined orchestration",
                "Finding": "Scenario 5 improvement over baseline",
                "Scenario": "Scenario 5 - Combined Orchestration",
                "Value": pct_change(s5_rec, base_rec),
                "Unit": "%",
                "Interpretation": "Relative increase in recovered material compared with baseline."
            })

    findings.extend([
        {
            "Finding ID": "F5",
            "Category": "Sensitivity",
            "Finding": "Most influential sensitivity parameter",
            "Scenario": "Scenario 5 - Combined Orchestration",
            "Value": top_elasticity,
            "Unit": "elasticity",
            "Interpretation": f"Recovery performance is most sensitive to {top_parameter}."
        },
        {
            "Finding ID": "F6",
            "Category": "Validation",
            "Finding": "Validation failures",
            "Scenario": "Steps 6-8",
            "Value": validation_failures,
            "Unit": "count",
            "Interpretation": "The consolidated validation evidence contains no failed checks when the value is zero."
        },
    ])

    key_findings = pd.DataFrame(findings)
    save(key_findings, TABLES / "09_key_findings.csv")

    # ================================================================
    # 9.10 MANUSCRIPT EVIDENCE MAP
    # ================================================================
    section("STEP 9.10 - MANUSCRIPT EVIDENCE MAP")

    evidence_rows = [
        ["Results 1", "Scenario comparison", "03_final_scenario_results.csv", "Scenario performance across six scenarios"],
        ["Results 2", "Baseline comparison", "04_baseline_intervention_effects.csv", "Effect of intervention scenarios relative to baseline"],
        ["Results 3", "Statistical evidence", "05_statistical_evidence.csv", "Replication and statistical inference evidence"],
        ["Results 4", "Effect sizes", "06_effect_size_summary.csv", "Magnitude of intervention effects"],
        ["Results 5", "Sensitivity", "07_sensitivity_results_final.csv", "Parameter robustness and ranking"],
        ["Validation", "Model validation", "08_validation_evidence_final.csv", "Logical and data validation"],
        ["Discussion", "Key findings", "09_key_findings.csv", "Main findings for interpretation"],
        ["Figures", "Publication figures", "figures/", "Final manuscript figures"],
    ]
    evidence_out = pd.DataFrame(
        evidence_rows,
        columns=["Block", "Evidence Type", "Output", "Purpose"]
    )
    save(evidence_out, TABLES / "10_manuscript_evidence_map.csv")
    passmsg("Evidence map", f"{len(evidence_out)}/8 evidence blocks prepared")

    # ================================================================
    # 9.11 FIGURES
    # ================================================================
    section("STEP 9.11 - GENERATING FINAL RESULTS FIGURES")

    figure_paths = []

    if plt is not None and not scenario_results.empty:
        # Figure 1
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.bar(
            scenario_results["Scenario"].str.replace("Scenario ", "S", regex=False),
            scenario_results["Recovered Material (kg)"],
        )
        ax.set_ylabel("Recovered Material (kg)")
        ax.set_xlabel("Scenario")
        ax.set_title("Recovered Material by Scenario")
        ax.tick_params(axis="x", rotation=30)
        fig.tight_layout()
        p = FIGURES / "01_final_recovered_material_by_scenario.png"
        fig.savefig(p, dpi=300, bbox_inches="tight")
        plt.close(fig)
        saved(p)
        figure_paths.append(p)

        # Figure 2
        fig, ax = plt.subplots(figsize=(10, 6))
        x = np.arange(len(scenario_results))
        width = 0.36
        ax.bar(x - width/2, scenario_results["Collection Rate (%)"], width, label="Collection Rate")
        ax.bar(x + width/2, scenario_results["Formal Participation (%)"], width, label="Formal Participation")
        ax.set_xticks(x)
        ax.set_xticklabels(
            scenario_results["Scenario"].str.replace("Scenario ", "S", regex=False),
            rotation=30,
            ha="right",
        )
        ax.set_ylabel("Percentage (%)")
        ax.set_title("Collection Rate and Formal Participation")
        ax.legend()
        fig.tight_layout()
        p = FIGURES / "02_collection_and_participation.png"
        fig.savefig(p, dpi=300, bbox_inches="tight")
        plt.close(fig)
        saved(p)
        figure_paths.append(p)

        # Figure 3
        if param_col and range_col:
            splot = sens_out.copy()
            splot[range_col] = pd.to_numeric(splot[range_col], errors="coerce")
            splot = splot.sort_values(range_col, ascending=True)
            fig, ax = plt.subplots(figsize=(9, 6))
            ax.barh(splot[param_col].astype(str), splot[range_col])
            ax.set_xlabel("Sensitivity Range (%)")
            ax.set_title("Sensitivity Ranking")
            fig.tight_layout()
            p = FIGURES / "03_final_sensitivity_ranking.png"
            fig.savefig(p, dpi=300, bbox_inches="tight")
            plt.close(fig)
            saved(p)
            figure_paths.append(p)

        # Figure 4
        s5rep = rep_master[
            rep_master["Scenario"].astype(str) == SCENARIOS[5]
        ].copy()
        if not s5rep.empty and "Recovered Material (kg)" in s5rep.columns:
            # Aggregate to replicate if period-level data are present
            if "Period" in s5rep.columns:
                s5rep = (
                    s5rep.groupby("Replicate", as_index=False)["Recovered Material (kg)"]
                    .sum()
                )
            fig, ax = plt.subplots(figsize=(7, 6))
            ax.boxplot(s5rep["Recovered Material (kg)"].dropna().values, orientation="vertical")
            ax.set_ylabel("Recovered Material (kg)")
            ax.set_title("Scenario 5 Recovered Material Distribution")
            fig.tight_layout()
            p = FIGURES / "04_scenario5_recovered_material_distribution.png"
            fig.savefig(p, dpi=300, bbox_inches="tight")
            plt.close(fig)
            saved(p)
            figure_paths.append(p)

    else:
        print("[WARNING] Matplotlib unavailable; figures were not generated.")

    # ================================================================
    # 9.12 MANUSCRIPT DOCX
    # ================================================================
    section("STEP 9.12 - BUILDING FINAL MANUSCRIPT RESULTS DOCUMENT")

    docx_path = OUT / "STEP09_MANUSCRIPT_RESULTS.docx"

    if DOCX_AVAILABLE and Document is not None:
        doc = Document()
        styles = doc.styles
        styles["Normal"].font.name = "Times New Roman"
        styles["Normal"].font.size = Pt(11)

        title = doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title.add_run(
            "FINAL RESULTS AND DISCUSSION EVIDENCE\n"
            "E-WASTE AGENT-BASED MODEL"
        )
        run.bold = True
        run.font.size = Pt(16)

        p = doc.add_paragraph()
        p.add_run("Data basis: ").bold = True
        p.add_run("Validated and consolidated outputs from STEP 4 through STEP 8.")

        doc.add_heading("1. Simulation Results", level=1)
        doc.add_paragraph(
            "The model evaluates six scenarios using 30 replicates per scenario "
            "and 12 simulation periods. Scenario-level outcomes are summarized "
            "using generated e-waste, formal and informal streams, recovered material, "
            "residual waste, collection rate, recovery rate, formal participation, "
            "ending inventory, and system cost where available."
        )
        add_table(doc, scenario_results, max_rows=10, max_cols=12)

        doc.add_heading("2. Baseline versus Intervention Scenarios", level=1)
        if not baseline_effects.empty:
            add_table(doc, baseline_effects, max_rows=10, max_cols=12)
            for _, r in baseline_effects.iterrows():
                doc.add_paragraph(
                    f"{r['Scenario']} produced a recovered-material change of "
                    f"{r['Recovered Change (%)']:.2f}% relative to the baseline, "
                    f"with a participation change of "
                    f"{r['Participation Change (percentage points)']:.2f} percentage points."
                )

        doc.add_heading("3. Statistical Evidence", level=1)
        doc.add_paragraph(
            f"The consolidated statistical evidence contains {len(statistical)} rows "
            "covering descriptive statistics, diagnostics, omnibus tests, post-hoc "
            "comparisons, baseline comparisons, effect sizes, and statistical conclusions "
            "from STEP 4."
        )

        doc.add_heading("4. Sensitivity and Robustness", level=1)
        doc.add_paragraph(
            f"The one-at-a-time sensitivity analysis identifies {top_parameter} "
            "as the highest-ranked parameter for recovered material under Scenario 5. "
            f"The reported elasticity is {fmt(top_elasticity, 4)} where available."
        )
        add_table(doc, sens_out, max_rows=10, max_cols=10)

        doc.add_heading("5. Model Validation", level=1)
        doc.add_paragraph(
            f"Consolidated validation evidence contains {len(validation)} rows. "
            f"Detected validation failures: {validation_failures}. "
            "The final manuscript should report validation as a model-quality and "
            "internal-consistency check rather than as external empirical validation."
        )

        doc.add_heading("6. Key Findings", level=1)
        for _, r in key_findings.iterrows():
            doc.add_paragraph(
                f"{r['Finding ID']}: {r['Finding']} — {r['Scenario']}; "
                f"value={r['Value']} {r['Unit']}. {r['Interpretation']}"
            )

        doc.add_heading("7. Evidence and Figure Package", level=1)
        doc.add_paragraph(
            "The accompanying CSV tables and PNG figures provide traceable evidence "
            "for scenario comparison, intervention effects, sensitivity, and validation."
        )

        for fp in figure_paths:
            doc.add_picture(str(fp), width=Inches(6.2))
            cap = doc.add_paragraph(fp.name)
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER

        doc.save(docx_path)
        saved(docx_path)
    else:
        detail = "python-docx unavailable. Install with: python -m pip install python-docx"
        if DOCX_IMPORT_ERROR:
            detail += f" | Import error: {DOCX_IMPORT_ERROR}"
        print(f"[FAIL] Manuscript DOCX | {detail}")
        failures.append("Manuscript DOCX")

    # ================================================================
    # 9.13 FINAL REPORT
    # ================================================================
    section("STEP 9.13 - GENERATING STEP 9 FINAL REPORT")

    report_lines = [
        "E-WASTE ABM",
        "STEP 9: FINAL RESULTS & MANUSCRIPT INTEGRATION",
        "FINAL COMPATIBLE VERSION",
        "",
        f"Project root: {ROOT}",
        f"Output folder: {OUT}",
        "",
        "DATASET SUMMARY",
        f"Master dataset rows: {len(master)}",
        f"Master dataset columns: {len(master.columns)}",
        f"Replicate master rows: {len(rep_master)}",
        f"Scenario results: {len(scenario_results)}",
        f"Sensitivity parameters: {len(sens_out)}",
        f"Validation evidence rows: {len(validation)}",
        "",
        "DESIGN",
        "Scenarios: 6",
        "Replicates per scenario: 30",
        "Periods per scenario: 12",
        "",
        "KEY SENSITIVITY RESULT",
        f"Highest-ranked parameter: {top_parameter}",
        f"Elasticity: {fmt(top_elasticity, 4)}",
        "",
        "VALIDATION",
        f"Validation failures detected: {validation_failures}",
        "",
        "OUTPUTS",
        f"Tables generated: {len(list(TABLES.glob('*.csv')))}",
        f"Figures generated: {len(figure_paths)}",
        f"DOCX generated: {'YES' if docx_path.exists() else 'NO'}",
        "",
        "STATUS",
        f"Failures in Step 9: {len(failures)}",
    ]

    report_path = OUT / "STEP09_FINAL_RESULTS_REPORT.txt"
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    saved(report_path)

    # ================================================================
    # 9.14 FINAL VALIDATION
    # ================================================================
    section("STEP 9.14 - FINAL STEP 9 VALIDATION")

    checks = [
        ("Input files", "PASS" if not failures else "FAIL", f"Failures={len(failures)}"),
        ("Master dataset", "PASS" if len(master) == 2160 else "FAIL", f"Rows={len(master)}"),
        ("Scenario count", "PASS" if len(scenario_results) == 6 else "FAIL", f"Detected={len(scenario_results)}"),
        ("Replicate structure", "PASS" if len(rep_master) == 180 else "FAIL", f"Rows={len(rep_master)}"),
        ("Sensitivity parameters", "PASS" if len(sens_out) == 7 else "FAIL", f"Detected={len(sens_out)}"),
        ("Validation failures", "PASS" if validation_failures == 0 else "FAIL", f"Detected={validation_failures}"),
        ("Evidence blocks", "PASS" if len(evidence_out) == 8 else "FAIL", f"Prepared={len(evidence_out)}/8"),
        ("Figures", "PASS" if len(figure_paths) == 4 else "FAIL", f"Generated={len(figure_paths)}/4"),
        (
            "Manuscript DOCX",
            "PASS" if docx_path.exists() else "FAIL",
            str(docx_path) if docx_path.exists()
            else "python-docx unavailable; run: python -m pip install python-docx",
        ),
        ("Final report", "PASS" if report_path.exists() else "FAIL", str(report_path)),
    ]

    final_df = pd.DataFrame(checks, columns=["Check", "Status", "Details"])
    save(final_df, TABLES / "11_final_step09_validation.csv")

    final_failures = int((final_df["Status"] == "FAIL").sum())
    if final_failures:
        for _, r in final_df[final_df["Status"] == "FAIL"].iterrows():
            failmsg("Final validation", f"{r['Check']} | {r['Details']}")
    else:
        for _, r in final_df.iterrows():
            passmsg("Final validation", f"{r['Check']} | {r['Details']}")

    banner("STEP 9 FINAL SUMMARY")
    print(f"Scenarios analyzed        : {len(scenario_results)}")
    print(f"Master dataset rows       : {len(master)}")
    print(f"Replicate-level rows      : {len(rep_master)}")
    print(f"Sensitivity parameters    : {len(sens_out)}")
    print(f"Statistical evidence rows : {len(statistical)}")
    print(f"Evidence map items        : {len(evidence_out)}")
    print(f"Figures generated         : {len(figure_paths)}")
    print(f"Validation failures       : {final_failures}")
    print(f"Output folder             : {OUT}")
    print(f"Tables folder             : {TABLES}")
    print(f"Figures folder            : {FIGURES}")
    print()

    if final_failures == 0:
        print("=" * 100)
        print("STEP 9 STATUS : PASS")
        print("=" * 100)
        print("READY FOR FINAL MANUSCRIPT / THESIS RESULTS & DISCUSSION")
    else:
        print("=" * 100)
        print("STEP 9 STATUS : FAIL")
        print("=" * 100)
        print("REVIEW REQUIRED")

    return final_failures


if __name__ == "__main__":
    raise SystemExit(main())
