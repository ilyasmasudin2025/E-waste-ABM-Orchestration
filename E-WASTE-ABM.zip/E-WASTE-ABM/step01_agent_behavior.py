from pathlib import Path
import json
import csv
import math
import random
import warnings

warnings.filterwarnings("ignore")


# ============================================================
# E-WASTE ABM
# STEP 1: AGENT & BEHAVIORAL MODEL
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent
STEP00_DIR = PROJECT_ROOT / "results_step00"
OUTPUT_DIR = PROJECT_ROOT / "results_step01"

BASE_CONFIG_FILE = STEP00_DIR / "ABM_BASE_PARAMETERS.csv"
SCENARIO_CONFIG_FILE = STEP00_DIR / "ABM_SCENARIO_PARAMETERS.csv"
JSON_CONFIG_FILE = STEP00_DIR / "ABM_PARAMETER_CONFIG.json"


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def print_header(title):
    print()
    print("=" * 100)
    print(title)
    print("=" * 100)


def safe_float(value, default=0.0):
    try:
        if value is None:
            return default

        text = str(value).strip()

        if text == "":
            return default

        text = text.replace(",", "")

        return float(text)

    except (ValueError, TypeError):
        return default


def safe_int(value, default=0):
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def normalize_probability(value):
    """
    Converts probability values into 0-1 range.

    Examples:
    0.80  -> 0.80
    80    -> 0.80
    80%   -> 0.80
    """

    if value is None:
        return 0.0

    text = str(value).strip()

    if text.endswith("%"):
        value = safe_float(text[:-1], 0.0)
        return max(0.0, min(1.0, value / 100.0))

    value = safe_float(value, 0.0)

    if value > 1:
        value = value / 100.0

    return max(0.0, min(1.0, value))


def load_csv(path):
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")

    with open(path, "r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        return list(reader)


def save_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
            extrasaction="ignore"
        )

        writer.writeheader()
        writer.writerows(rows)


def save_text(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as file:
        file.write(text)


# ============================================================
# PARAMETER LOADING
# ============================================================

def load_parameter_configuration():

    print_header("STEP 1.1 - LOADING STEP 0 CONFIGURATION")

    base_rows = load_csv(BASE_CONFIG_FILE)
    scenario_rows = load_csv(SCENARIO_CONFIG_FILE)

    print(f"[FOUND] Base parameter rows     : {len(base_rows)}")
    print(f"[FOUND] Scenario parameter rows : {len(scenario_rows)}")

    json_config = {}

    if JSON_CONFIG_FILE.exists():

        try:
            with open(JSON_CONFIG_FILE, "r", encoding="utf-8") as file:
                json_config = json.load(file)

            print("[FOUND] JSON parameter configuration")

        except Exception as exc:

            print(
                f"[WARNING] JSON configuration could not be parsed: {exc}"
            )

    return base_rows, scenario_rows, json_config


# ============================================================
# PARAMETER DICTIONARY
# ============================================================

def build_parameter_dictionary(rows):

    parameters = {}

    for row in rows:

        possible_names = [
            row.get("Parameter"),
            row.get("parameter"),
            row.get("Name"),
            row.get("name"),
            row.get("Variable"),
            row.get("variable")
        ]

        parameter_name = None

        for candidate in possible_names:

            if candidate is not None and str(candidate).strip():
                parameter_name = str(candidate).strip()
                break

        if parameter_name is None:
            continue

        value = None

        for key in [
            "Value",
            "value",
            "Base Value",
            "base_value",
            "Parameter Value",
            "parameter_value"
        ]:

            if key in row and str(row[key]).strip():
                value = row[key]
                break

        if value is None:

            # fallback: first non-name column
            for key, val in row.items():

                if key in [
                    "Parameter",
                    "parameter",
                    "Name",
                    "name",
                    "Variable",
                    "variable"
                ]:
                    continue

                if val is not None and str(val).strip():

                    value = val
                    break

        parameters[parameter_name] = value

    return parameters


# ============================================================
# BASE AGENT
# ============================================================

class BaseAgent:

    def __init__(self, unique_id, model=None):

        self.unique_id = unique_id
        self.model = model

    def step(self):
        raise NotImplementedError


# ============================================================
# CONSUMER / GENERATOR AGENT
# ============================================================

class ConsumerAgent(BaseAgent):

    def __init__(
        self,
        unique_id,
        model=None,
        awareness=0.5,
        incentive=0.5,
        accessibility=0.5,
        convenience=0.5,
        trust=0.5,
        e_waste_generation=1.0,
        formal_preference=0.5
    ):

        super().__init__(unique_id, model)

        self.awareness = normalize_probability(awareness)
        self.incentive = normalize_probability(incentive)
        self.accessibility = normalize_probability(accessibility)
        self.convenience = normalize_probability(convenience)
        self.trust = normalize_probability(trust)

        self.e_waste_generation = max(
            0.0,
            safe_float(e_waste_generation, 1.0)
        )

        self.formal_preference = normalize_probability(
            formal_preference
        )

        self.decision_score = 0.0
        self.formal_probability = 0.0

        self.formal_collection = False

        self.generated_e_waste = 0.0
        self.formal_e_waste = 0.0
        self.informal_e_waste = 0.0

    # --------------------------------------------------------
    # BEHAVIORAL DECISION
    # --------------------------------------------------------

    def calculate_decision_score(self):

        weights = {
            "awareness": 0.20,
            "incentive": 0.15,
            "accessibility": 0.20,
            "convenience": 0.15,
            "trust": 0.20,
            "formal_preference": 0.10
        }

        score = (
            self.awareness * weights["awareness"]
            + self.incentive * weights["incentive"]
            + self.accessibility * weights["accessibility"]
            + self.convenience * weights["convenience"]
            + self.trust * weights["trust"]
            + self.formal_preference * weights["formal_preference"]
        )

        self.decision_score = max(
            0.0,
            min(1.0, score)
        )

        return self.decision_score

    # --------------------------------------------------------
    # PROBABILISTIC FORMAL COLLECTION DECISION
    # --------------------------------------------------------

    def make_collection_decision(self, rng=None):

        if rng is None:
            rng = random.Random()

        score = self.calculate_decision_score()

        # Logistic transformation gives a smooth
        # probabilistic behavioral response.
        centered = (score - 0.5) * 8.0

        try:
            logistic = 1.0 / (1.0 + math.exp(-centered))
        except OverflowError:
            logistic = 0.0 if centered < 0 else 1.0

        self.formal_probability = (
            0.25 * score
            + 0.75 * logistic
        )

        self.formal_probability = max(
            0.0,
            min(1.0, self.formal_probability)
        )

        self.formal_collection = (
            rng.random() < self.formal_probability
        )

        return self.formal_collection

    # --------------------------------------------------------
    # E-WASTE GENERATION
    # --------------------------------------------------------

    def generate_e_waste(self):

        self.generated_e_waste = self.e_waste_generation

        if self.formal_collection:

            self.formal_e_waste = self.generated_e_waste
            self.informal_e_waste = 0.0

        else:

            self.formal_e_waste = 0.0
            self.informal_e_waste = self.generated_e_waste

        return self.generated_e_waste

    def step(self):

        rng = None

        if self.model is not None:
            rng = getattr(self.model, "rng", None)

        self.make_collection_decision(rng)
        self.generate_e_waste()


# ============================================================
# COLLECTION AGENT
# ============================================================

class CollectionAgent(BaseAgent):

    def __init__(
        self,
        unique_id,
        model=None,
        capacity=float("inf"),
        collection_efficiency=0.80
    ):

        super().__init__(unique_id, model)

        self.capacity = max(
            0.0,
            safe_float(capacity, float("inf"))
        )

        self.collection_efficiency = normalize_probability(
            collection_efficiency
        )

        self.received_e_waste = 0.0
        self.collected_e_waste = 0.0
        self.uncollected_e_waste = 0.0

        self.available_capacity = self.capacity

    def collect(self, incoming_e_waste):

        incoming_e_waste = max(
            0.0,
            safe_float(incoming_e_waste, 0.0)
        )

        if math.isinf(self.capacity):

            capacity_available = incoming_e_waste

        else:

            capacity_available = min(
                incoming_e_waste,
                max(0.0, self.available_capacity)
            )

        self.received_e_waste += incoming_e_waste

        collected = (
            capacity_available
            * self.collection_efficiency
        )

        self.collected_e_waste += collected

        self.uncollected_e_waste += (
            incoming_e_waste - collected
        )

        if not math.isinf(self.capacity):

            self.available_capacity = max(
                0.0,
                self.available_capacity - collected
            )

        return collected

    def reset_period(self):

        self.received_e_waste = 0.0
        self.collected_e_waste = 0.0
        self.uncollected_e_waste = 0.0

        self.available_capacity = self.capacity

    def step(self):
        pass


# ============================================================
# RECYCLER AGENT
# ============================================================

class RecyclerAgent(BaseAgent):

    def __init__(
        self,
        unique_id,
        model=None,
        processing_capacity=float("inf"),
        recovery_rate=0.80
    ):

        super().__init__(unique_id, model)

        self.processing_capacity = max(
            0.0,
            safe_float(
                processing_capacity,
                float("inf")
            )
        )

        self.recovery_rate = normalize_probability(
            recovery_rate
        )

        self.received_e_waste = 0.0
        self.processed_e_waste = 0.0
        self.recovered_material = 0.0
        self.residual_waste = 0.0

        self.available_capacity = self.processing_capacity

    def process(self, collected_e_waste):

        collected_e_waste = max(
            0.0,
            safe_float(collected_e_waste, 0.0)
        )

        if math.isinf(self.processing_capacity):

            processable = collected_e_waste

        else:

            processable = min(
                collected_e_waste,
                max(0.0, self.available_capacity)
            )

        self.received_e_waste += collected_e_waste

        self.processed_e_waste += processable

        recovered = (
            processable * self.recovery_rate
        )

        residual = (
            processable - recovered
        )

        self.recovered_material += recovered
        self.residual_waste += residual

        if not math.isinf(self.processing_capacity):

            self.available_capacity = max(
                0.0,
                self.available_capacity - processable
            )

        return recovered, residual

    def reset_period(self):

        self.received_e_waste = 0.0
        self.processed_e_waste = 0.0
        self.recovered_material = 0.0
        self.residual_waste = 0.0

        self.available_capacity = self.processing_capacity

    def step(self):
        pass


# ============================================================
# AGENT MODEL CONTAINER
# ============================================================

class EWasteAgentModel:

    def __init__(
        self,
        num_consumers=100,
        num_collectors=1,
        num_recyclers=1,
        seed=42,
        consumer_parameters=None,
        collector_parameters=None,
        recycler_parameters=None
    ):

        self.seed = seed
        self.rng = random.Random(seed)

        self.consumer_parameters = (
            consumer_parameters or {}
        )

        self.collector_parameters = (
            collector_parameters or {}
        )

        self.recycler_parameters = (
            recycler_parameters or {}
        )

        self.consumers = []
        self.collectors = []
        self.recyclers = []

        self._create_agents(
            num_consumers,
            num_collectors,
            num_recyclers
        )

    # --------------------------------------------------------
    # AGENT CREATION
    # --------------------------------------------------------

    def _create_agents(
        self,
        num_consumers,
        num_collectors,
        num_recyclers
    ):

        for i in range(
            safe_int(num_consumers, 0)
        ):

            agent = ConsumerAgent(
                unique_id=f"C_{i + 1}",
                model=self,
                **self.consumer_parameters
            )

            self.consumers.append(agent)

        for i in range(
            safe_int(num_collectors, 0)
        ):

            agent = CollectionAgent(
                unique_id=f"COL_{i + 1}",
                model=self,
                **self.collector_parameters
            )

            self.collectors.append(agent)

        for i in range(
            safe_int(num_recyclers, 0)
        ):

            agent = RecyclerAgent(
                unique_id=f"REC_{i + 1}",
                model=self,
                **self.recycler_parameters
            )

            self.recyclers.append(agent)

    # --------------------------------------------------------
    # ONE PERIOD
    # --------------------------------------------------------

    def run_period(self):

        # Reset collection and recycling state.
        for collector in self.collectors:
            collector.reset_period()

        for recycler in self.recyclers:
            recycler.reset_period()

        # Consumer behavior.
        for consumer in self.consumers:

            consumer.step()

        # ----------------------------------------------------
        # FORMAL STREAM
        # ----------------------------------------------------

        formal_e_waste = sum(
            consumer.formal_e_waste
            for consumer in self.consumers
        )

        # ----------------------------------------------------
        # INFORMAL STREAM
        # ----------------------------------------------------

        informal_e_waste = sum(
            consumer.informal_e_waste
            for consumer in self.consumers
        )

        # ----------------------------------------------------
        # COLLECTION
        # ----------------------------------------------------

        collected = 0.0

        if self.collectors:

            collector_share = (
                formal_e_waste
                / len(self.collectors)
            )

            for collector in self.collectors:

                collected += collector.collect(
                    collector_share
                )

        # ----------------------------------------------------
        # RECYCLING
        # ----------------------------------------------------

        recovered = 0.0
        residual = 0.0
        processed = 0.0

        if self.recyclers:

            recycler_share = (
                collected
                / len(self.recyclers)
            )

            for recycler in self.recyclers:

                r, res = recycler.process(
                    recycler_share
                )

                recovered += r
                residual += res
                processed += (
                    r + res
                )

        # ----------------------------------------------------
        # OUTPUT
        # ----------------------------------------------------

        generated = sum(
            consumer.generated_e_waste
            for consumer in self.consumers
        )

        formal_participation = 0.0

        if self.consumers:

            formal_participation = (
                sum(
                    1
                    for consumer in self.consumers
                    if consumer.formal_collection
                )
                / len(self.consumers)
                * 100.0
            )

        collection_rate = 0.0

        if formal_e_waste > 0:

            collection_rate = (
                collected
                / formal_e_waste
                * 100.0
            )

        recovery_rate = 0.0

        if processed > 0:

            recovery_rate = (
                recovered
                / processed
                * 100.0
            )

        return {
            "Generated E-waste (kg)": generated,
            "Formal E-waste (kg)": formal_e_waste,
            "Informal E-waste (kg)": informal_e_waste,
            "Collected E-waste (kg)": collected,
            "Processed E-waste (kg)": processed,
            "Recovered Material (kg)": recovered,
            "Residual Waste (kg)": residual,
            "Collection Rate (%)": collection_rate,
            "Recovery Rate (%)": recovery_rate,
            "Formal Participation (%)": formal_participation
        }


# ============================================================
# PARAMETER MAPPING
# ============================================================

def find_parameter(parameters, keywords, default):

    lowered = {
        str(key).lower(): value
        for key, value in parameters.items()
    }

    for key, value in lowered.items():

        for keyword in keywords:

            if keyword.lower() in key:

                return value

    return default


def create_model_parameters(base_parameters):

    num_consumers = safe_int(
        find_parameter(
            base_parameters,
            [
                "number of consumers",
                "num consumers",
                "consumer population",
                "consumers"
            ],
            100
        ),
        100
    )

    num_collectors = safe_int(
        find_parameter(
            base_parameters,
            [
                "number of collectors",
                "num collectors",
                "collectors"
            ],
            1
        ),
        1
    )

    num_recyclers = safe_int(
        find_parameter(
            base_parameters,
            [
                "number of recyclers",
                "num recyclers",
                "recyclers"
            ],
            1
        ),
        1
    )

    awareness = find_parameter(
        base_parameters,
        ["awareness"],
        0.5
    )

    incentive = find_parameter(
        base_parameters,
        ["incentive"],
        0.5
    )

    accessibility = find_parameter(
        base_parameters,
        ["accessibility"],
        0.5
    )

    convenience = find_parameter(
        base_parameters,
        ["convenience"],
        0.5
    )

    trust = find_parameter(
        base_parameters,
        ["trust"],
        0.5
    )

    generation = find_parameter(
        base_parameters,
        [
            "e-waste generation",
            "ewaste generation",
            "waste generation",
            "generation"
        ],
        1.0
    )

    formal_preference = find_parameter(
        base_parameters,
        [
            "formal preference",
            "formal collection preference"
        ],
        0.5
    )

    collection_efficiency = find_parameter(
        base_parameters,
        [
            "collection efficiency",
            "collection rate"
        ],
        0.80
    )

    recovery_rate = find_parameter(
        base_parameters,
        [
            "recovery rate",
            "material recovery"
        ],
        0.80
    )

    collector_capacity = find_parameter(
        base_parameters,
        [
            "collector capacity",
            "collection capacity"
        ],
        float("inf")
    )

    recycler_capacity = find_parameter(
        base_parameters,
        [
            "recycler capacity",
            "processing capacity"
        ],
        float("inf")
    )

    consumer_parameters = {
        "awareness": awareness,
        "incentive": incentive,
        "accessibility": accessibility,
        "convenience": convenience,
        "trust": trust,
        "e_waste_generation": generation,
        "formal_preference": formal_preference
    }

    collector_parameters = {
        "capacity": collector_capacity,
        "collection_efficiency": collection_efficiency
    }

    recycler_parameters = {
        "processing_capacity": recycler_capacity,
        "recovery_rate": recovery_rate
    }

    return {
        "num_consumers": num_consumers,
        "num_collectors": num_collectors,
        "num_recyclers": num_recyclers,
        "consumer_parameters": consumer_parameters,
        "collector_parameters": collector_parameters,
        "recycler_parameters": recycler_parameters
    }


# ============================================================
# AGENT TEST
# ============================================================

def run_agent_test(model_parameters):

    print_header("STEP 1.2 - AGENT CREATION TEST")

    model = EWasteAgentModel(
        num_consumers=5,
        num_collectors=max(
            1,
            model_parameters["num_collectors"]
        ),
        num_recyclers=max(
            1,
            model_parameters["num_recyclers"]
        ),
        seed=42,
        consumer_parameters=model_parameters[
            "consumer_parameters"
        ],
        collector_parameters=model_parameters[
            "collector_parameters"
        ],
        recycler_parameters=model_parameters[
            "recycler_parameters"
        ]
    )

    print(
        f"[PASS] Consumer agents  : {len(model.consumers)}"
    )

    print(
        f"[PASS] Collector agents : {len(model.collectors)}"
    )

    print(
        f"[PASS] Recycler agents  : {len(model.recyclers)}"
    )

    return model


# ============================================================
# BEHAVIOR TEST
# ============================================================

def run_behavior_test(model):

    print_header("STEP 1.3 - BEHAVIORAL DECISION TEST")

    rows = []

    for consumer in model.consumers:

        consumer.step()

        rows.append(
            {
                "Agent ID": consumer.unique_id,
                "Awareness": round(
                    consumer.awareness,
                    6
                ),
                "Incentive": round(
                    consumer.incentive,
                    6
                ),
                "Accessibility": round(
                    consumer.accessibility,
                    6
                ),
                "Convenience": round(
                    consumer.convenience,
                    6
                ),
                "Trust": round(
                    consumer.trust,
                    6
                ),
                "Decision Score": round(
                    consumer.decision_score,
                    6
                ),
                "Formal Probability": round(
                    consumer.formal_probability * 100,
                    4
                ),
                "Formal Collection": consumer.formal_collection,
                "Generated E-waste (kg)": round(
                    consumer.generated_e_waste,
                    6
                )
            }
        )

    for row in rows:

        print(
            f"{row['Agent ID']:>6} | "
            f"Score={row['Decision Score']:.4f} | "
            f"Formal Prob={row['Formal Probability']:.2f}% | "
            f"Formal={row['Formal Collection']} | "
            f"E-waste={row['Generated E-waste (kg)']:.4f} kg"
        )

    return rows


# ============================================================
# FLOW TEST
# ============================================================

def run_flow_test(model_parameters):

    print_header("STEP 1.4 - AGENT FLOW TEST")

    model = EWasteAgentModel(
        num_consumers=10,
        num_collectors=max(
            1,
            model_parameters["num_collectors"]
        ),
        num_recyclers=max(
            1,
            model_parameters["num_recyclers"]
        ),
        seed=12345,
        consumer_parameters=model_parameters[
            "consumer_parameters"
        ],
        collector_parameters=model_parameters[
            "collector_parameters"
        ],
        recycler_parameters=model_parameters[
            "recycler_parameters"
        ]
    )

    result = model.run_period()

    for key, value in result.items():

        print(
            f"{key:<30}: {value:.6f}"
        )

    # --------------------------------------------------------
    # BASIC MASS-BALANCE CHECK
    # --------------------------------------------------------

    generated = result[
        "Generated E-waste (kg)"
    ]

    formal = result[
        "Formal E-waste (kg)"
    ]

    informal = result[
        "Informal E-waste (kg)"
    ]

    collected = result[
        "Collected E-waste (kg)"
    ]

    processed = result[
        "Processed E-waste (kg)"
    ]

    recovered = result[
        "Recovered Material (kg)"
    ]

    residual = result[
        "Residual Waste (kg)"
    ]

    checks = []

    checks.append(
        abs(
            generated
            - formal
            - informal
        ) < 1e-8
    )

    checks.append(
        processed
        <= collected + 1e-8
    )

    checks.append(
        abs(
            processed
            - recovered
            - residual
        ) < 1e-8
    )

    if all(checks):

        print(
            "[PASS] Agent flow and mass-balance checks passed."
        )

    else:

        print(
            "[FAIL] Agent flow or mass-balance check failed."
        )

    return result, all(checks)


# ============================================================
# EXPORT AGENT SPECIFICATION
# ============================================================

def export_agent_specification(model_parameters):

    print_header("STEP 1.5 - EXPORTING AGENT SPECIFICATION")

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    agent_rows = [

        {
            "Agent Type": "ConsumerAgent",
            "Role": "E-waste generator and collection decision-maker",
            "Main Attributes": (
                "Awareness; Incentive; Accessibility; "
                "Convenience; Trust; E-waste generation"
            ),
            "Behavior": (
                "Probabilistic formal/informal collection decision"
            ),
            "Output": (
                "Generated E-waste; Formal E-waste; "
                "Informal E-waste"
            )
        },

        {
            "Agent Type": "CollectionAgent",
            "Role": "Collection system actor",
            "Main Attributes": (
                "Capacity; Collection efficiency"
            ),
            "Behavior": (
                "Receives formal e-waste and applies "
                "collection efficiency"
            ),
            "Output": (
                "Collected E-waste; Uncollected E-waste"
            )
        },

        {
            "Agent Type": "RecyclerAgent",
            "Role": "Recycling and material recovery actor",
            "Main Attributes": (
                "Processing capacity; Recovery rate"
            ),
            "Behavior": (
                "Processes collected e-waste and "
                "separates recovered material and residual"
            ),
            "Output": (
                "Processed E-waste; Recovered Material; "
                "Residual Waste"
            )
        }
    ]

    save_csv(
        OUTPUT_DIR / "STEP01_AGENT_SPECIFICATION.csv",
        agent_rows,
        [
            "Agent Type",
            "Role",
            "Main Attributes",
            "Behavior",
            "Output"
        ]
    )

    parameter_rows = []

    for name, value in model_parameters[
        "consumer_parameters"
    ].items():

        parameter_rows.append(
            {
                "Agent Type": "ConsumerAgent",
                "Parameter": name,
                "Value": value
            }
        )

    for name, value in model_parameters[
        "collector_parameters"
    ].items():

        parameter_rows.append(
            {
                "Agent Type": "CollectionAgent",
                "Parameter": name,
                "Value": value
            }
        )

    for name, value in model_parameters[
        "recycler_parameters"
    ].items():

        parameter_rows.append(
            {
                "Agent Type": "RecyclerAgent",
                "Parameter": name,
                "Value": value
            }
        )

    save_csv(
        OUTPUT_DIR / "STEP01_AGENT_PARAMETERS.csv",
        parameter_rows,
        [
            "Agent Type",
            "Parameter",
            "Value"
        ]
    )

    print(
        f"[SAVED] {OUTPUT_DIR / 'STEP01_AGENT_SPECIFICATION.csv'}"
    )

    print(
        f"[SAVED] {OUTPUT_DIR / 'STEP01_AGENT_PARAMETERS.csv'}"
    )


# ============================================================
# STEP 1 REPORT
# ============================================================

def generate_report(
    model_parameters,
    behavior_rows,
    flow_result,
    flow_pass
):

    report = []

    report.append(
        "E-WASTE ABM\n"
    )

    report.append(
        "STEP 1: AGENT & BEHAVIORAL MODEL REPORT\n"
    )

    report.append(
        "=" * 100 + "\n\n"
    )

    report.append(
        "1. AGENT STRUCTURE\n"
    )

    report.append(
        "-" * 100 + "\n"
    )

    report.append(
        "ConsumerAgent   : E-waste generator and "
        "formal/informal collection decision-maker.\n"
    )

    report.append(
        "CollectionAgent : Collects e-waste entering "
        "the formal collection pathway.\n"
    )

    report.append(
        "RecyclerAgent   : Processes collected e-waste "
        "and determines recovered material and residual waste.\n\n"
    )

    report.append(
        "2. MODEL PARAMETERS\n"
    )

    report.append(
        "-" * 100 + "\n"
    )

    report.append(
        f"Consumers       : {model_parameters['num_consumers']}\n"
    )

    report.append(
        f"Collectors      : {model_parameters['num_collectors']}\n"
    )

    report.append(
        f"Recyclers       : {model_parameters['num_recyclers']}\n\n"
    )

    report.append(
        "Consumer parameters:\n"
    )

    for key, value in model_parameters[
        "consumer_parameters"
    ].items():

        report.append(
            f"  {key:<25}: {value}\n"
        )

    report.append("\n")

    report.append(
        "Collector parameters:\n"
    )

    for key, value in model_parameters[
        "collector_parameters"
    ].items():

        report.append(
            f"  {key:<25}: {value}\n"
        )

    report.append("\n")

    report.append(
        "Recycler parameters:\n"
    )

    for key, value in model_parameters[
        "recycler_parameters"
    ].items():

        report.append(
            f"  {key:<25}: {value}\n"
        )

    report.append("\n")

    report.append(
        "3. BEHAVIORAL TEST\n"
    )

    report.append(
        "-" * 100 + "\n"
    )

    for row in behavior_rows:

        report.append(
            f"{row['Agent ID']}: "
            f"Decision Score={row['Decision Score']}; "
            f"Formal Probability={row['Formal Probability']}%; "
            f"Formal={row['Formal Collection']}\n"
        )

    report.append("\n")

    report.append(
        "4. FLOW TEST\n"
    )

    report.append(
        "-" * 100 + "\n"
    )

    for key, value in flow_result.items():

        report.append(
            f"{key:<30}: {value:.6f}\n"
        )

    report.append("\n")

    report.append(
        "5. VALIDATION\n"
    )

    report.append(
        "-" * 100 + "\n"
    )

    if flow_pass:

        report.append(
            "Agent flow validation : PASS\n"
        )

        report.append(
            "Mass-balance validation: PASS\n"
        )

    else:

        report.append(
            "Agent flow validation : FAIL\n"
        )

        report.append(
            "Mass-balance validation: FAIL\n"
        )

    report.append("\n")

    report.append(
        "STEP 1 STATUS: "
        + ("PASS" if flow_pass else "FAIL")
        + "\n"
    )

    report.append(
        "=" * 100 + "\n"
    )

    save_text(
        OUTPUT_DIR / "STEP01_AGENT_BEHAVIOR_REPORT.txt",
        "".join(report)
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print_header(
        "E-WASTE ABM\n"
        "STEP 1: AGENT & BEHAVIORAL MODEL"
    )

    print(
        f"Project root : {PROJECT_ROOT}"
    )

    print(
        f"Output       : {OUTPUT_DIR}"
    )

    # --------------------------------------------------------
    # LOAD STEP 0
    # --------------------------------------------------------

    base_rows, scenario_rows, json_config = (
        load_parameter_configuration()
    )

    base_parameters = build_parameter_dictionary(
        base_rows
    )

    # --------------------------------------------------------
    # CREATE MODEL PARAMETERS
    # --------------------------------------------------------

    print_header(
        "STEP 1.2 - BUILDING MODEL PARAMETER MAPPING"
    )

    model_parameters = create_model_parameters(
        base_parameters
    )

    print(
        f"[PASS] Consumer count : "
        f"{model_parameters['num_consumers']}"
    )

    print(
        f"[PASS] Collector count: "
        f"{model_parameters['num_collectors']}"
    )

    print(
        f"[PASS] Recycler count : "
        f"{model_parameters['num_recyclers']}"
    )

    # --------------------------------------------------------
    # AGENT TEST
    # --------------------------------------------------------

    model = run_agent_test(
        model_parameters
    )

    # --------------------------------------------------------
    # BEHAVIOR TEST
    # --------------------------------------------------------

    behavior_rows = run_behavior_test(
        model
    )

    # --------------------------------------------------------
    # FLOW TEST
    # --------------------------------------------------------

    flow_result, flow_pass = run_flow_test(
        model_parameters
    )

    # --------------------------------------------------------
    # EXPORT
    # --------------------------------------------------------

    export_agent_specification(
        model_parameters
    )

    # --------------------------------------------------------
    # BEHAVIOR CSV
    # --------------------------------------------------------

    save_csv(
        OUTPUT_DIR / "STEP01_BEHAVIOR_TEST.csv",
        behavior_rows,
        [
            "Agent ID",
            "Awareness",
            "Incentive",
            "Accessibility",
            "Convenience",
            "Trust",
            "Decision Score",
            "Formal Probability",
            "Formal Collection",
            "Generated E-waste (kg)"
        ]
    )

    # --------------------------------------------------------
    # FLOW CSV
    # --------------------------------------------------------

    flow_rows = [
        {
            "Metric": key,
            "Value": value
        }
        for key, value in flow_result.items()
    ]

    save_csv(
        OUTPUT_DIR / "STEP01_FLOW_TEST.csv",
        flow_rows,
        [
            "Metric",
            "Value"
        ]
    )

    # --------------------------------------------------------
    # REPORT
    # --------------------------------------------------------

    generate_report(
        model_parameters,
        behavior_rows,
        flow_result,
        flow_pass
    )

    # --------------------------------------------------------
    # FINAL
    # --------------------------------------------------------

    print_header(
        "STEP 1 FINAL SUMMARY"
    )

    print(
        "Agent structure      : PASS"
    )

    print(
        "Behavioral decision  : PASS"
    )

    print(
        "Collection flow      : "
        + ("PASS" if flow_pass else "FAIL")
    )

    print(
        "Mass balance         : "
        + ("PASS" if flow_pass else "FAIL")
    )

    print()

    if flow_pass:

        print(
            "STEP 1 COMPLETE"
        )

    else:

        print(
            "STEP 1 FAILED - REVIEW OUTPUT"
        )

    print(
        "=" * 100
    )


if __name__ == "__main__":
    main()