"""
E-WASTE ABM - STEP 6: MODEL VALIDATION & CALIBRATION
Compatible with the actual outputs of STEP 0-5.
"""

from pathlib import Path
import json
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parent
S00 = ROOT / "results_step00"
S01 = ROOT / "results_step01"
S02 = ROOT / "results_step02"
S05 = ROOT / "results_step05"
S06 = ROOT / "results_step06"

TABLES = S06 / "tables"
FIGURES = S06 / "figures"
TABLES.mkdir(parents=True, exist_ok=True)
FIGURES.mkdir(parents=True, exist_ok=True)

ALPHA = 0.05

SCENARIOS = [
    "Baseline",
    "Scenario 1 - Formal-Informal Integration",
    "Scenario 2 - Economic Incentives",
    "Scenario 3 - Information & Traceability",
    "Scenario 4 - Producer Responsibility",
    "Scenario 5 - Combined Orchestration",
]

EXPECTED_REPLICATES = 30
EXPECTED_PERIODS = 12

CORE_COLUMNS = [
    "Scenario",
    "Replicate",
    "Period",
    "Generated E-waste (kg)",
    "Formal E-waste (kg)",
    "Informal E-waste (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
]


def banner(x):
    print("\n" + "=" * 100)
    print(x)
    print("=" * 100)


def section(x):
    print("\n" + "=" * 100)
    print(x)
    print("=" * 100)


def status(ok, category, detail):
    print(f"[{'PASS' if ok else 'FAIL'}] {category:<40} | {detail}")


def save(df, path):
    df.to_csv(path, index=False)
    print(f"[SAVED] {path}")


def savefig(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"[SAVED] {path}")


def get_col(df, names):
    for n in names:
        if n in df.columns:
            return n
    norm = {
        str(c).strip().lower().replace("_", " "): c
        for c in df.columns
    }
    for n in names:
        k = str(n).strip().lower().replace("_", " ")
        if k in norm:
            return norm[k]
    return None


# ============================================================
# HEADER
# ============================================================

banner("""E-WASTE ABM
STEP 6: MODEL VALIDATION & CALIBRATION
FINAL COMPATIBLE VERSION""")

print(f"Project root : {ROOT}")
print(f"Output       : {S06}")


# ============================================================
# STEP 6.1
# ============================================================

section("STEP 6.1 - LOADING STEP 0-2 AND STEP 5 RESULTS")

files = {
    "STEP 2 raw simulation":
        S02 / "STEP02_RAW_SIMULATION_RESULTS.csv",
    "STEP 2 scenario summary":
        S02 / "STEP02_SCENARIO_SUMMARY.csv",
    "STEP 2 period results":
        S02 / "STEP02_PERIOD_RESULTS.csv",
    "STEP 0 parameter JSON":
        S00 / "ABM_PARAMETER_CONFIG.json",
    "STEP 0 base parameters":
        S00 / "ABM_BASE_PARAMETERS.csv",
    "STEP 1 agent specification":
        S01 / "STEP01_AGENT_SPECIFICATION.csv",
    "STEP 1 agent parameters":
        S01 / "STEP01_AGENT_PARAMETERS.csv",
    "STEP 5 sensitivity results":
        S05 / "tables" / "02_sensitivity_results.csv",
}

file_ok = True
for label, path in files.items():
    ok = path.exists()
    file_ok &= ok
    status(ok, "File integrity", f"{label}: {path}")

if not file_ok:
    raise FileNotFoundError("One or more required STEP 0-5 files are missing.")

raw = pd.read_csv(files["STEP 2 raw simulation"])
scenario_summary = pd.read_csv(files["STEP 2 scenario summary"])
period_results = pd.read_csv(files["STEP 2 period results"])
base_parameters = pd.read_csv(files["STEP 0 base parameters"])
agent_spec = pd.read_csv(files["STEP 1 agent specification"])
agent_params = pd.read_csv(files["STEP 1 agent parameters"])
sens = pd.read_csv(files["STEP 5 sensitivity results"])

with open(files["STEP 0 parameter JSON"], "r", encoding="utf-8") as f:
    parameter_config = json.load(f)

print(f"Raw simulation rows : {len(raw)}")
print(f"Scenario rows       : {len(scenario_summary)}")
print(f"Period rows         : {len(period_results)}")
print(f"Base parameters     : {len(base_parameters)}")
print(f"Agent specifications: {len(agent_spec)}")
print(f"Agent parameters    : {len(agent_params)}")
print(f"Sensitivity rows    : {len(sens)}")


# ============================================================
# STEP 6.2
# ============================================================

section("STEP 6.2 - SIMULATION COLUMN VALIDATION")

column_rows = []

for col in CORE_COLUMNS:
    ok = col in raw.columns
    column_rows.append({
        "Check": "Column available",
        "Column": col,
        "Status": "PASS" if ok else "FAIL"
    })
    status(ok, "Column available", col)

# IMPORTANT:
# Actual STEP 2 output uses System Cost (USD), not System Cost (Rp).
system_cost_col = get_col(
    raw,
    [
        "System Cost (USD)",
        "System Cost (Rp)",
        "System Cost",
        "System Cost USD",
        "System Cost Rp",
    ],
)

cost_ok = system_cost_col is not None

column_rows.append({
    "Check": "System cost compatibility",
    "Column": system_cost_col if system_cost_col else "Not found",
    "Status": "PASS" if cost_ok else "FAIL"
})

status(
    cost_ok,
    "System cost compatibility",
    f"{system_cost_col} accepted" if cost_ok else "No compatible cost column found"
)

missing_core = [c for c in CORE_COLUMNS if c not in raw.columns]

if missing_core:
    raise ValueError(
        "Required STEP 2 columns are missing:\n" +
        "\n".join(missing_core)
    )

if not cost_ok:
    raise ValueError(
        "STEP 2 must contain System Cost (USD) or System Cost (Rp)."
    )

raw["System Cost"] = pd.to_numeric(raw[system_cost_col], errors="coerce")

save(
    pd.DataFrame(column_rows),
    TABLES / "01_column_validation.csv"
)


# ============================================================
# NUMERIC NORMALIZATION
# ============================================================

numeric_cols = [
    "Replicate",
    "Period",
    "Generated E-waste (kg)",
    "Formal E-waste (kg)",
    "Informal E-waste (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
    "System Cost",
]

for c in numeric_cols:
    raw[c] = pd.to_numeric(raw[c], errors="coerce")

raw["Scenario"] = raw["Scenario"].astype(str).str.strip()


# ============================================================
# STEP 6.3
# ============================================================

section("STEP 6.3 - DATA INTEGRITY VALIDATION")

checks = []

def add_check(name, ok, detail):
    checks.append({
        "Check": name,
        "Status": "PASS" if ok else "FAIL",
        "Details": detail,
    })
    status(ok, "Data integrity", f"{name}: {detail}")


add_check(
    "Raw simulation non-empty",
    len(raw) > 0,
    f"Rows={len(raw)}"
)

actual_scenarios = raw["Scenario"].dropna().unique().tolist()
missing_scenarios = [x for x in SCENARIOS if x not in actual_scenarios]
unexpected_scenarios = [x for x in actual_scenarios if x not in SCENARIOS]

add_check(
    "Expected scenarios present",
    len(missing_scenarios) == 0,
    f"Missing={missing_scenarios if missing_scenarios else 'None'}"
)

add_check(
    "No unexpected scenarios",
    len(unexpected_scenarios) == 0,
    f"Unexpected={unexpected_scenarios if unexpected_scenarios else 'None'}"
)

add_check(
    "Scenario values complete",
    raw["Scenario"].notna().all(),
    f"Missing={raw['Scenario'].isna().sum()}"
)

add_check(
    "Replicate values complete",
    raw["Replicate"].notna().all(),
    f"Missing={raw['Replicate'].isna().sum()}"
)

add_check(
    "Period values complete",
    raw["Period"].notna().all(),
    f"Missing={raw['Period'].isna().sum()}"
)

finite_failures = []
for c in numeric_cols:
    v = raw[c].to_numpy(dtype=float)
    if len(v) == 0 or not np.isfinite(v).all():
        finite_failures.append(c)

add_check(
    "Numeric simulation fields finite",
    len(finite_failures) == 0,
    "All numeric fields finite"
    if not finite_failures else
    f"Invalid={finite_failures}"
)

save(pd.DataFrame(checks), TABLES / "02_data_integrity_validation.csv")


# ============================================================
# STEP 6.4
# ============================================================

section("STEP 6.4 - REPLICATION AND PERIOD VALIDATION")

rep_rows = []

for s in SCENARIOS:
    d = raw[raw["Scenario"] == s]
    nr = d["Replicate"].nunique()
    npd = d["Period"].nunique()
    rows = len(d)
    expected = EXPECTED_REPLICATES * EXPECTED_PERIODS

    ok = (
        nr == EXPECTED_REPLICATES and
        npd == EXPECTED_PERIODS and
        rows == expected
    )

    rep_rows.append({
        "Scenario": s,
        "Replicates": nr,
        "Periods": npd,
        "Rows": rows,
        "Expected Replicates": EXPECTED_REPLICATES,
        "Expected Periods": EXPECTED_PERIODS,
        "Expected Rows": expected,
        "Status": "PASS" if ok else "FAIL",
    })

    status(
        ok,
        "Replication structure",
        f"{s} | Replicates={nr} | Periods={npd} | Rows={rows}"
    )

rep_df = pd.DataFrame(rep_rows)
save(rep_df, TABLES / "03_replication_validation.csv")


# ============================================================
# STEP 6.5
# ============================================================

section("STEP 6.5 - MODEL LOGIC AND PHYSICAL VALIDATION")

logic_rows = []

# Formal + informal = generated
diff = (
    raw["Formal E-waste (kg)"] +
    raw["Informal E-waste (kg)"] -
    raw["Generated E-waste (kg)"]
)

mass_ok = np.isfinite(diff).all() and np.all(np.abs(diff) <= 1e-6)

logic_rows.append({
    "Check": "Formal + Informal = Generated E-waste",
    "Status": "PASS" if mass_ok else "FAIL",
    "Maximum Absolute Difference (kg)": float(np.max(np.abs(diff))),
})
status(
    mass_ok,
    "Mass balance",
    f"Maximum difference={np.max(np.abs(diff)):.10f} kg"
)

# Percentages must be 0-100.
for c in [
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
]:
    v = raw[c].to_numpy(dtype=float)
    ok = (
        np.isfinite(v).all() and
        np.all(v >= 0) and
        np.all(v <= 100)
    )

    logic_rows.append({
        "Check": f"{c} within 0-100%",
        "Status": "PASS" if ok else "FAIL",
        "Minimum": float(np.min(v)),
        "Maximum": float(np.max(v)),
    })

    status(
        ok,
        "Range validation",
        f"{c}: min={np.min(v):.4f}, max={np.max(v):.4f}"
    )

# Physical quantities cannot be negative.
for c in [
    "Generated E-waste (kg)",
    "Formal E-waste (kg)",
    "Informal E-waste (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Ending Inventory (kg)",
    "System Cost",
]:
    v = raw[c].to_numpy(dtype=float)
    ok = np.isfinite(v).all() and np.all(v >= -1e-9)

    logic_rows.append({
        "Check": f"{c} non-negative",
        "Status": "PASS" if ok else "FAIL",
        "Minimum": float(np.min(v)),
        "Maximum": float(np.max(v)),
    })

    status(
        ok,
        "Non-negative validation",
        f"{c}: minimum={np.min(v):.8f}"
    )

logic_df = pd.DataFrame(logic_rows)
save(logic_df, TABLES / "04_model_logic_validation.csv")


# ============================================================
# STEP 6.6
# ============================================================

section("STEP 6.6 - REPLICATE-LEVEL VALIDATION DATASET")

replicate_rows = []

for (scenario, replicate), d in raw.groupby(
    ["Scenario", "Replicate"],
    dropna=False
):
    d = d.sort_values("Period")

    generated = d["Generated E-waste (kg)"].sum()
    formal = d["Formal E-waste (kg)"].sum()
    informal = d["Informal E-waste (kg)"].sum()
    recovered = d["Recovered Material (kg)"].sum()
    residual = d["Residual Waste (kg)"].sum()
    cost = d["System Cost"].sum()

    collection_rate = (
        formal / generated * 100
        if generated > 0 else np.nan
    )

    row = {
        "Scenario": scenario,
        "Replicate": replicate,
        "Generated E-waste (kg)": generated,
        "Formal E-waste (kg)": formal,
        "Informal E-waste (kg)": informal,
        "Recovered Material (kg)": recovered,
        "Residual Waste (kg)": residual,
        "Collection Rate (%)": collection_rate,
        "Recovery Rate (%)": d["Recovery Rate (%)"].mean(),
        "Formal Participation (%)": d["Formal Participation (%)"].mean(),
        "Ending Inventory (kg)": d.iloc[-1]["Ending Inventory (kg)"],
        "System Cost": cost,
    }

    replicate_rows.append(row)

replicate_df = pd.DataFrame(replicate_rows)

print(f"Replicate-level rows : {len(replicate_df)}")
print(replicate_df["Scenario"].value_counts())

save(
    replicate_df,
    TABLES / "05_replicate_level_validation_data.csv"
)


# ============================================================
# STEP 6.7
# ============================================================

section("STEP 6.7 - SCENARIO VALIDATION SUMMARY")

metrics = [
    "Generated E-waste (kg)",
    "Formal E-waste (kg)",
    "Informal E-waste (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
    "Ending Inventory (kg)",
    "System Cost",
]

summary_rows = []

for s in SCENARIOS:
    d = replicate_df[replicate_df["Scenario"] == s]

    row = {
        "Scenario": s,
        "Replicates": len(d),
    }

    for m in metrics:
        row[f"{m} Mean"] = d[m].mean()
        row[f"{m} SD"] = d[m].std(ddof=1)
        row[f"{m} Minimum"] = d[m].min()
        row[f"{m} Maximum"] = d[m].max()

    summary_rows.append(row)

summary_df = pd.DataFrame(summary_rows)
save(summary_df, TABLES / "06_scenario_validation_summary.csv")


# ============================================================
# STEP 6.8
# ============================================================

section("STEP 6.8 - STEP 5 SENSITIVITY OUTPUT VALIDATION")

required_sens = [
    "Parameter Label",
    "Base Value",
    "Minimum Recovered (kg)",
    "Maximum Recovered (kg)",
    "Sensitivity Range (%)",
    "Low Change (%)",
    "High Change (%)",
    "Elasticity",
    "Sensitivity Rank",
]

sens_check_rows = []

for c in required_sens:
    ok = c in sens.columns
    sens_check_rows.append({
        "Check": f"Column available: {c}",
        "Status": "PASS" if ok else "FAIL",
        "Details": "Available" if ok else "Missing",
    })
    status(ok, "Sensitivity column", c)

missing_sens = [c for c in required_sens if c not in sens.columns]

if missing_sens:
    raise ValueError(
        "STEP 5 sensitivity columns missing:\n" +
        "\n".join(missing_sens)
    )

for c in required_sens[1:]:
    sens[c] = pd.to_numeric(sens[c], errors="coerce")

bad_numeric = []

for c in required_sens[1:]:
    if not np.isfinite(sens[c].to_numpy(dtype=float)).all():
        bad_numeric.append(c)

sens_numeric_ok = len(bad_numeric) == 0

sens_check_rows.append({
    "Check": "Sensitivity numeric fields finite",
    "Status": "PASS" if sens_numeric_ok else "FAIL",
    "Details": "All finite" if sens_numeric_ok else str(bad_numeric),
})

status(
    sens_numeric_ok,
    "Sensitivity numeric fields",
    "All finite" if sens_numeric_ok else str(bad_numeric)
)

parameters = sens["Parameter Label"].dropna().astype(str).unique().tolist()
parameter_count_ok = len(parameters) == 7

sens_check_rows.append({
    "Check": "Sensitivity parameter count",
    "Status": "PASS" if parameter_count_ok else "FAIL",
    "Details": f"Expected=7, Detected={len(parameters)}",
})

status(
    parameter_count_ok,
    "Sensitivity parameter count",
    f"Expected=7, Detected={len(parameters)}"
)

range_ok = (
    np.isfinite(sens["Sensitivity Range (%)"]).all()
    and (sens["Sensitivity Range (%)"] >= 0).all()
)

sens_check_rows.append({
    "Check": "Sensitivity ranges valid",
    "Status": "PASS" if range_ok else "FAIL",
    "Details": "All ranges non-negative and finite",
})

status(
    range_ok,
    "Sensitivity ranges",
    "All ranges non-negative and finite"
)

save(
    pd.DataFrame(sens_check_rows),
    TABLES / "07_sensitivity_validation.csv"
)


# ============================================================
# STEP 6.9
# ============================================================

section("STEP 6.9 - SCENARIO 5 CALIBRATION REFERENCE")

s5 = replicate_df[
    replicate_df["Scenario"] == SCENARIOS[5]
].copy()

calibration = {
    "Recovered Material (kg)": s5["Recovered Material (kg)"].mean(),
    "Collected Formal E-waste (kg)": s5["Formal E-waste (kg)"].mean(),
    "Collection Rate (%)": s5["Collection Rate (%)"].mean(),
    "Formal Participation (%)": s5["Formal Participation (%)"].mean(),
    "System Cost": s5["System Cost"].mean(),
}

cal_rows = []

for metric, value in calibration.items():
    ok = np.isfinite(value)
    cal_rows.append({
        "Scenario": SCENARIOS[5],
        "Metric": metric,
        "Reference Mean": value,
        "Status": "PASS" if ok else "FAIL",
    })
    status(
        ok,
        "Calibration reference",
        f"{metric}={value:.6f}" if ok else f"{metric}=invalid"
    )

save(pd.DataFrame(cal_rows), TABLES / "08_calibration_reference.csv")


# ============================================================
# STEP 6.10 FIGURES
# ============================================================

section("STEP 6.10 - GENERATING VALIDATION FIGURES")

# Figure 1
fig, ax = plt.subplots(figsize=(12, 7))
x = np.arange(len(SCENARIOS))
means = []
stds = []

for s in SCENARIOS:
    v = replicate_df.loc[
        replicate_df["Scenario"] == s,
        "Recovered Material (kg)"
    ]
    means.append(v.mean())
    stds.append(v.std(ddof=1))

ax.bar(x, means, yerr=stds, capsize=5)
ax.set_xticks(x)
ax.set_xticklabels(["Baseline", "S1", "S2", "S3", "S4", "S5"])
ax.set_xlabel("Scenario")
ax.set_ylabel("Recovered Material (kg)")
ax.set_title("Model Validation: Recovered Material by Scenario")
ax.grid(axis="y", alpha=0.25)
savefig(fig, FIGURES / "01_validation_recovered_material.png")

# Figure 2
fig, ax = plt.subplots(figsize=(12, 7))
vals = [
    replicate_df.loc[
        replicate_df["Scenario"] == s,
        "Collection Rate (%)"
    ].mean()
    for s in SCENARIOS
]

ax.bar(x, vals)
ax.set_xticks(x)
ax.set_xticklabels(["Baseline", "S1", "S2", "S3", "S4", "S5"])
ax.set_xlabel("Scenario")
ax.set_ylabel("Collection Rate (%)")
ax.set_title("Model Validation: Collection Rate by Scenario")
ax.set_ylim(0, 105)
ax.grid(axis="y", alpha=0.25)
savefig(fig, FIGURES / "02_validation_collection_rate.png")

# Figure 3
fig, ax = plt.subplots(figsize=(11, 7))
sp = sens.sort_values("Sensitivity Rank", ascending=True)
ax.barh(
    sp["Parameter Label"].astype(str),
    sp["Sensitivity Range (%)"]
)
ax.set_xlabel("Sensitivity Range (%)")
ax.set_ylabel("Parameter")
ax.set_title("Model Validation: STEP 5 Sensitivity Ranking")
ax.grid(axis="x", alpha=0.25)
savefig(fig, FIGURES / "03_validation_sensitivity_ranking.png")

# Figure 4
fig, ax = plt.subplots(figsize=(9, 7))
ax.boxplot(
    s5["Recovered Material (kg)"].dropna().to_numpy()
)
ax.set_ylabel("Recovered Material (kg)")
ax.set_title(
    "Scenario 5 - Combined Orchestration\n"
    "Replicate-Level Validation"
)
ax.grid(axis="y", alpha=0.25)
savefig(fig, FIGURES / "04_scenario5_recovered_material_boxplot.png")


# ============================================================
# STEP 6.11 FINAL MATRIX
# ============================================================

section("STEP 6.11 - FINAL VALIDATION MATRIX")

final_rows = []

def final_add(name, ok, detail):
    final_rows.append({
        "Check": name,
        "Status": "PASS" if ok else "FAIL",
        "Details": detail,
    })
    status(ok, "Final validation", f"{name}: {detail}")


final_add(
    "Input files",
    file_ok,
    "All STEP 0-2 and STEP 5 files available"
)

final_add(
    "Simulation columns",
    len(missing_core) == 0 and cost_ok,
    f"System cost source={system_cost_col}"
)

final_add(
    "Replication structure",
    (rep_df["Status"] == "PASS").all(),
    "6 scenarios x 30 replicates x 12 periods"
)

final_add(
    "Data integrity",
    (pd.DataFrame(checks)["Status"] == "PASS").all(),
    "Identifiers and numeric fields validated"
)

final_add(
    "Model logic",
    (logic_df["Status"] == "PASS").all(),
    "Mass balance, ranges and physical values validated"
)

final_add(
    "Sensitivity output",
    sens_numeric_ok and parameter_count_ok and range_ok,
    "STEP 5 sensitivity results compatible"
)

fig_ok = all(
    p.exists() for p in [
        FIGURES / "01_validation_recovered_material.png",
        FIGURES / "02_validation_collection_rate.png",
        FIGURES / "03_validation_sensitivity_ranking.png",
        FIGURES / "04_scenario5_recovered_material_boxplot.png",
    ]
)

final_add(
    "Validation figures",
    fig_ok,
    "4/4 figures generated"
)

final_df = pd.DataFrame(final_rows)
save(final_df, TABLES / "09_final_validation_matrix.csv")


# ============================================================
# STEP 6.12 REPORT
# ============================================================

section("STEP 6.12 - GENERATING STEP 6 REPORT")

overall_pass = (final_df["Status"] == "PASS").all()

report = []
report.append("=" * 100)
report.append("E-WASTE ABM")
report.append("STEP 6: MODEL VALIDATION & CALIBRATION")
report.append("FINAL VALIDATION REPORT")
report.append("=" * 100)
report.append("")
report.append(f"Project root : {ROOT}")
report.append(f"STEP 2 raw rows : {len(raw)}")
report.append(f"Replicate-level rows : {len(replicate_df)}")
report.append(f"Scenarios : {len(SCENARIOS)}")
report.append(f"Replicates/scenario : {EXPECTED_REPLICATES}")
report.append(f"Periods/scenario : {EXPECTED_PERIODS}")
report.append("")
report.append("SYSTEM COST COMPATIBILITY")
report.append("-" * 100)
report.append(f"Detected source column : {system_cost_col}")
report.append("Standardized internal column : System Cost")
report.append("")
report.append("SCENARIO 5 CALIBRATION REFERENCE")
report.append("-" * 100)

for k, v in calibration.items():
    report.append(f"{k}: {v:.6f}")

report.append("")
report.append("FINAL VALIDATION")
report.append("-" * 100)

for _, r in final_df.iterrows():
    report.append(
        f"[{r['Status']}] {r['Check']} | {r['Details']}"
    )

report.append("")
report.append("=" * 100)
report.append(
    f"STEP 6 STATUS : {'PASS' if overall_pass else 'FAIL'}"
)
report.append("=" * 100)

report_path = S06 / "STEP06_MODEL_VALIDATION_REPORT.txt"
report_path.write_text("\n".join(report), encoding="utf-8")
print(f"[SAVED] {report_path}")


# ============================================================
# FINAL SUMMARY
# ============================================================

section("STEP 6 FINAL SUMMARY")

print(f"Scenarios analyzed       : {len(SCENARIOS)}")
print(f"Replicate-level rows     : {len(replicate_df)}")
print(f"Metrics validated        : {len(metrics)}")
print(f"Sensitivity parameters   : {len(parameters)}")
print(f"Validation figures       : 4")
print(
    f"Validation failures      : "
    f"{int((final_df['Status'] == 'FAIL').sum())}"
)
print(f"Output folder            : {S06}")
print(f"Tables folder            : {TABLES}")
print(f"Figures folder           : {FIGURES}")

print("\n" + "=" * 100)
print(f"STEP 6 STATUS : {'PASS' if overall_pass else 'FAIL'}")
print("=" * 100)

if not overall_pass:
    print("REVIEW REQUIRED")
    raise SystemExit(1)

print("READY FOR NEXT STEP")
