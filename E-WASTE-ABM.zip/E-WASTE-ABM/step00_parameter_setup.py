from pathlib import Path
import json
import csv
import sys


# ============================================================
# E-WASTE ABM
# STEP 0: PARAMETER ELICITATION & MODEL CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_ROOT / "results_step00"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# BASIC MODEL CONFIGURATION
# ============================================================

MODEL_CONFIG = {
    "model_name": "E-Waste Agent-Based Model",
    "version": "STEP 0 - Parameter Configuration",
    "source": "Supplementary Material S6 - ABM Parameter Elicitation Data",
    "number_of_experts": 10,
    "experts": [f"E{i}" for i in range(1, 11)],

    # Initial simulation configuration.
    # These are MODEL DESIGN settings, not elicited expert parameters.
    "simulation": {
        "households": 1000,
        "informal_collectors": 50,
        "aggregators": 10,
        "formal_recyclers": 2,
        "producers": 10,
        "regulators": 1,

        "time_unit": "month",
        "simulation_months": 12,

        "replications": 30,

        "random_seed": 42
    },

    "currency": "USD",

    "scenarios": [
        "Baseline",
        "Scenario 1 - Formal-Informal Integration",
        "Scenario 2 - Economic Incentives",
        "Scenario 3 - Information & Traceability",
        "Scenario 4 - Producer Responsibility",
        "Scenario 5 - Combined Orchestration"
    ]
}


# ============================================================
# C1 - CONSUMER PARAMETERS
# Source: S6 Table C1
# ============================================================

CONSUMER_PARAMETERS = {
    "e_waste_generation_kg_household_year": {
        "value": 8.25,
        "minimum": 5.35,
        "maximum": 12.25,
        "confidence": 4.1,
        "unit": "kg/household/year"
    },

    "consumer_participation_rate": {
        "value": 0.207,
        "minimum": 0.113,
        "maximum": 0.347,
        "confidence": 3.1,
        "unit": "proportion"
    },

    "price_sensitivity": {
        "value": 0.47,
        "minimum": 0.29,
        "maximum": 0.66,
        "confidence": 3.5,
        "unit": "0-1"
    },

    "disposal_behavior_baseline": {
        "value": 0.676,
        "minimum": 0.535,
        "maximum": 0.817,
        "confidence": 4.1,
        "unit": "proportion"
    }
}


# ============================================================
# C2 - INFORMAL COLLECTOR / DISMANTLER
# Source: S6 Table C2
# ============================================================

INFORMAL_PARAMETERS = {
    "collection_capacity_kg_collector_day": {
        "value": 23.9,
        "minimum": 15.5,
        "maximum": 39.1,
        "confidence": 3.9,
        "unit": "kg/collector/day"
    },

    "collection_cost_usd_kg": {
        "value": 0.337,
        "minimum": 0.242,
        "maximum": 0.476,
        "confidence": 4.0,
        "unit": "USD/kg"
    },

    "dismantling_capacity_kg_day": {
        "value": 19.4,
        "minimum": 12.3,
        "maximum": 33.5,
        "confidence": 3.5,
        "unit": "kg/day"
    },

    "dismantling_cost_usd_kg": {
        "value": 0.389,
        "minimum": 0.285,
        "maximum": 0.578,
        "confidence": 4.0,
        "unit": "USD/kg"
    },

    "manual_recovery_rate": {
        "value": 0.653,
        "minimum": 0.553,
        "maximum": 0.755,
        "confidence": 3.1,
        "unit": "proportion"
    },

    "selling_price_sensitivity": {
        "value": 0.76,
        "minimum": 0.56,
        "maximum": 0.90,
        "confidence": 3.9,
        "unit": "0-1"
    },

    "regulatory_compliance_cost_usd_actor_year": {
        "value": 134.0,
        "minimum": 88.0,
        "maximum": 257.0,
        "confidence": 3.2,
        "unit": "USD/actor/year"
    },

    "formalization_willingness": {
        "value": 0.50,
        "minimum": 0.31,
        "maximum": 0.69,
        "confidence": 3.4,
        "unit": "0-1"
    }
}


# ============================================================
# C3 - AGGREGATOR / TRADER
# Source: S6 Table C3
# ============================================================

AGGREGATOR_PARAMETERS = {
    "aggregation_capacity_tons_month": {
        "value": 42.7,
        "minimum": 27.3,
        "maximum": 69.7,
        "confidence": 3.9,
        "unit": "tons/month"
    },

    "transaction_cost_usd_kg": {
        "value": 0.147,
        "minimum": 0.098,
        "maximum": 0.236,
        "confidence": 4.0,
        "unit": "USD/kg"
    },

    "material_quality_assessment_accuracy": {
        "value": 0.754,
        "minimum": 0.653,
        "maximum": 0.853,
        "confidence": 3.2,
        "unit": "proportion"
    },

    "price_negotiation_flexibility": {
        "value": 0.65,
        "minimum": 0.45,
        "maximum": 0.84,
        "confidence": 3.7,
        "unit": "0-1"
    },

    "information_access": {
        "value": 0.47,
        "minimum": 0.27,
        "maximum": 0.65,
        "confidence": 3.2,
        "unit": "0-1"
    }
}


# ============================================================
# C4 - FORMAL RECYCLER
# Source: S6 Table C4
# ============================================================

RECYCLER_PARAMETERS = {
    "processing_capacity_tons_month": {
        "value": 506.0,
        "minimum": 328.0,
        "maximum": 780.0,
        "confidence": 4.1,
        "unit": "tons/month"
    },

    "processing_cost_usd_kg": {
        "value": 0.835,
        "minimum": 0.623,
        "maximum": 1.165,
        "confidence": 4.1,
        "unit": "USD/kg"
    },

    "mechanical_recovery_rate": {
        "value": 0.894,
        "minimum": 0.842,
        "maximum": 0.941,
        "confidence": 4.3,
        "unit": "proportion"
    },

    "technology_efficiency": {
        "value": 0.840,
        "minimum": 0.740,
        "maximum": 0.922,
        "confidence": 4.2,
        "unit": "proportion"
    },

    "environmental_compliance_cost_usd_year": {
        "value": 11600.0,
        "minimum": 6200.0,
        "maximum": 21400.0,
        "confidence": 3.5,
        "unit": "USD/year"
    },

    "capacity_utilization_rate": {
        "value": 0.605,
        "minimum": 0.468,
        "maximum": 0.760,
        "confidence": 4.0,
        "unit": "proportion"
    },

    "technology_investment_usd_year": {
        "value": 15200.0,
        "minimum": 8200.0,
        "maximum": 27100.0,
        "confidence": 3.3,
        "unit": "USD/year"
    }
}


# ============================================================
# C5 - PRODUCER
# Source: S6 Table C5
# ============================================================

PRODUCER_PARAMETERS = {
    "epr_compliance_cost_usd_year": {
        "value": 27100.0,
        "minimum": 15800.0,
        "maximum": 44000.0,
        "confidence": 3.6,
        "unit": "USD/year"
    },

    "producer_engagement_level": {
        "value": 0.32,
        "minimum": 0.16,
        "maximum": 0.50,
        "confidence": 3.9,
        "unit": "0-1"
    },

    "design_for_recyclability": {
        "value": 0.25,
        "minimum": 0.15,
        "maximum": 0.44,
        "confidence": 4.4,
        "unit": "0-1"
    },

    "willingness_to_finance_recovery": {
        "value": 0.34,
        "minimum": 0.19,
        "maximum": 0.55,
        "confidence": 3.7,
        "unit": "0-1"
    },

    "collaboration_with_informal_sector": {
        "value": 0.26,
        "minimum": 0.12,
        "maximum": 0.45,
        "confidence": 3.6,
        "unit": "0-1"
    }
}


# ============================================================
# C6 - REGULATOR
# Source: S6 Table C6
# ============================================================

REGULATOR_PARAMETERS = {
    "enforcement_intensity": {
        "value": 0.40,
        "minimum": 0.18,
        "maximum": 0.55,
        "confidence": 4.3,
        "unit": "0-1"
    },

    "monitoring_capacity": {
        "value": 0.30,
        "minimum": 0.17,
        "maximum": 0.47,
        "confidence": 4.3,
        "unit": "0-1"
    },

    "policy_implementation_effectiveness": {
        "value": 0.40,
        "minimum": 0.18,
        "maximum": 0.55,
        "confidence": 4.3,
        "unit": "0-1"
    },

    "institutional_capacity": {
        "value": 0.40,
        "minimum": 0.18,
        "maximum": 0.55,
        "confidence": 4.3,
        "unit": "0-1"
    },

    "formal_informal_integration_support": {
        "value": 0.40,
        "minimum": 0.16,
        "maximum": 0.50,
        "confidence": 3.4,
        "unit": "0-1"
    }
}


# ============================================================
# C7 - NETWORK / INTERACTION
# Source: S6 Table C7
# ============================================================

NETWORK_PARAMETERS = {
    "network_connectivity_density": {
        "value": 0.49,
        "minimum": 0.30,
        "maximum": 0.69,
        "confidence": 3.9,
        "unit": "0-1"
    },

    "information_flow_quality": {
        "value": 0.35,
        "minimum": 0.20,
        "maximum": 0.54,
        "confidence": 4.1,
        "unit": "0-1"
    },

    "transaction_trust_level": {
        "value": 0.47,
        "minimum": 0.29,
        "maximum": 0.66,
        "confidence": 4.0,
        "unit": "0-1"
    },

    "cooperation_competition_intensity": {
        "value": 0.37,
        "minimum": 0.20,
        "maximum": 0.55,
        "confidence": 3.6,
        "unit": "0-1"
    },

    "formal_informal_interdependence": {
        "value": 0.69,
        "minimum": 0.50,
        "maximum": 0.83,
        "confidence": 4.0,
        "unit": "0-1"
    }
}


# ============================================================
# D2 - SCENARIO ADJUSTMENTS
# Source: S6 Table D2
# ============================================================

SCENARIO_PARAMETERS = {

    "formalization_incentive_usd": {
        "Baseline": 200.0,
        "Scenario 1 - Formal-Informal Integration": 605.0,
        "Scenario 2 - Economic Incentives": 200.0,
        "Scenario 3 - Information & Traceability": 200.0,
        "Scenario 4 - Producer Responsibility": 335.0,
        "Scenario 5 - Combined Orchestration": 705.0
    },

    "collection_incentive_usd_kg": {
        "Baseline": 0.121,
        "Scenario 1 - Formal-Informal Integration": 0.121,
        "Scenario 2 - Economic Incentives": 0.555,
        "Scenario 3 - Information & Traceability": 0.121,
        "Scenario 4 - Producer Responsibility": 0.183,
        "Scenario 5 - Combined Orchestration": 0.655
    },

    "traceability_adoption_cost_usd": {
        "Baseline": 1000.0,
        "Scenario 1 - Formal-Informal Integration": 1000.0,
        "Scenario 2 - Economic Incentives": 1000.0,
        "Scenario 3 - Information & Traceability": 455.0,
        "Scenario 4 - Producer Responsibility": 1000.0,
        "Scenario 5 - Combined Orchestration": 360.0
    },

    "epr_compliance_requirement": {
        "Baseline": 0.295,
        "Scenario 1 - Formal-Informal Integration": 0.295,
        "Scenario 2 - Economic Incentives": 0.295,
        "Scenario 3 - Information & Traceability": 0.295,
        "Scenario 4 - Producer Responsibility": 0.640,
        "Scenario 5 - Combined Orchestration": 0.750
    },

    "information_transparency_level": {
        "Baseline": 0.24,
        "Scenario 1 - Formal-Informal Integration": 0.34,
        "Scenario 2 - Economic Incentives": 0.24,
        "Scenario 3 - Information & Traceability": 0.79,
        "Scenario 4 - Producer Responsibility": 0.34,
        "Scenario 5 - Combined Orchestration": 0.88
    },

    "regulatory_enforcement_intensity": {
        "Baseline": 0.26,
        "Scenario 1 - Formal-Informal Integration": 0.36,
        "Scenario 2 - Economic Incentives": 0.26,
        "Scenario 3 - Information & Traceability": 0.26,
        "Scenario 4 - Producer Responsibility": 0.46,
        "Scenario 5 - Combined Orchestration": 0.56
    }
}


# ============================================================
# ALL PARAMETERS
# ============================================================

ALL_PARAMETERS = {
    "consumer": CONSUMER_PARAMETERS,
    "informal_collector_dismantler": INFORMAL_PARAMETERS,
    "aggregator_trader": AGGREGATOR_PARAMETERS,
    "formal_recycler": RECYCLER_PARAMETERS,
    "producer": PRODUCER_PARAMETERS,
    "regulator": REGULATOR_PARAMETERS,
    "network": NETWORK_PARAMETERS
}


# ============================================================
# VALIDATION FUNCTIONS
# ============================================================

def validate_parameter(name, parameter):
    errors = []

    if "value" not in parameter:
        errors.append(f"{name}: missing value")

    if "minimum" not in parameter:
        errors.append(f"{name}: missing minimum")

    if "maximum" not in parameter:
        errors.append(f"{name}: missing maximum")

    if "confidence" not in parameter:
        errors.append(f"{name}: missing confidence")

    if "unit" not in parameter:
        errors.append(f"{name}: missing unit")

    if errors:
        return errors

    value = parameter["value"]
    minimum = parameter["minimum"]
    maximum = parameter["maximum"]
    confidence = parameter["confidence"]

    if minimum > maximum:
        errors.append(
            f"{name}: minimum > maximum"
        )

    if not (minimum <= value <= maximum):
        errors.append(
            f"{name}: value {value} outside "
            f"range [{minimum}, {maximum}]"
        )

    if not (1 <= confidence <= 5):
        errors.append(
            f"{name}: confidence outside 1-5"
        )

    return errors


def validate_all_parameters():
    errors = []

    for category, parameters in ALL_PARAMETERS.items():
        for name, parameter in parameters.items():
            errors.extend(
                validate_parameter(
                    f"{category}.{name}",
                    parameter
                )
            )

    return errors


def validate_scenarios():
    errors = []

    scenario_names = MODEL_CONFIG["scenarios"]

    for parameter_name, values in SCENARIO_PARAMETERS.items():

        missing = [
            scenario
            for scenario in scenario_names
            if scenario not in values
        ]

        if missing:
            errors.append(
                f"{parameter_name}: missing scenarios {missing}"
            )

    return errors


# ============================================================
# CSV EXPORT
# ============================================================

def export_parameter_csv():

    output_file = OUTPUT_DIR / "ABM_BASE_PARAMETERS.csv"

    rows = []

    for category, parameters in ALL_PARAMETERS.items():

        for name, parameter in parameters.items():

            rows.append({
                "Category": category,
                "Parameter": name,
                "Value": parameter["value"],
                "Minimum": parameter["minimum"],
                "Maximum": parameter["maximum"],
                "Confidence": parameter["confidence"],
                "Unit": parameter["unit"]
            })

    fieldnames = [
        "Category",
        "Parameter",
        "Value",
        "Minimum",
        "Maximum",
        "Confidence",
        "Unit"
    ]

    with open(
        output_file,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(rows)

    return output_file


def export_scenario_csv():

    output_file = OUTPUT_DIR / "ABM_SCENARIO_PARAMETERS.csv"

    scenario_names = MODEL_CONFIG["scenarios"]

    rows = []

    for parameter_name, values in SCENARIO_PARAMETERS.items():

        row = {
            "Parameter": parameter_name
        }

        for scenario in scenario_names:
            row[scenario] = values[scenario]

        rows.append(row)

    fieldnames = [
        "Parameter"
    ] + scenario_names

    with open(
        output_file,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(rows)

    return output_file


# ============================================================
# JSON EXPORT
# ============================================================

def export_json():

    output_file = OUTPUT_DIR / "ABM_PARAMETER_CONFIG.json"

    complete_config = {
        "model_config": MODEL_CONFIG,
        "base_parameters": ALL_PARAMETERS,
        "scenario_parameters": SCENARIO_PARAMETERS
    }

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            complete_config,
            f,
            indent=4,
            ensure_ascii=False
        )

    return output_file


# ============================================================
# HUMAN-READABLE REPORT
# ============================================================

def export_report():

    output_file = OUTPUT_DIR / "STEP00_PARAMETER_REPORT.txt"

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as f:

        f.write("=" * 100 + "\n")
        f.write("E-WASTE ABM\n")
        f.write("STEP 0: PARAMETER ELICITATION & MODEL CONFIGURATION\n")
        f.write("=" * 100 + "\n\n")

        f.write("SOURCE\n")
        f.write("-" * 100 + "\n")
        f.write(
            "Supplementary Material S6 - "
            "ABM Parameter Elicitation Data\n"
        )
        f.write(
            "Experts: E1-E10\n"
        )
        f.write("\n")

        f.write("BASE PARAMETERS\n")
        f.write("-" * 100 + "\n")

        for category, parameters in ALL_PARAMETERS.items():

            f.write(f"\n[{category.upper()}]\n")

            for name, parameter in parameters.items():

                f.write(
                    f"{name}: "
                    f"value={parameter['value']}, "
                    f"min={parameter['minimum']}, "
                    f"max={parameter['maximum']}, "
                    f"confidence={parameter['confidence']}\n"
                )

        f.write("\n")
        f.write("SCENARIO PARAMETERS\n")
        f.write("-" * 100 + "\n")

        for parameter_name, values in SCENARIO_PARAMETERS.items():

            f.write(f"\n{parameter_name}\n")

            for scenario in MODEL_CONFIG["scenarios"]:

                f.write(
                    f"  {scenario}: "
                    f"{values[scenario]}\n"
                )

        f.write("\n")
        f.write("SIMULATION CONFIGURATION\n")
        f.write("-" * 100 + "\n")

        for key, value in MODEL_CONFIG["simulation"].items():

            f.write(
                f"{key}: {value}\n"
            )

        f.write("\n")
        f.write("VALIDATION STATUS\n")
        f.write("-" * 100 + "\n")
        f.write("All parameters successfully loaded and validated.\n")

    return output_file


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=" * 100)
    print("E-WASTE ABM")
    print("STEP 0: PARAMETER ELICITATION & MODEL CONFIGURATION")
    print("=" * 100)

    print()
    print(f"Project root : {PROJECT_ROOT}")
    print(f"Output       : {OUTPUT_DIR}")

    print()
    print("=" * 100)
    print("STEP 0.1 - VALIDATING BASE PARAMETERS")
    print("=" * 100)

    parameter_errors = validate_all_parameters()

    if parameter_errors:

        for error in parameter_errors:
            print(f"[FAIL] {error}")

        print()
        print("STEP 0 FAILED.")
        sys.exit(1)

    print(
        f"[PASS] Base parameters validated: "
        f"{sum(len(v) for v in ALL_PARAMETERS.values())} parameters."
    )

    print()
    print("=" * 100)
    print("STEP 0.2 - VALIDATING SCENARIO PARAMETERS")
    print("=" * 100)

    scenario_errors = validate_scenarios()

    if scenario_errors:

        for error in scenario_errors:
            print(f"[FAIL] {error}")

        print()
        print("STEP 0 FAILED.")
        sys.exit(1)

    print(
        f"[PASS] Scenario parameters validated: "
        f"{len(SCENARIO_PARAMETERS)} parameters."
    )

    print()
    print("=" * 100)
    print("STEP 0.3 - EXPORTING CONFIGURATION")
    print("=" * 100)

    base_csv = export_parameter_csv()
    scenario_csv = export_scenario_csv()
    json_file = export_json()
    report_file = export_report()

    print(f"[SAVED] {base_csv}")
    print(f"[SAVED] {scenario_csv}")
    print(f"[SAVED] {json_file}")
    print(f"[SAVED] {report_file}")

    print()
    print("=" * 100)
    print("STEP 0.4 - SCENARIO OVERVIEW")
    print("=" * 100)

    for i, scenario in enumerate(
        MODEL_CONFIG["scenarios"],
        start=0
    ):
        print(f"{i}. {scenario}")

    print()
    print("=" * 100)
    print("STEP 0 FINAL SUMMARY")
    print("=" * 100)

    print("Base parameters : PASS")
    print("Scenario data   : PASS")
    print("Configuration   : PASS")
    print("Exports         : PASS")

    print()
    print("STEP 0 COMPLETE")
    print("=" * 100)


if __name__ == "__main__":
    main()