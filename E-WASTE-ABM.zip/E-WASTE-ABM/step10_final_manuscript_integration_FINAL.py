"""
E-WASTE ABM
STEP 10: FINAL THESIS / JOURNAL RESULTS & DISCUSSION INTEGRATION
FINAL COMPATIBLE VERSION

Purpose
-------
Integrates the authoritative outputs from STEP 09 into a final,
traceable Results & Discussion package.

Important
---------
- No new simulation is performed.
- No upstream values are fabricated or silently replaced.
- STEP 09 outputs are treated as the primary evidence source.
- Scenario, statistical, effect-size, sensitivity, and validation
  evidence are preserved as separate evidence classes.
- python-docx is loaded dynamically to avoid false Pylance warnings
  when VS Code and the terminal use different interpreters.

Expected upstream:
    results_step09/
        STEP09_MANUSCRIPT_RESULTS.docx
        STEP09_FINAL_RESULTS_REPORT.txt
        tables/
            03_final_scenario_results.csv
            04_baseline_intervention_effects.csv
            05_statistical_evidence.csv
            06_effect_size_summary.csv
            07_sensitivity_results_final.csv
            08_validation_evidence_final.csv
            09_key_findings.csv
            10_manuscript_evidence_map.csv
            11_final_step09_validation.csv
        figures/
            01_final_recovered_material_by_scenario.png
            02_collection_and_participation.png
            03_final_sensitivity_ranking.png
            04_scenario5_recovered_material_distribution.png

Run:
    python -m py_compile step10_final_manuscript_integration_FINAL.py
    python step10_final_manuscript_integration_FINAL.py
"""

from __future__ import annotations

import importlib
import math
import re
import textwrap
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# ---------------------------------------------------------------------
# OPTIONAL LIBRARIES
# ---------------------------------------------------------------------
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    MPL_AVAILABLE = True
    MPL_ERROR = ""
except Exception as exc:
    plt = None
    MPL_AVAILABLE = False
    MPL_ERROR = str(exc)

try:
    _docx = importlib.import_module("docx")
    _docx_shared = importlib.import_module("docx.shared")
    _docx_text = importlib.import_module("docx.enum.text")
    _docx_table = importlib.import_module("docx.enum.table")

    Document = _docx.Document
    Inches = _docx_shared.Inches
    Pt = _docx_shared.Pt
    WD_ALIGN_PARAGRAPH = _docx_text.WD_ALIGN_PARAGRAPH
    WD_TABLE_ALIGNMENT = _docx_table.WD_TABLE_ALIGNMENT
    DOCX_AVAILABLE = True
    DOCX_ERROR = ""
except Exception as exc:
    Document = None
    Inches = None
    Pt = None
    WD_ALIGN_PARAGRAPH = None
    WD_TABLE_ALIGNMENT = None
    DOCX_AVAILABLE = False
    DOCX_ERROR = str(exc)

# ---------------------------------------------------------------------
# PATHS
# ---------------------------------------------------------------------
ROOT = Path.cwd()
UPSTREAM = ROOT / "results_step09"
OUT = ROOT / "results_step10"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
MANUSCRIPT = OUT / "manuscript"

for folder in (OUT, TABLES, FIGURES, MANUSCRIPT):
    folder.mkdir(parents=True, exist_ok=True)

SCENARIOS = {
    0: "Baseline",
    1: "Scenario 1 - Formal-Informal Integration",
    2: "Scenario 2 - Economic Incentives",
    3: "Scenario 3 - Information & Traceability",
    4: "Scenario 4 - Producer Responsibility",
    5: "Scenario 5 - Combined Orchestration",
}
SCENARIO_ORDER = list(SCENARIOS.values())

EXPECTED_FILES = {
    "STEP 9 Master/Results": UPSTREAM / "tables" / "03_final_scenario_results.csv",
    "STEP 9 Baseline/Intervention": UPSTREAM / "tables" / "04_baseline_intervention_effects.csv",
    "STEP 9 Statistical Evidence": UPSTREAM / "tables" / "05_statistical_evidence.csv",
    "STEP 9 Effect Sizes": UPSTREAM / "tables" / "06_effect_size_summary.csv",
    "STEP 9 Sensitivity": UPSTREAM / "tables" / "07_sensitivity_results_final.csv",
    "STEP 9 Validation": UPSTREAM / "tables" / "08_validation_evidence_final.csv",
    "STEP 9 Key Findings": UPSTREAM / "tables" / "09_key_findings.csv",
    "STEP 9 Evidence Map": UPSTREAM / "tables" / "10_manuscript_evidence_map.csv",
    "STEP 9 Final Validation": UPSTREAM / "tables" / "11_final_step09_validation.csv",
    "STEP 9 Manuscript": UPSTREAM / "STEP09_MANUSCRIPT_RESULTS.docx",
    "STEP 9 Report": UPSTREAM / "STEP09_FINAL_RESULTS_REPORT.txt",
}

# ---------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------
failures: list[str] = []


def banner(title: str) -> None:
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def section(title: str) -> None:
    print("\n" + "-" * 100)
    print(title)
    print("-" * 100)


def log(status: str, label: str, details: str) -> None:
    print(f"[{status}] {label:<45} | {details}")


def saved(path: Path) -> None:
    print(f"[SAVED] {path}")


def safe_float(value, default=np.nan):
    try:
        x = float(value)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def fmt(value, digits=4) -> str:
    x = safe_float(value)
    if np.isnan(x):
        return "NA"
    return f"{x:.{digits}f}"


def find_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    normalized = {str(c).strip().lower(): c for c in df.columns}
    for cand in candidates:
        key = cand.strip().lower()
        if key in normalized:
            return normalized[key]

    for cand in candidates:
        key = cand.strip().lower()
        for col in df.columns:
            c = str(col).strip().lower()
            if key in c or c in key:
                return col
    return None


def numeric_series(df: pd.DataFrame, col: str | None) -> pd.Series:
    if col is None or col not in df.columns:
        return pd.Series(dtype=float)
    return pd.to_numeric(df[col], errors="coerce")


def save_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False)
    saved(path)


def load_csv(path: Path, label: str) -> pd.DataFrame:
    if not path.exists():
        failures.append(label)
        raise FileNotFoundError(f"Missing required STEP 09 file: {path}")
    return pd.read_csv(path)


def scenario_name_from_row(row: pd.Series) -> str:
    for col in ["Scenario", "Scenario Name", "Scenario Label"]:
        if col in row.index:
            value = str(row[col])
            if value in SCENARIO_ORDER:
                return value
    return ""


def scenario_col(df: pd.DataFrame) -> str | None:
    return find_col(df, ["Scenario", "Scenario Name", "Scenario Label"])


def metric_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    return find_col(df, candidates)


def scenario_summary_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize STEP 09 scenario results into a publication-oriented table.
    The function is intentionally defensive because STEP 09 versions can
    differ slightly in column naming.
    """
    sc = scenario_col(df)
    if sc is None:
        raise ValueError("Scenario column not found in STEP 09 scenario results.")

    out = pd.DataFrame()
    out["Scenario"] = df[sc].astype(str)

    mappings = {
        "Recovered Material (kg)": [
            "Recovered Material (kg)",
            "Mean Recovered Material (kg)",
            "Recovered Material Mean (kg)",
            "Recovered Mean (kg)",
        ],
        "Collection Rate (%)": [
            "Collection Rate (%)",
            "Mean Collection Rate (%)",
            "Collection Rate Mean (%)",
        ],
        "Formal Participation (%)": [
            "Formal Participation (%)",
            "Mean Formal Participation (%)",
            "Formal Participation Mean (%)",
        ],
        "Residual Waste (kg)": [
            "Residual Waste (kg)",
            "Mean Residual Waste (kg)",
            "Residual Waste Mean (kg)",
        ],
        "System Cost (USD)": [
            "System Cost (USD)",
            "Mean System Cost (USD)",
            "System Cost (USD) Mean",
            "System Cost Mean (USD)",
        ],
        "Generated E-waste (kg)": [
            "Generated E-waste (kg)",
            "Mean Generated E-waste (kg)",
            "Generated E-waste Mean (kg)",
        ],
    }

    for target, candidates in mappings.items():
        col = find_col(df, candidates)
        if col is not None:
            out[target] = numeric_series(df, col)

    # Keep expected scenario order where possible.
    order_map = {name: i for i, name in SCENARIOS.items()}
    out["_order"] = out["Scenario"].map(order_map).fillna(999)
    out = out.sort_values("_order").drop(columns="_order").reset_index(drop=True)

    return out


def get_metric(summary: pd.DataFrame, scenario: str, metric: str) -> float:
    if metric not in summary.columns:
        return np.nan
    rows = summary.loc[summary["Scenario"] == scenario, metric]
    if rows.empty:
        return np.nan
    return safe_float(rows.iloc[0])


def pct_change(new: float, base: float) -> float:
    if np.isnan(new) or np.isnan(base) or base == 0:
        return np.nan
    return (new - base) / abs(base) * 100.0


def write_text(text: str, path: Path) -> None:
    path.write_text(text.rstrip() + "\n", encoding="utf-8")
    saved(path)


# ---------------------------------------------------------------------
# STEP 10.1 - HEADER
# ---------------------------------------------------------------------
banner(
    "E-WASTE ABM\n"
    "STEP 10: FINAL THESIS / JOURNAL RESULTS & DISCUSSION INTEGRATION\n"
    "FINAL COMPATIBLE VERSION"
)
print(f"Project root : {ROOT}")
print(f"Output       : {OUT}")

# ---------------------------------------------------------------------
# STEP 10.2 - UPSTREAM INTEGRITY
# ---------------------------------------------------------------------
section("STEP 10.2 - UPSTREAM STEP 09 FILE INTEGRITY")

integrity_rows = []

for label, path in EXPECTED_FILES.items():
    exists = path.exists()
    status = "PASS" if exists else "FAIL"
    if not exists:
        failures.append(label)
    log(status, "File integrity", f"{label}: {path}")
    integrity_rows.append(
        {
            "Evidence": label,
            "Path": str(path),
            "Exists": exists,
            "Status": status,
        }
    )

integrity_df = pd.DataFrame(integrity_rows)
save_csv(integrity_df, TABLES / "01_upstream_file_integrity.csv")

if failures:
    raise FileNotFoundError(
        "STEP 10 cannot continue because one or more required STEP 09 files are missing."
    )

# ---------------------------------------------------------------------
# STEP 10.3 - LOAD EVIDENCE
# ---------------------------------------------------------------------
section("STEP 10.3 - LOADING STEP 09 AUTHORITATIVE EVIDENCE")

scenario_raw = load_csv(
    EXPECTED_FILES["STEP 9 Master/Results"],
    "STEP 9 Scenario Results",
)
baseline = load_csv(
    EXPECTED_FILES["STEP 9 Baseline/Intervention"],
    "STEP 9 Baseline/Intervention",
)
statistical = load_csv(
    EXPECTED_FILES["STEP 9 Statistical Evidence"],
    "STEP 9 Statistical Evidence",
)
effect_sizes = load_csv(
    EXPECTED_FILES["STEP 9 Effect Sizes"],
    "STEP 9 Effect Sizes",
)
sensitivity = load_csv(
    EXPECTED_FILES["STEP 9 Sensitivity"],
    "STEP 9 Sensitivity",
)
validation = load_csv(
    EXPECTED_FILES["STEP 9 Validation"],
    "STEP 9 Validation",
)
key_findings = load_csv(
    EXPECTED_FILES["STEP 9 Key Findings"],
    "STEP 9 Key Findings",
)
evidence_map = load_csv(
    EXPECTED_FILES["STEP 9 Evidence Map"],
    "STEP 9 Evidence Map",
)
final_validation = load_csv(
    EXPECTED_FILES["STEP 9 Final Validation"],
    "STEP 9 Final Validation",
)

summary = scenario_summary_table(scenario_raw)

print(f"Scenario rows            : {len(summary)}")
print(f"Baseline/intervention    : {len(baseline)}")
print(f"Statistical evidence     : {len(statistical)}")
print(f"Effect-size rows         : {len(effect_sizes)}")
print(f"Sensitivity parameters   : {len(sensitivity)}")
print(f"Validation rows          : {len(validation)}")
print(f"Key findings             : {len(key_findings)}")
print(f"Evidence map rows        : {len(evidence_map)}")

# ---------------------------------------------------------------------
# STEP 10.4 - MASTER RESULTS TABLE
# ---------------------------------------------------------------------
section("STEP 10.4 - FINAL PUBLICATION RESULTS TABLE")

results_table = summary.copy()

# Add baseline-relative changes for key metrics.
base_name = SCENARIOS[0]
combined_name = SCENARIOS[5]

for metric in [
    "Recovered Material (kg)",
    "Collection Rate (%)",
    "Formal Participation (%)",
    "Residual Waste (kg)",
    "System Cost (USD)",
]:
    if metric in results_table.columns:
        base_value = get_metric(results_table, base_name, metric)
        results_table[f"{metric} - Change vs Baseline (%)"] = results_table[
            metric
        ].apply(lambda x: pct_change(safe_float(x), base_value))

results_path = TABLES / "02_final_publication_results_table.csv"
save_csv(results_table, results_path)

# ---------------------------------------------------------------------
# STEP 10.5 - SCENARIO INTERPRETATION
# ---------------------------------------------------------------------
section("STEP 10.5 - SCENARIO RESULTS INTERPRETATION")

interpretation_rows = []

for _, row in results_table.iterrows():
    scenario = str(row["Scenario"])
    recovered = safe_float(row.get("Recovered Material (kg)", np.nan))
    collection = safe_float(row.get("Collection Rate (%)", np.nan))
    participation = safe_float(row.get("Formal Participation (%)", np.nan))
    residual = safe_float(row.get("Residual Waste (kg)", np.nan))
    cost = safe_float(row.get("System Cost (USD)", np.nan))

    interpretation_rows.append(
        {
            "Scenario": scenario,
            "Recovered Material (kg)": recovered,
            "Collection Rate (%)": collection,
            "Formal Participation (%)": participation,
            "Residual Waste (kg)": residual,
            "System Cost (USD)": cost,
            "Recovery Change vs Baseline (%)": pct_change(
                recovered,
                get_metric(results_table, base_name, "Recovered Material (kg)"),
            ),
            "Interpretation": (
                "Scenario-level descriptive evidence; inferential significance "
                "and practical magnitude must be read from the separate statistical "
                "and effect-size evidence."
            ),
        }
    )

scenario_interpretation = pd.DataFrame(interpretation_rows)
save_csv(
    scenario_interpretation,
    TABLES / "03_scenario_results_interpretation.csv",
)

# ---------------------------------------------------------------------
# STEP 10.6 - BASELINE VS INTERVENTION EVIDENCE
# ---------------------------------------------------------------------
section("STEP 10.6 - BASELINE VS INTERVENTION EVIDENCE")

base_copy = baseline.copy()

# Detect scenario and common baseline/effect columns.
b_sc = scenario_col(base_copy)
if b_sc is not None:
    base_copy["Scenario"] = base_copy[b_sc].astype(str)

save_csv(base_copy, TABLES / "04_baseline_intervention_evidence_final.csv")

# ---------------------------------------------------------------------
# STEP 10.7 - STATISTICAL EVIDENCE
# ---------------------------------------------------------------------
section("STEP 10.7 - STATISTICAL EVIDENCE INTERPRETATION")

stat_copy = statistical.copy()

# Detect common inferential columns without assuming one exact STEP 09 schema.
p_col = find_col(
    stat_copy,
    [
        "p-value",
        "p value",
        "P-value",
        "Paired permutation p-value",
        "p",
    ],
)
decision_col = find_col(
    stat_copy,
    [
        "Significant p<0.05",
        "Significant",
        "Decision",
        "Inference",
    ],
)

statistical_interpretation_rows = []

for _, row in stat_copy.iterrows():
    p = safe_float(row[p_col]) if p_col else np.nan
    if not np.isnan(p):
        significance = "significant (p<0.05)" if p < 0.05 else "not significant (p>=0.05)"
    else:
        significance = "not evaluated from a numeric p-value in this row"

    decision = str(row[decision_col]) if decision_col else ""

    statistical_interpretation_rows.append(
        {
            "Source Row": _,
            "p-value": p,
            "Significance Interpretation": significance,
            "Original Decision": decision,
        }
    )

stat_interp = pd.DataFrame(statistical_interpretation_rows)

# Preserve all source evidence in a companion file.
save_csv(stat_copy, TABLES / "05_statistical_evidence_final.csv")
save_csv(stat_interp, TABLES / "06_statistical_interpretation.csv")

# ---------------------------------------------------------------------
# STEP 10.8 - EFFECT SIZE EVIDENCE
# ---------------------------------------------------------------------
section("STEP 10.8 - EFFECT SIZE INTERPRETATION")

effect_copy = effect_sizes.copy()
save_csv(effect_copy, TABLES / "07_effect_size_evidence_final.csv")

effect_notes = []
for idx, row in effect_copy.iterrows():
    effect_notes.append(
        {
            "Source Row": idx,
            "Interpretation": (
                "Effect-size evidence should be interpreted as practical magnitude "
                "and should not be treated as interchangeable with statistical significance."
            ),
        }
    )

save_csv(pd.DataFrame(effect_notes), TABLES / "08_effect_size_interpretation.csv")

# ---------------------------------------------------------------------
# STEP 10.9 - SENSITIVITY / ROBUSTNESS
# ---------------------------------------------------------------------
section("STEP 10.9 - SENSITIVITY & ROBUSTNESS INTERPRETATION")

sens_copy = sensitivity.copy()
save_csv(sens_copy, TABLES / "09_sensitivity_evidence_final.csv")

sens_param_col = find_col(
    sens_copy,
    ["Parameter Label", "Parameter", "Sensitivity Parameter"],
)
sens_rank_col = find_col(
    sens_copy,
    ["Sensitivity Rank", "Rank"],
)
sens_elasticity_col = find_col(
    sens_copy,
    ["Elasticity", "Sensitivity Elasticity"],
)

if sens_rank_col is not None:
    rank_num = pd.to_numeric(sens_copy[sens_rank_col], errors="coerce")
    valid_rank = sens_copy.loc[rank_num.notna()].copy()
    if not valid_rank.empty:
        valid_rank["_rank_num"] = pd.to_numeric(
            valid_rank[sens_rank_col], errors="coerce"
        )
        top_sens_row = valid_rank.sort_values("_rank_num").iloc[0]
        top_parameter = (
            str(top_sens_row[sens_param_col])
            if sens_param_col is not None
            else "Highest-ranked parameter"
        )
        top_elasticity = (
            safe_float(top_sens_row[sens_elasticity_col])
            if sens_elasticity_col is not None
            else np.nan
        )
    else:
        top_parameter = "Not available"
        top_elasticity = np.nan
else:
    top_parameter = "Not available"
    top_elasticity = np.nan

log(
    "PASS",
    "Sensitivity ranking",
    f"Highest-ranked parameter={top_parameter}; elasticity={fmt(top_elasticity, 4)}",
)

# ---------------------------------------------------------------------
# STEP 10.10 - VALIDATION EVIDENCE
# ---------------------------------------------------------------------
section("STEP 10.10 - MODEL VALIDATION EVIDENCE")

validation_copy = validation.copy()
save_csv(validation_copy, TABLES / "10_validation_evidence_final.csv")

status_cols = [
    c for c in validation_copy.columns
    if str(c).strip().lower() in {"status", "validation status", "result"}
]

validation_failures = 0
for c in status_cols:
    values = validation_copy[c].astype(str).str.upper()
    validation_failures += int((values == "FAIL").sum())

log(
    "PASS" if validation_failures == 0 else "FAIL",
    "Validation evidence",
    f"Detected validation failures={validation_failures}",
)

if validation_failures > 0:
    failures.append("Validation evidence")

# ---------------------------------------------------------------------
# STEP 10.11 - KEY FINDINGS
# ---------------------------------------------------------------------
section("STEP 10.11 - FINAL KEY FINDINGS")

save_csv(key_findings, TABLES / "11_key_findings_final.csv")

# ---------------------------------------------------------------------
# STEP 10.12 - EVIDENCE MAP
# ---------------------------------------------------------------------
section("STEP 10.12 - MANUSCRIPT EVIDENCE MAP")

save_csv(evidence_map, TABLES / "12_manuscript_evidence_map_final.csv")

# ---------------------------------------------------------------------
# STEP 10.13 - CLAIM-TO-EVIDENCE MATRIX
# ---------------------------------------------------------------------
section("STEP 10.13 - CLAIM-TO-EVIDENCE AUDIT")

claims = [
    {
        "Claim ID": "C1",
        "Claim Area": "Scenario performance",
        "Claim": "Scenario-level performance is reported from STEP 09 scenario evidence.",
        "Evidence": "02_final_publication_results_table.csv",
        "Status": "SUPPORTED",
    },
    {
        "Claim ID": "C2",
        "Claim Area": "Intervention effects",
        "Claim": "Baseline-relative intervention effects are reported separately from raw descriptive outcomes.",
        "Evidence": "04_baseline_intervention_evidence_final.csv",
        "Status": "SUPPORTED",
    },
    {
        "Claim ID": "C3",
        "Claim Area": "Statistical inference",
        "Claim": "Statistical significance is interpreted from STEP 09 inferential evidence.",
        "Evidence": "05_statistical_evidence_final.csv",
        "Status": "SUPPORTED",
    },
    {
        "Claim ID": "C4",
        "Claim Area": "Practical magnitude",
        "Claim": "Effect sizes are treated as evidence of practical magnitude rather than statistical significance.",
        "Evidence": "07_effect_size_evidence_final.csv",
        "Status": "SUPPORTED",
    },
    {
        "Claim ID": "C5",
        "Claim Area": "Robustness",
        "Claim": f"Sensitivity ranking identifies {top_parameter} as the highest-ranked parameter.",
        "Evidence": "09_sensitivity_evidence_final.csv",
        "Status": "SUPPORTED",
    },
    {
        "Claim ID": "C6",
        "Claim Area": "Validation",
        "Claim": "Model validation evidence contains no detected failures.",
        "Evidence": "10_validation_evidence_final.csv",
        "Status": "SUPPORTED" if validation_failures == 0 else "NOT SUPPORTED",
    },
    {
        "Claim ID": "C7",
        "Claim Area": "Model interpretation",
        "Claim": "Scenario outcomes are model-based and conditional on the implemented assumptions and parameterization.",
        "Evidence": "STEP09_FINAL_RESULTS_REPORT.txt",
        "Status": "SUPPORTED",
    },
    {
        "Claim ID": "C8",
        "Claim Area": "Causality",
        "Claim": "Modeled scenario differences are not automatically interpreted as direct empirical causal effects.",
        "Evidence": "STEP09_MANUSCRIPT_RESULTS.docx",
        "Status": "SUPPORTED",
    },
]

claims_df = pd.DataFrame(claims)
save_csv(claims_df, TABLES / "13_claim_to_evidence_matrix.csv")

# ---------------------------------------------------------------------
# STEP 10.14 - NUMERIC HIGHLIGHTS
# ---------------------------------------------------------------------
section("STEP 10.14 - EXTRACTING NUMERIC HIGHLIGHTS")

best_recovery_scenario = "Not available"
best_recovery = np.nan
best_collection_scenario = "Not available"
best_collection = np.nan
best_participation_scenario = "Not available"
best_participation = np.nan
lowest_cost_scenario = "Not available"
lowest_cost = np.nan

if "Recovered Material (kg)" in results_table.columns:
    rec = pd.to_numeric(results_table["Recovered Material (kg)"], errors="coerce")
    if rec.notna().any():
        idx = rec.idxmax()
        best_recovery_scenario = str(results_table.loc[idx, "Scenario"])
        best_recovery = safe_float(results_table.loc[idx, "Recovered Material (kg)"])

if "Collection Rate (%)" in results_table.columns:
    col = pd.to_numeric(results_table["Collection Rate (%)"], errors="coerce")
    if col.notna().any():
        idx = col.idxmax()
        best_collection_scenario = str(results_table.loc[idx, "Scenario"])
        best_collection = safe_float(results_table.loc[idx, "Collection Rate (%)"])

if "Formal Participation (%)" in results_table.columns:
    part = pd.to_numeric(
        results_table["Formal Participation (%)"],
        errors="coerce",
    )
    if part.notna().any():
        idx = part.idxmax()
        best_participation_scenario = str(results_table.loc[idx, "Scenario"])
        best_participation = safe_float(
            results_table.loc[idx, "Formal Participation (%)"]
        )

if "System Cost (USD)" in results_table.columns:
    cost = pd.to_numeric(results_table["System Cost (USD)"], errors="coerce")
    if cost.notna().any():
        idx = cost.idxmin()
        lowest_cost_scenario = str(results_table.loc[idx, "Scenario"])
        lowest_cost = safe_float(results_table.loc[idx, "System Cost (USD)"])

combined_recovery = get_metric(
    results_table, combined_name, "Recovered Material (kg)"
)
baseline_recovery = get_metric(
    results_table, base_name, "Recovered Material (kg)"
)
combined_recovery_change = pct_change(combined_recovery, baseline_recovery)

highlights = pd.DataFrame(
    [
        ["Highest recovered material", best_recovery_scenario, best_recovery, "kg"],
        ["Highest collection rate", best_collection_scenario, best_collection, "%"],
        ["Highest formal participation", best_participation_scenario, best_participation, "%"],
        ["Lowest system cost", lowest_cost_scenario, lowest_cost, "USD"],
        [
            "Combined vs baseline recovered-material change",
            combined_name,
            combined_recovery_change,
            "%",
        ],
        ["Highest sensitivity parameter", top_parameter, top_elasticity, "elasticity"],
    ],
    columns=["Finding", "Scenario/Parameter", "Value", "Unit"],
)
save_csv(highlights, TABLES / "14_numeric_highlights.csv")

# ---------------------------------------------------------------------
# STEP 10.15 - MANUSCRIPT NARRATIVE
# ---------------------------------------------------------------------
section("STEP 10.15 - GENERATING RESULTS & DISCUSSION NARRATIVE")

def narrative_scenario_table() -> str:
    lines = []
    for _, r in results_table.iterrows():
        scenario = str(r["Scenario"])
        parts = [scenario]

        if "Recovered Material (kg)" in r.index:
            parts.append(
                f"recovered material={fmt(r['Recovered Material (kg)'], 3)} kg"
            )
        if "Collection Rate (%)" in r.index:
            parts.append(
                f"collection rate={fmt(r['Collection Rate (%)'], 3)}%"
            )
        if "Formal Participation (%)" in r.index:
            parts.append(
                f"formal participation={fmt(r['Formal Participation (%)'], 3)}%"
            )
        if "Residual Waste (kg)" in r.index:
            parts.append(
                f"residual waste={fmt(r['Residual Waste (kg)'], 3)} kg"
            )
        if "System Cost (USD)" in r.index:
            parts.append(
                f"system cost={fmt(r['System Cost (USD)'], 3)} USD"
            )

        lines.append("; ".join(parts) + ".")
    return "\n".join(lines)


scenario_narrative = narrative_scenario_table()

results_discussion = f"""
CHAPTER / MANUSCRIPT SECTION
RESULTS AND DISCUSSION
E-WASTE AGENT-BASED MODEL

1. OVERALL SCENARIO RESULTS

The final scenario results were consolidated from the validated STEP 09
evidence package. The analysis contains six modeled scenarios, comprising
a baseline and five intervention configurations. The interpretation below
is based on scenario-level descriptive evidence and does not treat modeled
scenario differences as direct empirical causal effects.

{scenario_narrative}

The scenario comparison provides the descriptive basis for evaluating the
relative performance of the modeled intervention configurations. The
baseline is retained as the reference condition, while intervention
scenarios are interpreted through their changes in recovery, collection,
formal participation, residual waste, and system cost where those metrics
are available in the authoritative STEP 09 evidence.

2. BASELINE-RELATIVE EFFECTS

The baseline-relative evidence is reported separately from the scenario
means so that absolute performance and relative intervention effects are
not conflated. The combined orchestration scenario is:

- Recovered material: {fmt(combined_recovery, 3)} kg
- Baseline recovered material: {fmt(baseline_recovery, 3)} kg
- Change in recovered material: {fmt(combined_recovery_change, 3)}%

These values describe the modeled difference between the combined scenario
and the baseline. They should be interpreted together with the statistical
evidence and effect-size evidence rather than as causal estimates of
real-world intervention effects.

3. STATISTICAL EVIDENCE

The statistical evidence is taken directly from the STEP 09 consolidated
inferential results. Statistical significance and practical magnitude are
treated as separate concepts. A statistically significant result indicates
evidence against the relevant null hypothesis under the specified model
and testing procedure; it does not, by itself, establish operational
importance or real-world causality.

The complete statistical evidence is provided in:
05_statistical_evidence_final.csv

4. EFFECT SIZE AND PRACTICAL MAGNITUDE

Effect-size evidence is retained separately from p-values. This distinction
is important because a small p-value and a large practical effect are not
equivalent statements. The effect-size table should therefore be used when
discussing the magnitude and substantive relevance of scenario differences.

The complete effect-size evidence is provided in:
07_effect_size_evidence_final.csv

5. SENSITIVITY AND ROBUSTNESS

The one-at-a-time sensitivity analysis evaluated seven parameters using
the STEP 09 sensitivity evidence. The highest-ranked parameter was
{top_parameter}, with an elasticity value of {fmt(top_elasticity, 4)}.

This finding indicates which modeled parameter produced the strongest
relative response within the specified perturbation design. Sensitivity
ranking should be interpreted as robustness evidence within the model
structure and parameter ranges; it is not a substitute for empirical
identification or formal causal inference.

6. MODEL VALIDATION

The validation evidence package contains {len(validation_copy)} rows.
Detected validation failures in STEP 09: {validation_failures}.

The validation process should be described as evidence of model
implementation quality, internal consistency, data integrity, replication
structure, and physical/mass-balance consistency. It should not be
described as proof of external empirical validity.

7. KEY FINDINGS

The final key findings extracted from STEP 09 are retained in
11_key_findings_final.csv. These findings provide the traceable bridge
between numerical results and the manuscript's interpretation.

8. DISCUSSION

The combined scenario represents the most comprehensive intervention
configuration in the modeled system. Its interpretation should therefore
focus on the joint behavior of collection, participation, recovery,
residual waste, and cost rather than relying on a single KPI.

The sensitivity results indicate that recovery performance is particularly
dependent on the parameter identified as {top_parameter}. Consequently,
policy or operational conclusions that rely on increased material recovery
should recognize the parameter sensitivity of that outcome.

At the same time, scenario differences should be interpreted conditionally.
The model represents a structured computational experiment in which agent
behavior, system capacity, incentives, collection efficiency, recovery
rate,
and related assumptions determine the simulated outcomes. Therefore,
the results provide decision-support evidence about the modeled system,
rather than direct estimates of observed real-world causal effects.

9. LIMITATIONS

First, the findings are conditional on the parameterization and behavioral
assumptions implemented in the ABM. Second, scenario interventions are
modeled configurations and should not automatically be interpreted as
empirically identified causal effects. Third, sensitivity analysis is
conditional on the selected parameter ranges and perturbation design.
Fourth, external validity should be evaluated before transferring the
results to different populations, geographic settings, institutional
arrangements, or collection systems.

10. REPORTING RECOMMENDATION

For the final thesis or journal manuscript, descriptive scenario outcomes,
statistical significance, effect magnitude, sensitivity, and validation
should be reported as distinct evidence layers. This structure improves
traceability and prevents overstatement of what the simulation evidence
can establish.
""".strip()

write_text(
    results_discussion,
    MANUSCRIPT / "STEP10_RESULTS_AND_DISCUSSION.txt",
)

# ---------------------------------------------------------------------
# STEP 10.16 - CONCLUSION DRAFT
# ---------------------------------------------------------------------
section("STEP 10.16 - GENERATING CONCLUSION DRAFT")

conclusion = f"""
CONCLUSION DRAFT
E-WASTE ABM

The final validated evidence package demonstrates that the six-scenario
agent-based model can be used to compare alternative e-waste management
configurations under a common simulation framework. The scenario results
show the modeled differences in recovered material, collection, formal
participation, residual waste, and system cost, with the baseline retained
as the reference condition.

The combined orchestration scenario produced {fmt(combined_recovery, 3)} kg
of recovered material compared with {fmt(baseline_recovery, 3)} kg in the
baseline, corresponding to a modeled change of {fmt(combined_recovery_change, 3)}%.
This difference should be interpreted as a model-based scenario result,
not as a direct empirical causal effect.

Sensitivity analysis identified {top_parameter} as the highest-ranked
parameter within the specified perturbation design. This result indicates
that recovery outcomes are not equally sensitive to all modeled parameters
and that robustness assessment is important when interpreting the model.

The validation evidence detected {validation_failures} validation failures
in the final STEP 09 package. The model should therefore be presented as a
validated computational framework with respect to internal consistency and
implementation checks, while external empirical validity remains a
separate consideration.

Overall, the evidence supports the use of the ABM as a structured
decision-support tool for examining e-waste management interventions,
subject to the assumptions, parameterization, scenario definitions, and
scope of the model.
""".strip()

write_text(conclusion, MANUSCRIPT / "STEP10_CONCLUSION_DRAFT.txt")

# ---------------------------------------------------------------------
# STEP 10.17 - LIMITATIONS
# ---------------------------------------------------------------------
section("STEP 10.17 - GENERATING LIMITATIONS")

limitations = """
LIMITATIONS

1. The results are conditional on the parameterization and behavioral
   assumptions implemented in the ABM.

2. Modeled intervention scenarios should not be interpreted automatically
   as direct empirical causal effects.

3. Sensitivity results are conditional on the selected parameter ranges,
   perturbation levels, and one-at-a-time design.

4. Model validation primarily establishes internal consistency,
   implementation quality, and computational credibility; it does not
   by itself establish external empirical validity.

5. Transfer of findings to different geographic, demographic, institutional,
   or operational settings requires additional validation.

6. Statistical significance, effect magnitude, sensitivity, and model
   validation represent different forms of evidence and should remain
   analytically distinct in the final manuscript.
""".strip()

write_text(limitations, MANUSCRIPT / "STEP10_LIMITATIONS.txt")

# ---------------------------------------------------------------------
# STEP 10.18 - FIGURES
# ---------------------------------------------------------------------
section("STEP 10.18 - GENERATING FINAL INTEGRATION FIGURES")

figure_paths: list[Path] = []

if not MPL_AVAILABLE:
    failures.append("Matplotlib")
    log("FAIL", "Publication figures", f"Matplotlib unavailable: {MPL_ERROR}")
else:
    # Figure 1 - recovered material
    if "Recovered Material (kg)" in results_table.columns:
        fig, ax = plt.subplots(figsize=(11, 6))
        ax.bar(
            results_table["Scenario"],
            pd.to_numeric(results_table["Recovered Material (kg)"], errors="coerce"),
        )
        ax.set_ylabel("Recovered Material (kg)")
        ax.set_xlabel("Scenario")
        ax.set_title("Final Scenario Comparison: Recovered Material")
        ax.tick_params(axis="x", rotation=35)
        fig.tight_layout()
        p = FIGURES / "01_final_scenario_performance.png"
        fig.savefig(p, dpi=300, bbox_inches="tight")
        plt.close(fig)
        figure_paths.append(p)
        saved(p)

    # Figure 2 - intervention effects
    if "Recovered Material (kg)" in results_table.columns:
        recovery_changes = []
        names = []
        for scenario in SCENARIO_ORDER[1:]:
            names.append(scenario)
            recovery_changes.append(
                pct_change(
                    get_metric(results_table, scenario, "Recovered Material (kg)"),
                    baseline_recovery,
                )
            )

        fig, ax = plt.subplots(figsize=(11, 6))
        ax.bar(names, recovery_changes)
        ax.axhline(0, linewidth=1)
        ax.set_ylabel("Recovered Material Change vs Baseline (%)")
        ax.set_xlabel("Intervention Scenario")
        ax.set_title("Baseline-Relative Recovery Effect")
        ax.tick_params(axis="x", rotation=35)
        fig.tight_layout()
        p = FIGURES / "02_final_intervention_effects.png"
        fig.savefig(p, dpi=300, bbox_inches="tight")
        plt.close(fig)
        figure_paths.append(p)
        saved(p)

    # Figure 3 - sensitivity ranking
    if sens_param_col is not None and sens_rank_col is not None:
        sf = sens_copy.copy()
        sf["_rank"] = pd.to_numeric(sf[sens_rank_col], errors="coerce")
        sf = sf.dropna(subset=["_rank"]).sort_values("_rank")

        if not sf.empty:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.barh(
                sf[sens_param_col].astype(str),
                sf["_rank"],
            )
            ax.set_xlabel("Sensitivity Rank (1 = highest)")
            ax.set_ylabel("Parameter")
            ax.set_title("Sensitivity Ranking")
            ax.invert_yaxis()
            fig.tight_layout()
            p = FIGURES / "03_final_sensitivity_ranking.png"
            fig.savefig(p, dpi=300, bbox_inches="tight")
            plt.close(fig)
            figure_paths.append(p)
            saved(p)

    # Figure 4 - combined vs baseline
    if "Recovered Material (kg)" in results_table.columns:
        vals = [
            baseline_recovery,
            combined_recovery,
        ]
        labels = ["Baseline", "Scenario 5 - Combined Orchestration"]

        fig, ax = plt.subplots(figsize=(8, 6))
        ax.bar(labels, vals)
        ax.set_ylabel("Recovered Material (kg)")
        ax.set_title("Baseline vs Combined Orchestration")
        ax.tick_params(axis="x", rotation=20)
        fig.tight_layout()
        p = FIGURES / "04_final_baseline_vs_combined.png"
        fig.savefig(p, dpi=300, bbox_inches="tight")
        plt.close(fig)
        figure_paths.append(p)
        saved(p)

# ---------------------------------------------------------------------
# STEP 10.19 - TABLE & FIGURE CAPTIONS
# ---------------------------------------------------------------------
section("STEP 10.19 - GENERATING TABLE AND FIGURE CAPTIONS")

captions = """
TABLE 1. Final Scenario Performance.
Scenario-level descriptive outcomes for recovered material, collection,
formal participation, residual waste, and system cost where available.

TABLE 2. Baseline-Relative Intervention Effects.
Absolute and percentage changes in selected outcomes relative to the
baseline scenario.

TABLE 3. Statistical Evidence.
Inferential evidence consolidated from STEP 09. Statistical significance
is interpreted separately from practical magnitude.

TABLE 4. Effect-Size Evidence.
Effect-size indicators used to interpret the practical magnitude of
scenario differences.

TABLE 5. Sensitivity Evidence.
Sensitivity ranking and robustness information for the seven modeled
parameters.

TABLE 6. Validation Evidence.
Internal consistency, data integrity, replication, and model validation
evidence carried forward from STEP 09.

FIGURE 1. Final Scenario Performance.
Comparison of recovered material across the six modeled scenarios.

FIGURE 2. Baseline-Relative Recovery Effect.
Modeled percentage change in recovered material for the five intervention
scenarios relative to the baseline.

FIGURE 3. Sensitivity Ranking.
Ranking of modeled parameters according to the STEP 09 sensitivity evidence.

FIGURE 4. Baseline versus Combined Orchestration.
Direct comparison of recovered material for the baseline and Scenario 5.
""".strip()

write_text(captions, MANUSCRIPT / "STEP10_TABLE_FIGURE_CAPTIONS.txt")

# ---------------------------------------------------------------------
# STEP 10.20 - DOCX
# ---------------------------------------------------------------------
section("STEP 10.20 - BUILDING FINAL MANUSCRIPT DOCUMENT")

docx_path = OUT / "STEP10_FINAL_MANUSCRIPT_RESULTS_DISCUSSION.docx"

if DOCX_AVAILABLE and Document is not None:
    doc = Document()

    # Basic styles
    try:
        normal = doc.styles["Normal"]
        normal.font.name = "Times New Roman"
        normal.font.size = Pt(11)
    except Exception:
        pass

    title = doc.add_heading(
        "E-WASTE ABM: FINAL RESULTS AND DISCUSSION",
        level=0,
    )
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    p = doc.add_paragraph(
        "STEP 10 – Final Thesis / Journal Results & Discussion Integration"
    )
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph(
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    doc.add_heading("1. Data and Evidence Basis", level=1)
    doc.add_paragraph(
        "This document integrates the validated evidence produced in STEP 09. "
        "No new simulation was performed in STEP 10. Descriptive scenario "
        "results, inferential statistics, effect sizes, sensitivity analysis, "
        "and model validation are retained as distinct evidence layers."
    )

    doc.add_heading("2. Final Scenario Results", level=1)
    doc.add_paragraph(
        "The final scenario-level outcomes are summarized below."
    )

    # Compact table
    display_cols = [
        c for c in [
            "Scenario",
            "Recovered Material (kg)",
            "Collection Rate (%)",
            "Formal Participation (%)",
            "Residual Waste (kg)",
            "System Cost (USD)",
        ]
        if c in results_table.columns
    ]

    if display_cols:
        table = doc.add_table(rows=1, cols=len(display_cols))
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.style = "Table Grid"

        for i, col in enumerate(display_cols):
            table.rows[0].cells[i].text = str(col)

        for _, r in results_table.iterrows():
            cells = table.add_row().cells
            for i, col in enumerate(display_cols):
                value = r[col]
                if isinstance(value, (float, np.floating)):
                    text = fmt(value, 3)
                else:
                    text = str(value)
                cells[i].text = text

    doc.add_paragraph(
        "Scenario-level differences are descriptive model outputs and should "
        "not be interpreted as direct empirical causal effects."
    )

    doc.add_heading("3. Baseline vs Intervention Effects", level=1)
    doc.add_paragraph(
        f"Scenario 5 – Combined Orchestration produced "
        f"{fmt(combined_recovery, 3)} kg of recovered material compared with "
        f"{fmt(baseline_recovery, 3)} kg in the baseline, corresponding to a "
        f"modeled change of {fmt(combined_recovery_change, 3)}%."
    )

    doc.add_heading("4. Statistical Evidence", level=1)
    doc.add_paragraph(
        f"The STEP 09 statistical evidence package contains "
        f"{len(statistical)} rows. Statistical significance is interpreted "
        "separately from effect magnitude."
    )

    doc.add_heading("5. Effect Size", level=1)
    doc.add_paragraph(
        f"The STEP 09 effect-size evidence contains {len(effect_sizes)} rows. "
        "Effect sizes are used to discuss practical magnitude and are not "
        "treated as interchangeable with p-values."
    )

    doc.add_heading("6. Sensitivity and Robustness", level=1)
    doc.add_paragraph(
        f"The sensitivity analysis evaluated {len(sensitivity)} parameters. "
        f"The highest-ranked parameter was {top_parameter}, with an elasticity "
        f"value of {fmt(top_elasticity, 4)}."
    )

    doc.add_heading("7. Model Validation", level=1)
    doc.add_paragraph(
        f"The validation evidence contains {len(validation)} rows, with "
        f"{validation_failures} detected validation failures in the STEP 09 "
        "package. Validation is presented as evidence of internal consistency "
        "and model implementation quality, not as proof of external empirical validity."
    )

    doc.add_heading("8. Discussion", level=1)
    for paragraph in results_discussion.split("\n\n")[6:]:
        if paragraph.strip():
            clean = re.sub(r"^\\d+\.\\s+[A-Z &/-]+\n?", "", paragraph.strip())
            if clean:
                doc.add_paragraph(clean)

    doc.add_heading("9. Limitations", level=1)
    for item in limitations.split("\n\n")[1:]:
        if item.strip():
            doc.add_paragraph(item.strip())

    doc.add_heading("10. Key Findings", level=1)
    if not key_findings.empty:
        for _, r in key_findings.iterrows():
            values = " | ".join(
                f"{col}: {r[col]}" for col in key_findings.columns
            )
            doc.add_paragraph(values)

    doc.add_heading("11. Evidence Package", level=1)
    doc.add_paragraph(
        "The accompanying CSV files provide traceable evidence for all "
        "major manuscript claims. Figures are supplied separately in the "
        "STEP 10 figures directory."
    )

    for fp in figure_paths:
        try:
            doc.add_picture(str(fp), width=Inches(6.2))
            cap = doc.add_paragraph(fp.name)
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        except Exception:
            pass

    doc.save(docx_path)
    saved(docx_path)
else:
    failures.append("Final Manuscript DOCX")
    log(
        "FAIL",
        "Final manuscript DOCX",
        "python-docx unavailable. Run: python -m pip install python-docx",
    )

# ---------------------------------------------------------------------
# STEP 10.21 - FINAL MANUSCRIPT PACKAGE
# ---------------------------------------------------------------------
section("STEP 10.21 - BUILDING FINAL MANUSCRIPT PACKAGE INDEX")

package_rows = []

for path in sorted(TABLES.glob("*.csv")):
    package_rows.append(
        {
            "Type": "Table",
            "File": path.name,
            "Path": str(path),
            "Exists": path.exists(),
        }
    )

for path in sorted(FIGURES.glob("*.png")):
    package_rows.append(
        {
            "Type": "Figure",
            "File": path.name,
            "Path": str(path),
            "Exists": path.exists(),
        }
    )

for path in sorted(MANUSCRIPT.glob("*")):
    if path.is_file():
        package_rows.append(
            {
                "Type": "Manuscript",
                "File": path.name,
                "Path": str(path),
                "Exists": path.exists(),
            }
        )

package_rows.append(
    {
        "Type": "Final DOCX",
        "File": docx_path.name,
        "Path": str(docx_path),
        "Exists": docx_path.exists(),
    }
)

package_df = pd.DataFrame(package_rows)
save_csv(package_df, TABLES / "15_final_manuscript_package_index.csv")

# ---------------------------------------------------------------------
# STEP 10.22 - FINAL VALIDATION
# ---------------------------------------------------------------------
section("STEP 10.22 - FINAL STEP 10 VALIDATION")

validation_checks = []

def check(label: str, condition: bool, details: str) -> None:
    status = "PASS" if bool(condition) else "FAIL"
    if not condition:
        failures.append(label)
    log(status, "Final validation", details)
    validation_checks.append(
        {
            "Check": label,
            "Status": status,
            "Details": details,
        }
    )


check(
    "STEP 09 inputs",
    all(integrity_df["Exists"]),
    f"Required STEP 09 files available={int(integrity_df['Exists'].sum())}/{len(integrity_df)}",
)

check(
    "Scenario count",
    len(summary) == 6 and set(summary["Scenario"]) == set(SCENARIO_ORDER),
    f"Detected={len(summary)}, Expected=6",
)

check(
    "Scenario order/integrity",
    not summary["Scenario"].duplicated().any(),
    "No duplicated scenario labels",
)

numeric_columns = [
    c for c in results_table.columns
    if c != "Scenario"
]

finite_ok = True
numeric_checked = 0
for col in numeric_columns:
    vals = pd.to_numeric(results_table[col], errors="coerce")
    if vals.notna().any():
        numeric_checked += 1
        if not np.isfinite(vals.dropna().to_numpy()).all():
            finite_ok = False

check(
    "Numeric scenario evidence",
    finite_ok,
    f"Numeric columns checked={numeric_checked}",
)

check(
    "Sensitivity parameters",
    len(sensitivity) == 7,
    f"Detected={len(sensitivity)}, Expected=7",
)

check(
    "Validation evidence",
    validation_failures == 0,
    f"Detected validation failures={validation_failures}",
)

check(
    "Evidence map",
    len(evidence_map) > 0,
    f"Evidence map rows={len(evidence_map)}",
)

check(
    "Figures",
    len(figure_paths) == 4,
    f"Generated={len(figure_paths)}/4",
)

check(
    "DOCX",
    docx_path.exists(),
    str(docx_path),
)

save_csv(
    pd.DataFrame(validation_checks),
    TABLES / "16_final_step10_validation.csv",
)

# ---------------------------------------------------------------------
# STEP 10.23 - FINAL REPORT
# ---------------------------------------------------------------------
section("STEP 10.23 - GENERATING STEP 10 FINAL REPORT")

report_lines = [
    "E-WASTE ABM",
    "STEP 10: FINAL THESIS / JOURNAL RESULTS & DISCUSSION INTEGRATION",
    "FINAL COMPATIBLE VERSION",
    "",
    f"Project root: {ROOT}",
    f"Output folder: {OUT}",
    "",
    "DATASET / EVIDENCE SUMMARY",
    f"Scenario rows: {len(summary)}",
    f"Baseline/intervention rows: {len(baseline)}",
    f"Statistical evidence rows: {len(statistical)}",
    f"Effect-size rows: {len(effect_sizes)}",
    f"Sensitivity parameters: {len(sensitivity)}",
    f"Validation evidence rows: {len(validation)}",
    f"Key findings: {len(key_findings)}",
    f"Evidence map rows: {len(evidence_map)}",
    "",
    "KEY RESULTS",
    f"Highest recovered-material scenario: {best_recovery_scenario}",
    f"Highest recovered material: {fmt(best_recovery, 3)} kg",
    f"Highest collection-rate scenario: {best_collection_scenario}",
    f"Highest collection rate: {fmt(best_collection, 3)}%",
    f"Highest formal-participation scenario: {best_participation_scenario}",
    f"Highest formal participation: {fmt(best_participation, 3)}%",
    f"Lowest system-cost scenario: {lowest_cost_scenario}",
    f"Lowest system cost: {fmt(lowest_cost, 3)} USD",
    f"Scenario 5 recovered material: {fmt(combined_recovery, 3)} kg",
    f"Baseline recovered material: {fmt(baseline_recovery, 3)} kg",
    f"Scenario 5 vs baseline recovery change: {fmt(combined_recovery_change, 3)}%",
    "",
    "SENSITIVITY",
    f"Highest-ranked parameter: {top_parameter}",
    f"Elasticity: {fmt(top_elasticity, 4)}",
    "",
    "VALIDATION",
    f"Validation failures detected: {validation_failures}",
    "",
    "OUTPUTS",
    f"Tables generated: {len(list(TABLES.glob('*.csv')))}",
    f"Figures generated: {len(figure_paths)}",
    f"Manuscript text files: {len(list(MANUSCRIPT.glob('*.txt')))}",
    f"DOCX generated: {'YES' if docx_path.exists() else 'NO'}",
    "",
    "FINAL STATUS",
    f"Validation failures in STEP 10: {len(failures)}",
]

report_path = OUT / "STEP10_RESULTS_DISCUSSION_REPORT.txt"
write_text("\n".join(report_lines), report_path)

# ---------------------------------------------------------------------
# STEP 10.24 - STATUS
# ---------------------------------------------------------------------
banner("STEP 10 FINAL SUMMARY")
print(f"Scenarios analyzed        : {len(summary)}")
print(f"Statistical evidence rows : {len(statistical)}")
print(f"Sensitivity parameters    : {len(sensitivity)}")
print(f"Validation evidence rows  : {len(validation)}")
print(f"Publication figures       : {len(figure_paths)}")
print(f"Evidence map rows         : {len(evidence_map)}")
print(f"Validation failures       : {len(failures)}")
print(f"Output folder             : {OUT}")
print(f"Tables folder             : {TABLES}")
print(f"Figures folder            : {FIGURES}")
print(f"Manuscript folder         : {MANUSCRIPT}")

if failures:
    print("\n" + "=" * 100)
    print("STEP 10 STATUS : FAIL")
    print("=" * 100)
    print("Failures:")
    for item in failures:
        print(f" - {item}")
    raise SystemExit(1)

print("\n" + "=" * 100)
print("STEP 10 STATUS : PASS")
print("=" * 100)
print("READY FOR FINAL THESIS / JOURNAL RESULTS, DISCUSSION & CONCLUSION")
