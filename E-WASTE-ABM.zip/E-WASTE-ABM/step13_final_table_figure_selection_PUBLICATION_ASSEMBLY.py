from pathlib import Path
import shutil
import csv
import math
from datetime import datetime

# ============================================================
# E-WASTE ABM
# STEP 13: FINAL TABLE & FIGURE SELECTION + PUBLICATION ASSEMBLY
# FINAL COMPATIBLE VERSION
# ============================================================

PROJECT_ROOT = Path(r"D:\E-WASTE-ABM")
STEP12 = PROJECT_ROOT / "results_step12"
STEP11 = PROJECT_ROOT / "results_step11"
OUT = PROJECT_ROOT / "results_step13"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
MANUSCRIPT = OUT / "manuscript"
PACKAGE = OUT / "FINAL_PUBLICATION_PACKAGE"

for p in [OUT, TABLES, FIGURES, MANUSCRIPT, PACKAGE]:
    p.mkdir(parents=True, exist_ok=True)

def log(status, section, message):
    print(f"[{status}] {section:<48} | {message}")

def copy_required(src, dst):
    if not src.exists():
        raise FileNotFoundError(str(src))
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

print("=" * 100)
print("E-WASTE ABM")
print("STEP 13: FINAL TABLE & FIGURE SELECTION + PUBLICATION ASSEMBLY")
print("FINAL COMPATIBLE VERSION")
print("=" * 100)
print(f"Project root : {PROJECT_ROOT}")
print(f"Output       : {OUT}")

# ------------------------------------------------------------
# STEP 13.1 - INPUT INTEGRITY
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.1 - STEP 12 INPUT INTEGRITY")
print("-" * 100)

required_tables = {
    "publication_results": STEP12 / "tables/03_final_publication_results_table.csv",
    "baseline_effects": STEP12 / "tables/04_baseline_intervention_evidence.csv",
    "statistical": STEP12 / "tables/05_statistical_evidence.csv",
    "statistical_interpretation": STEP12 / "tables/06_statistical_interpretation.csv",
    "effect_sizes": STEP12 / "tables/07_effect_size_evidence.csv",
    "effect_interpretation": STEP12 / "tables/08_effect_size_interpretation.csv",
    "sensitivity": STEP12 / "tables/09_sensitivity_evidence.csv",
    "validation": STEP12 / "tables/10_validation_evidence.csv",
    "key_findings": STEP12 / "tables/11_key_findings.csv",
    "evidence_map": STEP12 / "tables/12_evidence_map.csv",
    "claim_matrix": STEP12 / "tables/13_claim_to_evidence.csv",
    "numeric_highlights": STEP12 / "tables/14_numeric_highlights.csv",
    "qc_matrix": STEP12 / "tables/15_step11_qc_matrix.csv",
    "checklist": STEP12 / "tables/16_step11_checklist.csv",
    "figure_manifest": STEP12 / "tables/18_final_figure_manifest.csv",
    "step12_validation": STEP12 / "tables/19_final_step12_validation.csv",
}

input_failures = 0
for name, path in required_tables.items():
    if path.exists():
        log("PASS", "Input integrity", f"{name}: {path}")
    else:
        input_failures += 1
        log("FAIL", "Input integrity", f"Missing: {path}")

if input_failures:
    raise SystemExit(f"STEP 13 STOPPED: missing inputs={input_failures}")

# ------------------------------------------------------------
# STEP 13.2 - LOAD AUTHORITATIVE DATA
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.2 - LOADING AUTHORITATIVE DATA")
print("-" * 100)

data = {k: read_csv(v) for k, v in required_tables.items()}

print(f"Publication result rows : {len(data['publication_results'])}")
print(f"Statistical rows        : {len(data['statistical'])}")
print(f"Effect-size rows        : {len(data['effect_sizes'])}")
print(f"Sensitivity rows        : {len(data['sensitivity'])}")
print(f"Validation rows         : {len(data['validation'])}")
print(f"Claim-to-evidence rows  : {len(data['claim_matrix'])}")

# ------------------------------------------------------------
# STEP 13.3 - PUBLICATION TABLE SELECTION
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.3 - FINAL PUBLICATION TABLE SELECTION")
print("-" * 100)

# Preserve authoritative data exactly; selection is based on existing STEP 12 outputs.
table_specs = [
    ("TABLE_01_FINAL_SCENARIO_RESULTS.csv", "publication_results"),
    ("TABLE_02_BASELINE_INTERVENTION_EFFECTS.csv", "baseline_effects"),
    ("TABLE_03_STATISTICAL_EVIDENCE.csv", "statistical"),
    ("TABLE_04_STATISTICAL_INTERPRETATION.csv", "statistical_interpretation"),
    ("TABLE_05_EFFECT_SIZE_EVIDENCE.csv", "effect_sizes"),
    ("TABLE_06_EFFECT_SIZE_INTERPRETATION.csv", "effect_interpretation"),
    ("TABLE_07_SENSITIVITY_EVIDENCE.csv", "sensitivity"),
    ("TABLE_08_VALIDATION_EVIDENCE.csv", "validation"),
    ("TABLE_09_KEY_FINDINGS.csv", "key_findings"),
    ("TABLE_10_EVIDENCE_MAP.csv", "evidence_map"),
    ("TABLE_11_CLAIM_TO_EVIDENCE.csv", "claim_matrix"),
]

table_manifest = []
for filename, key in table_specs:
    src = required_tables[key]
    dst = TABLES / filename
    copy_required(src, dst)
    table_manifest.append({
        "publication_order": len(table_manifest) + 1,
        "publication_table": filename,
        "source_step": "STEP12",
        "source_file": str(src),
        "rows": len(data[key]),
        "status": "PASS",
    })
    log("PASS", "Publication table", filename)

write_csv(
    TABLES / "12_final_table_selection_manifest.csv",
    table_manifest,
    ["publication_order", "publication_table", "source_step",
     "source_file", "rows", "status"]
)

# ------------------------------------------------------------
# STEP 13.4 - FIGURE SELECTION
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.4 - FINAL PUBLICATION FIGURE SELECTION")
print("-" * 100)

figure_names = [
    "01_final_scenario_performance.png",
    "02_final_intervention_effects.png",
    "03_final_sensitivity_ranking.png",
    "04_final_baseline_vs_combined.png",
]

figure_rows = []
for i, filename in enumerate(figure_names, 1):
    src = STEP12 / "figures" / filename
    dst = FIGURES / f"FIGURE_{i:02d}_{filename.split('_', 1)[1]}"
    if src.exists():
        copy_required(src, dst)
        size = dst.stat().st_size
        figure_rows.append({
            "figure_number": i,
            "publication_figure": dst.name,
            "source_file": str(src),
            "size_bytes": size,
            "valid": "YES" if size > 0 else "NO",
            "status": "PASS" if size > 0 else "FAIL",
        })
        log("PASS", "Publication figure", dst.name)
    else:
        figure_rows.append({
            "figure_number": i,
            "publication_figure": dst.name,
            "source_file": str(src),
            "size_bytes": 0,
            "valid": "NO",
            "status": "FAIL",
        })
        log("FAIL", "Publication figure", f"Missing: {src}")

write_csv(
    TABLES / "13_final_figure_selection_manifest.csv",
    figure_rows,
    ["figure_number", "publication_figure", "source_file",
     "size_bytes", "valid", "status"]
)

# ------------------------------------------------------------
# STEP 13.5 - NUMERIC HIGHLIGHT AUDIT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.5 - FINAL NUMERIC HIGHLIGHT AUDIT")
print("-" * 100)

numeric_rows = data["numeric_highlights"]
numeric_finite = True
for row in numeric_rows:
    for value in row.values():
        try:
            if value is not None and str(value).strip() != "":
                x = float(str(value).replace(",", ""))
                if not math.isfinite(x):
                    numeric_finite = False
        except ValueError:
            pass

log(
    "PASS" if numeric_finite else "FAIL",
    "Numeric highlight audit",
    f"Rows={len(numeric_rows)}; finite_numeric_values={numeric_finite}"
)

# ------------------------------------------------------------
# STEP 13.6 - CLAIM/EVIDENCE COVERAGE
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.6 - CLAIM-TO-EVIDENCE COVERAGE AUDIT")
print("-" * 100)

claim_rows = data["claim_matrix"]
claim_linked = 0
for row in claim_rows:
    values = [str(v).strip() for v in row.values() if v is not None]
    if any(v for v in values):
        # Existing STEP 12 matrix is authoritative; require an Evidence field when present.
        evidence = str(row.get("Evidence", "")).strip()
        claim = str(row.get("Claim", "")).strip()
        if claim and evidence:
            claim_linked += 1

coverage = (claim_linked / len(claim_rows) * 100) if claim_rows else 0
log(
    "PASS" if coverage == 100 else "FAIL",
    "Claim-to-evidence coverage",
    f"Linked={claim_linked}/{len(claim_rows)}; coverage={coverage:.2f}%"
)

# ------------------------------------------------------------
# STEP 13.7 - PACKAGE CONSISTENCY / 48 VS 52 AUDIT
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.7 - FINAL PACKAGE CONSISTENCY AUDIT")
print("-" * 100)

# Count files that STEP 12 explicitly exposed in its final package.
manifest12 = STEP12 / "FINAL_MANUSCRIPT_PACKAGE_MANIFEST.csv"
package_manifest_rows = read_csv(manifest12) if manifest12.exists() else []

step12_manifest_count = len(package_manifest_rows)
step12_package_dir = STEP12 / "FINAL_MANUSCRIPT_PACKAGE"
actual_step12_package_files = (
    [p for p in step12_package_dir.rglob("*") if p.is_file()]
    if step12_package_dir.exists() else []
)

print(f"STEP12 manifest rows    : {step12_manifest_count}")
print(f"STEP12 package files    : {len(actual_step12_package_files)}")

package_count_consistent = (
    step12_manifest_count == len(actual_step12_package_files)
    if step12_package_dir.exists() else True
)

log(
    "PASS" if package_count_consistent else "WARN",
    "STEP12 package count",
    "Manifest/package count consistent" if package_count_consistent
    else "Manifest count differs from physical package count; retained as audit finding"
)

# ------------------------------------------------------------
# STEP 13.8 - BUILD FINAL PUBLICATION PACKAGE
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.8 - BUILDING FINAL PUBLICATION PACKAGE")
print("-" * 100)

# Copy selected tables
for p in TABLES.glob("TABLE_*.csv"):
    copy_required(p, PACKAGE / "tables" / p.name)

# Copy selected figures
for p in FIGURES.glob("FIGURE_*.png"):
    copy_required(p, PACKAGE / "figures" / p.name)

# Copy final manuscript and core narrative files
manuscript_sources = [
    STEP12 / "manuscript/STEP12_FINAL_MANUSCRIPT.docx",
    STEP12 / "manuscript/STEP12_FINAL_MANUSCRIPT.txt",
    STEP12 / "manuscript/STEP12_ABSTRACT.txt",
    STEP12 / "manuscript/STEP12_METHOD_INTEGRATION.txt",
    STEP12 / "manuscript/STEP12_RESULTS.txt",
    STEP12 / "manuscript/STEP12_DISCUSSION.txt",
    STEP12 / "manuscript/STEP12_LIMITATIONS.txt",
    STEP12 / "manuscript/STEP12_CONCLUSION.txt",
    STEP12 / "manuscript/STEP12_EVIDENCE_TRACEABILITY.txt",
]

for src in manuscript_sources:
    if src.exists():
        copy_required(src, PACKAGE / "manuscript" / src.name)

# Copy QC and validation evidence
qc_sources = [
    STEP12 / "tables/15_step11_qc_matrix.csv",
    STEP12 / "tables/16_step11_checklist.csv",
    STEP12 / "tables/19_final_step12_validation.csv",
]
for src in qc_sources:
    if src.exists():
        copy_required(src, PACKAGE / "quality_control" / src.name)

package_files = [p for p in PACKAGE.rglob("*") if p.is_file()]
print(f"Publication package files : {len(package_files)}")

# ------------------------------------------------------------
# STEP 13.9 - FINAL PUBLICATION MANIFEST
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.9 - FINAL PUBLICATION MANIFEST")
print("-" * 100)

manifest_rows = []
for p in sorted(package_files):
    rel = p.relative_to(PACKAGE)
    manifest_rows.append({
        "artifact_order": len(manifest_rows) + 1,
        "artifact": str(rel),
        "type": p.suffix.lower().lstrip("."),
        "size_bytes": p.stat().st_size,
        "exists": "YES",
        "status": "PASS" if p.stat().st_size > 0 else "FAIL",
    })

write_csv(
    OUT / "FINAL_PUBLICATION_PACKAGE_MANIFEST.csv",
    manifest_rows,
    ["artifact_order", "artifact", "type", "size_bytes", "exists", "status"]
)

# ------------------------------------------------------------
# STEP 13.10 - PUBLICATION READINESS CHECKLIST
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.10 - FINAL PUBLICATION READINESS CHECKLIST")
print("-" * 100)

checks = [
    ("STEP12 input integrity", input_failures == 0),
    ("Publication tables", len(table_manifest) == len(table_specs)),
    ("Publication figures", all(r["status"] == "PASS" for r in figure_rows)),
    ("Numeric highlights", numeric_finite),
    ("Claim-to-evidence coverage", coverage == 100),
    ("Final manuscript DOCX", (STEP12 / "manuscript/STEP12_FINAL_MANUSCRIPT.docx").exists()),
    ("Final manuscript TXT", (STEP12 / "manuscript/STEP12_FINAL_MANUSCRIPT.txt").exists()),
    ("Publication package", len(package_files) > 0),
    ("Package artifacts non-empty", all(p.stat().st_size > 0 for p in package_files)),
]

check_rows = []
for item, ok in checks:
    status = "PASS" if ok else "FAIL"
    log(status, "Publication checklist", item)
    check_rows.append({
        "check": item,
        "status": status,
        "value": "TRUE" if ok else "FALSE"
    })

write_csv(
    TABLES / "14_final_publication_readiness_checklist.csv",
    check_rows,
    ["check", "status", "value"]
)

failures = sum(1 for r in check_rows if r["status"] == "FAIL")

# ------------------------------------------------------------
# STEP 13.11 - FINAL VALIDATION
# ------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 13.11 - FINAL STEP 13 VALIDATION")
print("-" * 100)

validation_rows = [
    {"metric": "Input failures", "value": input_failures, "status": "PASS" if input_failures == 0 else "FAIL"},
    {"metric": "Publication tables", "value": len(table_manifest), "status": "PASS"},
    {"metric": "Publication figures", "value": len([r for r in figure_rows if r["status"] == "PASS"]), "status": "PASS" if all(r["status"] == "PASS" for r in figure_rows) else "FAIL"},
    {"metric": "Claim evidence coverage", "value": f"{coverage:.2f}%", "status": "PASS" if coverage == 100 else "FAIL"},
    {"metric": "Publication package artifacts", "value": len(package_files), "status": "PASS" if len(package_files) > 0 else "FAIL"},
    {"metric": "Checklist failures", "value": failures, "status": "PASS" if failures == 0 else "FAIL"},
]

write_csv(
    TABLES / "15_final_step13_validation.csv",
    validation_rows,
    ["metric", "value", "status"]
)

# ------------------------------------------------------------
# STEP 13.12 - FINAL REPORT
# ------------------------------------------------------------
report = f"""
E-WASTE ABM
STEP 13: FINAL TABLE & FIGURE SELECTION + PUBLICATION ASSEMBLY
FINAL PUBLICATION READINESS REPORT

Generated: {datetime.now().isoformat(timespec='seconds')}

INPUT
- STEP 12 input failures: {input_failures}
- STEP 12 publication result rows: {len(data['publication_results'])}
- Statistical evidence rows: {len(data['statistical'])}
- Effect-size evidence rows: {len(data['effect_sizes'])}
- Sensitivity rows: {len(data['sensitivity'])}
- Validation rows: {len(data['validation'])}
- Claim-to-evidence rows: {len(data['claim_matrix'])}

SELECTED PUBLICATION MATERIAL
- Final tables selected: {len(table_manifest)}
- Final figures selected: {len([r for r in figure_rows if r['status'] == 'PASS'])}
- Claim-to-evidence coverage: {coverage:.2f}%
- Final publication package artifacts: {len(package_files)}

STEP 12 PACKAGE COUNT AUDIT
- STEP 12 manifest rows: {step12_manifest_count}
- STEP 12 physical package files: {len(actual_step12_package_files)}
- Count consistency: {package_count_consistent}

FINAL CHECKLIST
- Failures: {failures}

STATUS
- {"PASS - FINAL PUBLICATION PACKAGE READY" if failures == 0 else "FAIL - REVIEW REQUIRED"}

OUTPUT
{OUT}
PACKAGE
{PACKAGE}
"""

(OUT / "STEP13_FINAL_PUBLICATION_READINESS_REPORT.txt").write_text(
    report.strip() + "\n", encoding="utf-8"
)

print("\n" + "=" * 100)
print("STEP 13 FINAL SUMMARY")
print("=" * 100)
print(f"Publication tables selected : {len(table_manifest)}")
print(f"Publication figures         : {len([r for r in figure_rows if r['status'] == 'PASS'])}")
print(f"Claim-to-evidence coverage  : {coverage:.2f}%")
print(f"Package artifacts           : {len(package_files)}")
print(f"Checklist failures          : {failures}")
print(f"Output folder               : {OUT}")
print(f"Publication package         : {PACKAGE}")
print()
print("STEP 13 STATUS :", "PASS" if failures == 0 else "FAIL")
print("FINAL PUBLICATION ASSEMBLY READY" if failures == 0 else "FINAL PUBLICATION ASSEMBLY REQUIRES REVIEW")
