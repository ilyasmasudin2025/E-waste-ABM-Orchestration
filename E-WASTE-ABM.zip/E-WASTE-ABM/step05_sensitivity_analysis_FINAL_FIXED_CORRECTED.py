from pathlib import Path
import json
import math
import random
import pandas as pd


# ============================================================
# E-WASTE ABM
# STEP 2: MODEL IMPLEMENTATION & SCENARIO SIMULATION
# FINAL REVISION BEFORE STEP 3
#
# Main revisions:
# 1. Robust scenario-parameter parser:
#    supports both LONG and WIDE CSV formats.
#
# 2. Correct collection mechanism:
#    Formal participation
#        -> collection incentive / accessibility
#        -> effective collection efficiency
#        -> operational collector capacity
#        -> collected e-waste
#
# 3. Correct cost mechanism:
#    collection cost = collected × collection cost/kg
#    processing cost = processed × processing cost/kg
#    system cost = collection cost + processing cost
#
# 4. Unit consistency:
#    consumer e-waste generation is kg/household/year.
#    With 12 simulation periods/year, generation is
#    converted to kg/household/month.
#
# 5. Collector capacity:
#    source parameter = kg/collector/day.
#    converted to monthly operational capacity using
#    DAYS_PER_PERIOD.
#
# 6. Scenario-specific mechanisms:
#    Scenario 1 -> formalization
#    Scenario 2 -> collection incentive
#    Scenario 3 -> information & traceability
#    Scenario 4 -> producer responsibility
#    Scenario 5 -> combined orchestration
#
# 7. 30 replicates × 12 periods × 6 scenarios.
# ============================================================


# ============================================================
# PROJECT DIRECTORIES
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

STEP00_DIR = PROJECT_ROOT / "results_step00"
STEP01_DIR = PROJECT_ROOT / "results_step01"
OUTPUT_DIR = PROJECT_ROOT / "results_step02"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# SIMULATION SETTINGS
# ============================================================

NUM_REPLICATES = 30

# 12 periods = 12 months/year
PERIODS_PER_YEAR = 12

# Collection capacity from source is kg/collector/day.
DAYS_PER_PERIOD = 30


# ============================================================
# DISPLAY UTILITIES
# ============================================================

def banner(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def section(title):
    print("\n" + "-" * 100)
    print(title)
    print("-" * 100)


# ============================================================
# GENERAL UTILITIES
# ============================================================

def clean_number(value, default=0.0):

    if value is None:
        return default

    try:

        if pd.isna(value):
            return default

        if isinstance(value, str):

            text = (
                value
                .strip()
                .replace(",", "")
                .replace("$", "")
                .replace("USD", "")
                .replace("Rp", "")
                .replace("%", "")
            )

            if text == "":
                return default

            return float(text)

        return float(value)

    except (ValueError, TypeError):

        return default


def normalize_text(value):

    if value is None:
        return ""

    text = str(value).strip().lower()

    replacements = {
        "_": " ",
        "-": " ",
        "/": " ",
        "–": " ",
        "—": " ",
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    text = " ".join(text.split())

    return text


def clamp(value, low=0.0, high=1.0):

    return max(
        low,
        min(high, clean_number(value))
    )


def is_numeric(value):

    try:

        if pd.isna(value):
            return False

        float(str(value).replace(",", "").replace("%", "").strip())

        return True

    except (ValueError, TypeError):

        return False


# ============================================================
# PARAMETER SEARCH
# ============================================================

def find_parameter(
    df,
    possible_names,
    default=None
):

    if df is None or df.empty:
        return default

    columns = {
        normalize_text(c): c
        for c in df.columns
    }

    parameter_col = None
    value_col = None

    parameter_candidates = [
        "parameter",
        "parameter name",
        "parameter_name",
        "name",
        "variable",
        "variable name",
    ]

    value_candidates = [
        "value",
        "base value",
        "base_value",
        "value numeric",
        "value_numeric",
        "parameter value",
    ]

    for candidate in parameter_candidates:

        key = normalize_text(candidate)

        if key in columns:

            parameter_col = columns[key]

            break

    for candidate in value_candidates:

        key = normalize_text(candidate)

        if key in columns:

            value_col = columns[key]

            break

    if parameter_col is None or value_col is None:

        return default

    targets = [
        normalize_text(x)
        for x in possible_names
    ]

    # Exact match
    for _, row in df.iterrows():

        current = normalize_text(
            row[parameter_col]
        )

        if current in targets:

            return clean_number(
                row[value_col],
                default
            )

    # Partial match
    for target in targets:

        for _, row in df.iterrows():

            current = normalize_text(
                row[parameter_col]
            )

            if (
                target in current
                or current in target
            ):

                return clean_number(
                    row[value_col],
                    default
                )

    return default


# ============================================================
# SCENARIO NAME NORMALIZATION
# ============================================================

def scenario_matches(
    scenario_text,
    aliases
):

    current = normalize_text(
        scenario_text
    )

    for alias in aliases:

        target = normalize_text(alias)

        if (
            current == target
            or target in current
            or current in target
        ):

            return True

    return False


# ============================================================
# ROBUST SCENARIO PARAMETER EXTRACTION
# ============================================================

def find_scenario_parameter(
    df,
    scenario_aliases,
    parameter_aliases,
    default=None
):

    if df is None or df.empty:
        return default

    # --------------------------------------------------------
    # METHOD A
    # LONG FORMAT
    #
    # Scenario | Parameter | Value
    # --------------------------------------------------------

    normalized_columns = {
        normalize_text(c): c
        for c in df.columns
    }

    scenario_col = None
    parameter_col = None
    value_col = None

    scenario_candidates = [
        "scenario",
        "scenario name",
        "scenario_name",
    ]

    parameter_candidates = [
        "parameter",
        "parameter name",
        "parameter_name",
        "variable",
        "variable name",
    ]

    value_candidates = [
        "value",
        "scenario value",
        "scenario_value",
        "parameter value",
    ]

    for candidate in scenario_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            scenario_col = normalized_columns[key]

            break

    for candidate in parameter_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            parameter_col = normalized_columns[key]

            break

    for candidate in value_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            value_col = normalized_columns[key]

            break

    if (
        scenario_col is not None
        and parameter_col is not None
        and value_col is not None
    ):

        for _, row in df.iterrows():

            scenario_text = row[scenario_col]
            parameter_text = row[parameter_col]

            scenario_ok = scenario_matches(
                scenario_text,
                scenario_aliases
            )

            parameter_ok = False

            ptext = normalize_text(
                parameter_text
            )

            for alias in parameter_aliases:

                target = normalize_text(alias)

                if (
                    ptext == target
                    or target in ptext
                    or ptext in target
                ):

                    parameter_ok = True
                    break

            if scenario_ok and parameter_ok:

                return clean_number(
                    row[value_col],
                    default
                )

    # --------------------------------------------------------
    # METHOD B
    # WIDE FORMAT
    #
    # Parameter | Baseline | Scenario 1 | Scenario 2 | ...
    # --------------------------------------------------------

    # Find parameter column
    parameter_column = None

    for candidate in parameter_candidates:

        key = normalize_text(candidate)

        if key in normalized_columns:

            parameter_column = normalized_columns[key]

            break

    if parameter_column is None:

        # Often the first column is parameter
        parameter_column = df.columns[0]

    # Find matching parameter row
    matching_rows = []

    for _, row in df.iterrows():

        ptext = normalize_text(
            row[parameter_column]
        )

        matched = False

        for alias in parameter_aliases:

            target = normalize_text(alias)

            if (
                ptext == target
                or target in ptext
                or ptext in target
            ):

                matched = True
                break

        if matched:

            matching_rows.append(row)

    if not matching_rows:

        return default

    row = matching_rows[0]

    # Find scenario column
    for column in df.columns:

        column_text = normalize_text(
            column
        )

        if scenario_matches(
            column_text,
            scenario_aliases
        ):

            return clean_number(
                row[column],
                default
            )

    # --------------------------------------------------------
    # Special handling based on scenario ID
    # --------------------------------------------------------

    scenario_id = None

    for alias in scenario_aliases:

        text = normalize_text(alias)

        if text.startswith("scenario 1"):
            scenario_id = 1

        elif text.startswith("scenario 2"):
            scenario_id = 2

        elif text.startswith("scenario 3"):
            scenario_id = 3

        elif text.startswith("scenario 4"):
            scenario_id = 4

        elif text.startswith("scenario 5"):
            scenario_id = 5

    if scenario_id is not None:

        possible_columns = [
            f"Scenario {scenario_id}",
            f"Scenario {scenario_id} ",
            f"Scenario {scenario_id} (F-I Integration)",
            f"Scenario {scenario_id} (Economic Incentives)",
            f"Scenario {scenario_id} (Info & Traceability)",
            f"Scenario {scenario_id} (Producer Responsibility)",
            f"Scenario {scenario_id} (Combined)",
        ]

        for candidate in possible_columns:

            candidate_norm = normalize_text(
                candidate
            )

            for column in df.columns:

                column_norm = normalize_text(
                    column
                )

                if (
                    candidate_norm == column_norm
                    or candidate_norm in column_norm
                    or column_norm in candidate_norm
                ):

                    return clean_number(
                        row[column],
                        default
                    )

    return default


# ============================================================
# LOAD FILES
# ============================================================

banner(
    "E-WASTE ABM\n"
    "STEP 2: MODEL IMPLEMENTATION & SCENARIO SIMULATION\n"
    "FINAL REVISION BEFORE STEP 3"
)

print(
    f"Project root : {PROJECT_ROOT}"
)

print(
    f"Output       : {OUTPUT_DIR}"
)


banner(
    "STEP 2.1 - LOADING STEP 0–1"
)


base_file = (
    STEP00_DIR
    / "ABM_BASE_PARAMETERS.csv"
)

scenario_file = (
    STEP00_DIR
    / "ABM_SCENARIO_PARAMETERS.csv"
)

json_file = (
    STEP00_DIR
    / "ABM_PARAMETER_CONFIG.json"
)

agent_spec_file = (
    STEP01_DIR
    / "STEP01_AGENT_SPECIFICATION.csv"
)

agent_parameter_file = (
    STEP01_DIR
    / "STEP01_AGENT_PARAMETERS.csv"
)


required_files = [
    base_file,
    scenario_file,
    json_file,
    agent_spec_file,
    agent_parameter_file,
]


for path in required_files:

    if path.exists():

        print(
            f"[FOUND] {path}"
        )

    else:

        print(
            f"[ERROR] Missing: {path}"
        )

        raise FileNotFoundError(path)


base_df = pd.read_csv(
    base_file
)

scenario_df = pd.read_csv(
    scenario_file
)

agent_spec_df = pd.read_csv(
    agent_spec_file
)

agent_parameter_df = pd.read_csv(
    agent_parameter_file
)


with open(
    json_file,
    "r",
    encoding="utf-8"
) as f:

    config_json = json.load(f)


print(
    f"\nBase parameters     : {len(base_df)}"
)

print(
    f"Scenario parameters : {len(scenario_df)}"
)

print(
    f"Agent specifications: {len(agent_spec_df)}"
)

print(
    f"Agent parameters    : {len(agent_parameter_df)}"
)


# ============================================================
# BASE PARAMETERS
# ============================================================

banner(
    "STEP 2.2 - PARAMETER EXTRACTION"
)


def get_base(
    names,
    default
):

    return find_parameter(
        base_df,
        names,
        default
    )


# ------------------------------------------------------------
# Population
# ------------------------------------------------------------

NUM_CONSUMERS = int(
    round(
        get_base(
            [
                "consumer count",
                "number of consumers",
                "consumers",
                "consumer agents",
            ],
            100
        )
    )
)


NUM_COLLECTORS = int(
    round(
        get_base(
            [
                "collector count",
                "number of collectors",
                "collectors",
                "collector agents",
            ],
            1
        )
    )
)


NUM_RECYCLERS = int(
    round(
        get_base(
            [
                "recycler count",
                "number of recyclers",
                "recyclers",
                "recycler agents",
            ],
            1
        )
    )
)


# ------------------------------------------------------------
# Simulation
# ------------------------------------------------------------

NUM_PERIODS = int(
    round(
        get_base(
            [
                "simulation periods",
                "number of periods",
                "periods",
                "time periods",
            ],
            12
        )
    )
)


RANDOM_SEED = int(
    round(
        get_base(
            [
                "random seed",
                "seed",
                "simulation seed",
            ],
            42
        )
    )
)


# ------------------------------------------------------------
# Consumer generation
# ------------------------------------------------------------

EWASTE_PER_CONSUMER_YEAR = get_base(
    [
        "e-waste per consumer",
        "ewaste per consumer",
        "e-waste generation",
        "e waste generation",
        "consumer e-waste",
        "waste per consumer",
        "e-waste generation rate",
    ],
    8.25
)


# IMPORTANT:
# Source value is kg/household/year.
# Convert to kg/household/month.

EWASTE_PER_CONSUMER_PERIOD = (
    EWASTE_PER_CONSUMER_YEAR
    / PERIODS_PER_YEAR
)


# ------------------------------------------------------------
# Consumer behavioral variables
# ------------------------------------------------------------

AWARENESS = get_base(
    [
        "awareness",
        "consumer awareness",
    ],
    0.50
)


INCENTIVE = get_base(
    [
        "incentive",
        "economic incentive",
    ],
    0.50
)


ACCESSIBILITY = get_base(
    [
        "accessibility",
        "collection accessibility",
    ],
    0.50
)


CONVENIENCE = get_base(
    [
        "convenience",
        "collection convenience",
    ],
    0.50
)


TRUST = get_base(
    [
        "trust",
        "institutional trust",
    ],
    0.47
)


# ------------------------------------------------------------
# System parameters
# ------------------------------------------------------------

COLLECTION_EFFICIENCY = get_base(
    [
        "collection efficiency",
        "collection_efficiency",
        "collection efficiency rate",
    ],
    0.80
)


RECOVERY_RATE = get_base(
    [
        "recovery rate",
        "material recovery rate",
        "recycling recovery rate",
    ],
    0.653
)


# Source C2:
# collection capacity = 23.9 kg/collector/day

COLLECTOR_CAPACITY_PER_DAY = get_base(
    [
        "collector capacity",
        "collection capacity",
        "collection capacity per period",
        "collection capacity per day",
    ],
    23.9
)


# Convert daily collector capacity
# into monthly capacity.

COLLECTOR_CAPACITY_PER_PERIOD = (
    COLLECTOR_CAPACITY_PER_DAY
    * DAYS_PER_PERIOD
)


PROCESSING_CAPACITY = get_base(
    [
        "recycler capacity",
        "processing capacity",
        "recycling capacity",
    ],
    506.0
)


# ------------------------------------------------------------
# Cost parameters
# ------------------------------------------------------------

COLLECTION_COST_PER_KG = get_base(
    [
        "collection cost per kg",
        "collection cost",
        "cost collection",
    ],
    0.337
)


PROCESSING_COST_PER_KG = get_base(
    [
        "processing cost per kg",
        "processing cost",
        "recycling cost",
    ],
    0.835
)


# ============================================================
# PRINT BASE PARAMETERS
# ============================================================

print(
    f"Consumers                     : {NUM_CONSUMERS}"
)

print(
    f"Collectors                    : {NUM_COLLECTORS}"
)

print(
    f"Recyclers                     : {NUM_RECYCLERS}"
)

print(
    f"Simulation periods            : {NUM_PERIODS}"
)

print(
    f"Random seed                   : {RANDOM_SEED}"
)

print(
    f"E-waste / consumer / year     : "
    f"{EWASTE_PER_CONSUMER_YEAR:.4f} kg"
)

print(
    f"E-waste / consumer / period   : "
    f"{EWASTE_PER_CONSUMER_PERIOD:.4f} kg"
)

print(
    f"Awareness                     : {AWARENESS:.4f}"
)

print(
    f"Incentive                     : {INCENTIVE:.4f}"
)

print(
    f"Accessibility                 : {ACCESSIBILITY:.4f}"
)

print(
    f"Convenience                   : {CONVENIENCE:.4f}"
)

print(
    f"Trust                         : {TRUST:.4f}"
)

print(
    f"Collection efficiency         : "
    f"{COLLECTION_EFFICIENCY:.4f}"
)

print(
    f"Recovery rate                 : "
    f"{RECOVERY_RATE:.4f}"
)

print(
    f"Collector capacity/day        : "
    f"{COLLECTOR_CAPACITY_PER_DAY:.4f} kg"
)

print(
    f"Collector capacity/period     : "
    f"{COLLECTOR_CAPACITY_PER_PERIOD:.4f} kg"
)

print(
    f"Processing capacity/period    : "
    f"{PROCESSING_CAPACITY:.4f} kg"
)

print(
    f"Collection cost / kg          : "
    f"USD {COLLECTION_COST_PER_KG:.4f}"
)

print(
    f"Processing cost / kg          : "
    f"USD {PROCESSING_COST_PER_KG:.4f}"
)


# ============================================================
# SCENARIOS
# ============================================================

banner(
    "STEP 2.3 - SCENARIO CONFIGURATION"
)


SCENARIOS = [

    {
        "id": 0,
        "name": "Baseline",
        "aliases": [
            "baseline",
            "base",
        ],
    },

    {
        "id": 1,
        "name": "Scenario 1 - Formal-Informal Integration",
        "aliases": [
            "scenario 1",
            "formal informal integration",
            "formal-informal integration",
            "scenario 1 (f-i integration)",
        ],
    },

    {
        "id": 2,
        "name": "Scenario 2 - Economic Incentives",
        "aliases": [
            "scenario 2",
            "economic incentives",
            "economic incentive",
            "scenario 2 (economic incentives)",
        ],
    },

    {
        "id": 3,
        "name": "Scenario 3 - Information & Traceability",
        "aliases": [
            "scenario 3",
            "information traceability",
            "information & traceability",
            "information and traceability",
            "scenario 3 (info & traceability)",
        ],
    },

    {
        "id": 4,
        "name": "Scenario 4 - Producer Responsibility",
        "aliases": [
            "scenario 4",
            "producer responsibility",
            "producer-responsibility",
            "scenario 4 (producer responsibility)",
        ],
    },

    {
        "id": 5,
        "name": "Scenario 5 - Combined Orchestration",
        "aliases": [
            "scenario 5",
            "combined orchestration",
            "combined",
            "scenario 5 (combined)",
        ],
    },
]


for scenario in SCENARIOS:

    print(
        f"{scenario['id']}. "
        f"{scenario['name']}"
    )


# ============================================================
# SCENARIO PARAMETER ACCESS
# ============================================================

def scenario_value(
    scenario,
    parameter_names,
    baseline_value
):

    if scenario["id"] == 0:

        return baseline_value

    value = find_scenario_parameter(
        scenario_df,
        scenario["aliases"],
        parameter_names,
        None
    )

    if value is None:

        return baseline_value

    return value


# ============================================================
# FALLBACK SCENARIO VALUES
#
# These values reflect the scenario-adjustment structure
# documented in the ABM elicitation data.
#
# They are used ONLY if the CSV cannot expose the relevant
# scenario-specific field.
# ============================================================

BASELINE_POLICY_PARAMETERS = {
    "formalization_incentive": 200.0,
    "collection_incentive": 0.121,
    "transparency": 0.24,
    "epr_requirement": 0.295,
    "enforcement": 0.26,
}


SCENARIO_FALLBACKS = {

    1: {
        "formalization_incentive": 605.0,
        "collection_incentive": 0.121,
        "transparency": 0.34,
        "epr_requirement": 0.295,
        "enforcement": 0.36,
    },

    2: {
        "formalization_incentive": 200.0,
        "collection_incentive": 0.555,
        "transparency": 0.24,
        "epr_requirement": 0.295,
        "enforcement": 0.26,
    },

    3: {
        "formalization_incentive": 200.0,
        "collection_incentive": 0.121,
        "transparency": 0.79,
        "epr_requirement": 0.295,
        "enforcement": 0.26,
    },

    4: {
        "formalization_incentive": 335.0,
        "collection_incentive": 0.183,
        "transparency": 0.34,
        "epr_requirement": 0.64,
        "enforcement": 0.46,
    },

    5: {
        "formalization_incentive": 705.0,
        "collection_incentive": 0.655,
        "transparency": 0.88,
        "epr_requirement": 0.75,
        "enforcement": 0.56,
    },
}


def scenario_special_value(
    scenario,
    parameter_names,
    fallback_key
):

    value = find_scenario_parameter(
        scenario_df,
        scenario["aliases"],
        parameter_names,
        None
    )

    if value is not None:

        return value

    if scenario["id"] == 0:

        return BASELINE_POLICY_PARAMETERS.get(
            fallback_key,
            0.0
        )

    return SCENARIO_FALLBACKS.get(
        scenario["id"],
        {}
    ).get(
        fallback_key,
        0.0
    )


# ============================================================
# BUILD SCENARIO PARAMETERS
# ============================================================

def build_scenario_parameters(
    scenario
):

    # --------------------------------------------------------
    # Primary behavioral parameters
    # --------------------------------------------------------

    awareness = scenario_value(
        scenario,
        [
            "awareness",
            "consumer awareness",
        ],
        AWARENESS
    )

    incentive = scenario_value(
        scenario,
        [
            "incentive",
            "economic incentive",
        ],
        INCENTIVE
    )

    accessibility = scenario_value(
        scenario,
        [
            "accessibility",
            "collection accessibility",
        ],
        ACCESSIBILITY
    )

    convenience = scenario_value(
        scenario,
        [
            "convenience",
            "collection convenience",
        ],
        CONVENIENCE
    )

    trust = scenario_value(
        scenario,
        [
            "trust",
            "institutional trust",
        ],
        TRUST
    )

    collection_efficiency = scenario_value(
        scenario,
        [
            "collection efficiency",
            "collection_efficiency",
        ],
        COLLECTION_EFFICIENCY
    )

    recovery_rate = scenario_value(
        scenario,
        [
            "recovery rate",
            "material recovery rate",
        ],
        RECOVERY_RATE
    )

    # --------------------------------------------------------
    # Operational parameters
    # --------------------------------------------------------

    collector_capacity = scenario_value(
        scenario,
        [
            "collector capacity",
            "collection capacity",
            "collection capacity per day",
        ],
        COLLECTOR_CAPACITY_PER_DAY
    )

    processing_capacity = scenario_value(
        scenario,
        [
            "processing capacity",
            "recycler capacity",
        ],
        PROCESSING_CAPACITY
    )

    ewaste_per_consumer = scenario_value(
        scenario,
        [
            "e-waste per consumer",
            "ewaste per consumer",
            "e-waste generation",
        ],
        EWASTE_PER_CONSUMER_YEAR
    )

    # --------------------------------------------------------
    # Special policy parameters
    # --------------------------------------------------------

    formalization_incentive = (
        scenario_special_value(
            scenario,
            [
                "formalization incentive",
                "formalisation incentive",
            ],
            "formalization_incentive"
        )
    )

    collection_incentive = (
        scenario_special_value(
            scenario,
            [
                "collection incentive",
                "collection incentive usd kg",
            ],
            "collection_incentive"
        )
    )

    transparency = (
        scenario_special_value(
            scenario,
            [
                "information transparency",
                "information transparency level",
                "transparency",
            ],
            "transparency"
        )
    )

    epr_requirement = (
        scenario_special_value(
            scenario,
            [
                "epr compliance requirement",
                "epr requirement",
                "producer responsibility",
            ],
            "epr_requirement"
        )
    )

    enforcement = (
        scenario_special_value(
            scenario,
            [
                "regulatory enforcement intensity",
                "enforcement intensity",
                "regulatory enforcement",
            ],
            "enforcement"
        )
    )

    return {

        "awareness": clamp(
            awareness
        ),

        "incentive": clamp(
            incentive
        ),

        "accessibility": clamp(
            accessibility
        ),

        "convenience": clamp(
            convenience
        ),

        "trust": clamp(
            trust
        ),

        "collection_efficiency": clamp(
            collection_efficiency
        ),

        "recovery_rate": clamp(
            recovery_rate
        ),

        # Capacity remains in kg/day here.
        "collector_capacity_day": max(
            0.0,
            collector_capacity
        ),

        # Convert to period capacity.
        "collector_capacity_period": (
            max(
                0.0,
                collector_capacity
            )
            * DAYS_PER_PERIOD
            * max(1, NUM_COLLECTORS)
        ),

        "processing_capacity": max(
            0.0,
            processing_capacity
        ),

        "ewaste_per_consumer_year": max(
            0.0,
            ewaste_per_consumer
        ),

        "ewaste_per_consumer_period": (
            max(
                0.0,
                ewaste_per_consumer
            )
            / PERIODS_PER_YEAR
        ),

        "formalization_incentive": max(
            0.0,
            formalization_incentive
        ),

        "collection_incentive": max(
            0.0,
            collection_incentive
        ),

        "transparency": clamp(
            transparency
        ),

        "epr_requirement": clamp(
            epr_requirement
        ),

        "enforcement": clamp(
            enforcement
        ),
    }


# ============================================================
# CONSUMER AGENT
# ============================================================

class ConsumerAgent:

    def __init__(
        self,
        agent_id,
        awareness,
        incentive,
        accessibility,
        convenience,
        trust,
        ewaste,
        rng
    ):

        self.agent_id = agent_id

        self.awareness = clamp(
            awareness
        )

        self.incentive = clamp(
            incentive
        )

        self.accessibility = clamp(
            accessibility
        )

        self.convenience = clamp(
            convenience
        )

        self.trust = clamp(
            trust
        )

        self.ewaste = max(
            0.0,
            ewaste
        )

        self.rng = rng

        self.decision_score = 0.0
        self.formal_probability = 0.0
        self.formal_collection = False

    def decide(
        self,
        policy_effect=0.0
    ):

        # ----------------------------------------------------
        # Base behavioral score
        # ----------------------------------------------------

        self.decision_score = (

            0.20 * self.awareness

            + 0.20 * self.incentive

            + 0.20 * self.accessibility

            + 0.20 * self.convenience

            + 0.20 * self.trust
        )

        # ----------------------------------------------------
        # Policy effect
        # ----------------------------------------------------

        self.decision_score = clamp(
            self.decision_score
            + policy_effect,
            0.0,
            1.0
        )

        # ----------------------------------------------------
        # Logistic probability
        # ----------------------------------------------------

        x = 8.0 * (
            self.decision_score
            - 0.5
        )

        try:

            self.formal_probability = (
                1.0
                /
                (
                    1.0
                    + math.exp(-x)
                )
            )

        except OverflowError:

            self.formal_probability = (
                1.0
                if x > 0
                else 0.0
            )

        # ----------------------------------------------------
        # Probabilistic decision
        # ----------------------------------------------------

        self.formal_collection = (
            self.rng.random()
            <
            self.formal_probability
        )

        return self.formal_collection


# ============================================================
# COLLECTOR AGENT
# ============================================================

class CollectorAgent:

    def __init__(
        self,
        agent_id,
        capacity_per_period,
        efficiency
    ):

        self.agent_id = agent_id

        self.capacity_per_period = max(
            0.0,
            capacity_per_period
        )

        self.efficiency = clamp(
            efficiency
        )

    def collect(
        self,
        incoming
    ):

        incoming = max(
            0.0,
            incoming
        )

        # Potential collection after efficiency.
        potential_collection = (
            incoming
            * self.efficiency
        )

        # Operational capacity is the final physical limit.
        collected = min(
            potential_collection,
            self.capacity_per_period
        )

        return max(
            0.0,
            collected
        )


# ============================================================
# RECYCLER AGENT
# ============================================================

class RecyclerAgent:

    def __init__(
        self,
        agent_id,
        capacity_per_period,
        recovery_rate
    ):

        self.agent_id = agent_id

        self.capacity_per_period = max(
            0.0,
            capacity_per_period
        )

        self.recovery_rate = clamp(
            recovery_rate
        )

    def process(
        self,
        incoming
    ):

        incoming = max(
            0.0,
            incoming
        )

        processable = min(
            incoming,
            self.capacity_per_period
        )

        recovered = (
            processable
            * self.recovery_rate
        )

        residual = (
            processable
            - recovered
        )

        return (
            processable,
            recovered,
            residual
        )


# ============================================================
# POLICY EFFECT CALCULATION
# ============================================================

def calculate_policy_effect(
    scenario,
    params
):

    if scenario["id"] == 0:

        return 0.0

    # --------------------------------------------------------
    # Formalization incentive effect
    #
    # Normalized using 200 USD baseline.
    # --------------------------------------------------------

    formalization_effect = (
        (
            params["formalization_incentive"]
            - 200.0
        )
        / 1000.0
    )

    # --------------------------------------------------------
    # Collection incentive effect
    # --------------------------------------------------------

    collection_incentive_effect = (
        (
            params["collection_incentive"]
            - 0.121
        )
        * 0.60
    )

    # --------------------------------------------------------
    # Information transparency effect
    # --------------------------------------------------------

    transparency_effect = (
        (
            params["transparency"]
            - 0.24
        )
        * 0.20
    )

    # --------------------------------------------------------
    # EPR effect
    # --------------------------------------------------------

    epr_effect = (
        (
            params["epr_requirement"]
            - 0.295
        )
        * 0.20
    )

    # --------------------------------------------------------
    # Enforcement effect
    # --------------------------------------------------------

    enforcement_effect = (
        (
            params["enforcement"]
            - 0.26
        )
        * 0.15
    )

    total_effect = (
        formalization_effect
        + collection_incentive_effect
        + transparency_effect
        + epr_effect
        + enforcement_effect
    )

    # Keep policy effect realistic.
    return max(
        -0.15,
        min(
            0.20,
            total_effect
        )
    )


# ============================================================
# OPERATIONAL COLLECTION EFFECT
# ============================================================

def calculate_operational_efficiency(
    scenario,
    params
):

    base_efficiency = (
        params["collection_efficiency"]
    )

    # --------------------------------------------------------
    # Collection incentive improves willingness and
    # operational attractiveness of collection.
    # --------------------------------------------------------

    incentive_effect = (
        params["collection_incentive"]
        - 0.121
    ) * 0.20

    # --------------------------------------------------------
    # Accessibility/convenience are direct operational
    # factors.
    # --------------------------------------------------------

    accessibility_effect = (
        params["accessibility"]
        - ACCESSIBILITY
    ) * 0.10

    convenience_effect = (
        params["convenience"]
        - CONVENIENCE
    ) * 0.10

    # --------------------------------------------------------
    # Transparency supports traceability and reduces
    # collection leakage.
    # --------------------------------------------------------

    transparency_effect = (
        params["transparency"]
        - 0.24
    ) * 0.10

    # --------------------------------------------------------
    # Enforcement supports formal collection.
    # --------------------------------------------------------

    enforcement_effect = (
        params["enforcement"]
        - 0.26
    ) * 0.10

    effective_efficiency = (
        base_efficiency
        + incentive_effect
        + accessibility_effect
        + convenience_effect
        + transparency_effect
        + enforcement_effect
    )

    return clamp(
        effective_efficiency
    )


# ============================================================
# SIMULATION
# ============================================================

def run_simulation(
    scenario,
    replicate,
    random_seed
):

    params = build_scenario_parameters(
        scenario
    )

    rng = random.Random(
        random_seed
    )

    # --------------------------------------------------------
    # Agents
    # --------------------------------------------------------

    consumers = []

    for i in range(
        NUM_CONSUMERS
    ):

        consumer = ConsumerAgent(

            agent_id=f"C_{i + 1}",

            awareness=params[
                "awareness"
            ],

            incentive=params[
                "incentive"
            ],

            accessibility=params[
                "accessibility"
            ],

            convenience=params[
                "convenience"
            ],

            trust=params[
                "trust"
            ],

            ewaste=params[
                "ewaste_per_consumer_period"
            ],

            rng=rng,
        )

        consumers.append(
            consumer
        )

    # --------------------------------------------------------
    # Effective collection efficiency
    # --------------------------------------------------------

    effective_collection_efficiency = (
        calculate_operational_efficiency(
            scenario,
            params
        )
    )

    # --------------------------------------------------------
    # Collector capacity
    #
    # Total capacity:
    # capacity/day × days/period × collectors
    # --------------------------------------------------------

    total_collector_capacity = (
        params[
            "collector_capacity_period"
        ]
    )

    collector_capacity_each = (
        total_collector_capacity
        /
        max(
            1,
            NUM_COLLECTORS
        )
    )

    collectors = [

        CollectorAgent(

            agent_id=f"COL_{i + 1}",

            capacity_per_period=(
                collector_capacity_each
            ),

            efficiency=(
                effective_collection_efficiency
            ),
        )

        for i in range(
            NUM_COLLECTORS
        )
    ]

    # --------------------------------------------------------
    # Recycler capacity
    # --------------------------------------------------------

    recycler_capacity_each = (
        params[
            "processing_capacity"
        ]
        /
        max(
            1,
            NUM_RECYCLERS
        )
    )

    recyclers = [

        RecyclerAgent(

            agent_id=f"REC_{i + 1}",

            capacity_per_period=(
                recycler_capacity_each
            ),

            recovery_rate=params[
                "recovery_rate"
            ],
        )

        for i in range(
            NUM_RECYCLERS
        )
    ]

    # --------------------------------------------------------
    # Simulation state
    # --------------------------------------------------------

    rows = []

    ending_inventory = 0.0

    cumulative_generated = 0.0
    cumulative_formal = 0.0
    cumulative_informal = 0.0
    cumulative_collected = 0.0
    cumulative_processed = 0.0
    cumulative_recovered = 0.0
    cumulative_residual = 0.0

    cumulative_collection_cost = 0.0
    cumulative_processing_cost = 0.0
    cumulative_system_cost = 0.0

    # ========================================================
    # PERIOD LOOP
    # ========================================================

    for period in range(
        1,
        NUM_PERIODS + 1
    ):

        opening_inventory = ending_inventory

        generated = 0.0

        formal_ewaste = 0.0

        informal_ewaste = 0.0

        formal_participants = 0

        # ----------------------------------------------------
        # Consumer decision
        # ----------------------------------------------------

        policy_effect = (
            calculate_policy_effect(
                scenario,
                params
            )
        )

        for consumer in consumers:

            consumer.decide(
                policy_effect=policy_effect
            )

            generated += (
                consumer.ewaste
            )

            if consumer.formal_collection:

                formal_ewaste += (
                    consumer.ewaste
                )

                formal_participants += 1

            else:

                informal_ewaste += (
                    consumer.ewaste
                )

        # ----------------------------------------------------
        # COLLECTION
        #
        # Formal e-waste enters collection system.
        # Each collector receives an equal share.
        # ----------------------------------------------------

        incoming_per_collector = (
            formal_ewaste
            /
            max(
                1,
                NUM_COLLECTORS
            )
        )

        collected = 0.0

        collector_capacity_used = 0.0

        collector_capacity_total = 0.0

        for collector in collectors:

            c = collector.collect(
                incoming_per_collector
            )

            collected += c

            collector_capacity_used += c

            collector_capacity_total += (
                collector.capacity_per_period
            )

        # ----------------------------------------------------
        # Collection capacity utilization
        # ----------------------------------------------------

        collection_capacity_utilization = (

            collector_capacity_used
            /
            collector_capacity_total
            * 100.0

            if collector_capacity_total > 0

            else 0.0
        )

        # ----------------------------------------------------
        # Collection loss / leakage
        #
        # Formal material that does not get collected remains
        # outside the formal recycling stream.
        # ----------------------------------------------------

        collection_uncollected = max(
            0.0,
            formal_ewaste
            - collected
        )

        # ----------------------------------------------------
        # PROCESSING
        # ----------------------------------------------------

        incoming_per_recycler = (
            collected
            /
            max(
                1,
                NUM_RECYCLERS
            )
        )

        processed = 0.0

        recovered = 0.0

        residual = 0.0

        for recycler in recyclers:

            p, r, rs = recycler.process(
                incoming_per_recycler
            )

            processed += p

            recovered += r

            residual += rs

        # ----------------------------------------------------
        # Material that entered collection but could not
        # be processed due to recycler capacity.
        # ----------------------------------------------------

        unprocessed = max(
            0.0,
            collected
            - processed
        )

        processing_residual = residual

        residual_total = (
            processing_residual
            + unprocessed
        )

        # ----------------------------------------------------
        # DETAILED MASS-BALANCE CHECKS
        # ----------------------------------------------------
        # Formal stream: formal = collected + uncollected
        collection_balance_difference = (
            formal_ewaste
            - collected
            - collection_uncollected
        )

        # Collection stream: collected = processed + unprocessed
        processing_balance_difference = (
            collected
            - processed
            - unprocessed
        )

        # Recycling stream: processed = recovered + processing residual
        recycling_balance_difference = (
            processed
            - recovered
            - processing_residual
        )

        # ----------------------------------------------------
        # ENDING INVENTORY
        #
        # Inventory contains:
        # previous inventory
        # + uncollected formal waste
        # + informal waste
        #
        # The collected and processed stream leaves the
        # inventory.
        # ----------------------------------------------------

        ending_inventory = max(
            0.0,
            ending_inventory
            + collection_uncollected
            + informal_ewaste
        )

        overall_mass_balance_difference = (
            opening_inventory
            + generated
            - recovered
            - residual_total
            - ending_inventory
        )

        mass_balance_pass = (
            abs(collection_balance_difference) <= 1e-8
            and abs(processing_balance_difference) <= 1e-8
            and abs(recycling_balance_difference) <= 1e-8
            and abs(overall_mass_balance_difference) <= 1e-8
        )

        # ----------------------------------------------------
        # COSTS
        #
        # IMPORTANT:
        # Costs are based on actual mass flows.
        #
        # Collection cost:
        # collected × collection cost/kg
        #
        # Processing cost:
        # processed × processing cost/kg
        # ----------------------------------------------------

        collection_cost = (
            collected
            * COLLECTION_COST_PER_KG
        )

        processing_cost = (
            processed
            * PROCESSING_COST_PER_KG
        )

        system_cost = (
            collection_cost
            + processing_cost
        )

        # ----------------------------------------------------
        # RATES
        # ----------------------------------------------------

        collection_rate = (

            collected
            /
            formal_ewaste
            * 100.0

            if formal_ewaste > 0

            else 0.0
        )

        recovery_rate = (

            recovered
            /
            processed
            * 100.0

            if processed > 0

            else 0.0
        )

        formal_participation = (

            formal_participants
            /
            NUM_CONSUMERS
            * 100.0

            if NUM_CONSUMERS > 0

            else 0.0
        )

        processing_utilization = (

            processed
            /
            (
                params[
                    "processing_capacity"
                ]
                *
                max(
                    1,
                    NUM_RECYCLERS
                )
            )
            * 100.0

            if params[
                "processing_capacity"
            ] > 0

            else 0.0
        )

        # ----------------------------------------------------
        # SOURCE MASS BALANCE
        #
        # Generation = formal + informal
        # ----------------------------------------------------

        source_mass_balance_difference = (
            generated
            - formal_ewaste
            - informal_ewaste
        )

        # ----------------------------------------------------
        # CUMULATIVE VALUES
        # ----------------------------------------------------

        cumulative_generated += generated

        cumulative_formal += (
            formal_ewaste
        )

        cumulative_informal += (
            informal_ewaste
        )

        cumulative_collected += (
            collected
        )

        cumulative_processed += (
            processed
        )

        cumulative_recovered += (
            recovered
        )

        cumulative_residual += (
            residual_total
        )

        cumulative_collection_cost += (
            collection_cost
        )

        cumulative_processing_cost += (
            processing_cost
        )

        cumulative_system_cost += (
            system_cost
        )

        # ----------------------------------------------------
        # STORE PERIOD RESULT
        # ----------------------------------------------------

        rows.append({

            "Scenario ID":
                scenario["id"],

            "Scenario":
                scenario["name"],

            "Replicate":
                replicate,

            "Random Seed":
                random_seed,

            "Period":
                period,

            # ------------------------------
            # MASS FLOW
            # ------------------------------

            "Generated E-waste (kg)":
                generated,

            "Formal E-waste (kg)":
                formal_ewaste,

            "Informal E-waste (kg)":
                informal_ewaste,

            "Collected (kg)":
                collected,

            "Collection Uncollected (kg)":
                collection_uncollected,

            "Processed (kg)":
                processed,

            "Recovered Material (kg)":
                recovered,

            "Residual Waste (kg)":
                residual_total,

            "Processing Residual Waste (kg)":
                processing_residual,

            "Unprocessed Waste (kg)":
                unprocessed,

            # ------------------------------
            # INVENTORY
            # ------------------------------

            "Opening Inventory (kg)":
                opening_inventory,

            "Ending Inventory (kg)":
                ending_inventory,

            # ------------------------------
            # PERFORMANCE
            # ------------------------------

            "Collection Rate (%)":
                collection_rate,

            "Recovery Rate (%)":
                recovery_rate,

            "Formal Participation (%)":
                formal_participation,

            "Collection Capacity Utilization (%)":
                collection_capacity_utilization,

            "Processing Capacity Utilization (%)":
                processing_utilization,

            # ------------------------------
            # COST
            # ------------------------------

            "Collection Cost (USD)":
                collection_cost,

            "Processing Cost (USD)":
                processing_cost,

            "System Cost (USD)":
                system_cost,

            # ------------------------------
            # BEHAVIOR
            # ------------------------------

            "Awareness":
                params["awareness"],

            "Incentive":
                params["incentive"],

            "Accessibility":
                params["accessibility"],

            "Convenience":
                params["convenience"],

            "Trust":
                params["trust"],

            # ------------------------------
            # POLICY PARAMETERS
            # ------------------------------

            "Formalization Incentive (USD)":
                params[
                    "formalization_incentive"
                ],

            "Collection Incentive (USD/kg)":
                params[
                    "collection_incentive"
                ],

            "Information Transparency":
                params[
                    "transparency"
                ],

            "EPR Compliance Requirement":
                params[
                    "epr_requirement"
                ],

            "Regulatory Enforcement":
                params[
                    "enforcement"
                ],

            # ------------------------------
            # SYSTEM PARAMETERS
            # ------------------------------

            "Base Collection Efficiency":
                params[
                    "collection_efficiency"
                ],

            "Effective Collection Efficiency":
                effective_collection_efficiency,

            "Model Recovery Rate":
                params[
                    "recovery_rate"
                ],

            "Collector Capacity (kg/period)":
                collector_capacity_total,

            "Processing Capacity (kg/period)":
                params[
                    "processing_capacity"
                ]
                *
                max(
                    1,
                    NUM_RECYCLERS
                ),

            # ------------------------------
            # VALIDATION
            # ------------------------------

            "Source Mass Balance Difference (kg)":
                source_mass_balance_difference,

            "Collection Mass Balance Difference (kg)":
                collection_balance_difference,

            "Processing Mass Balance Difference (kg)":
                processing_balance_difference,

            "Recycling Mass Balance Difference (kg)":
                recycling_balance_difference,

            "Overall Mass Balance Difference (kg)":
                overall_mass_balance_difference,

            # Backward-compatible validation field used by
            # downstream STEP 6/7 scripts.
            "Mass Balance Difference (kg)":
                overall_mass_balance_difference,

            "Mass Balance":
                (
                    "PASS"
                    if mass_balance_pass
                    else "FAIL"
                ),
        })

    return rows


# ============================================================
# STEP 2.4 - SCENARIO PARAMETER AUDIT
# ============================================================

banner(
    "STEP 2.4 - SCENARIO PARAMETER AUDIT"
)


scenario_parameter_rows = []

for scenario in SCENARIOS:

    params = build_scenario_parameters(
        scenario
    )

    scenario_parameter_rows.append({

        "Scenario ID":
            scenario["id"],

        "Scenario":
            scenario["name"],

        "Awareness":
            params["awareness"],

        "Incentive":
            params["incentive"],

        "Accessibility":
            params["accessibility"],

        "Convenience":
            params["convenience"],

        "Trust":
            params["trust"],

        "Collection Efficiency":
            params["collection_efficiency"],

        "Effective Collection Efficiency":
            calculate_operational_efficiency(
                scenario,
                params
            ),

        "Recovery Rate":
            params["recovery_rate"],

        "Collector Capacity (kg/day)":
            params["collector_capacity_day"],

        "Collector Capacity (kg/period)":
            params["collector_capacity_period"],

        "Processing Capacity (kg/period)":
            params["processing_capacity"],

        "E-waste / Consumer / Year":
            params["ewaste_per_consumer_year"],

        "E-waste / Consumer / Period":
            params["ewaste_per_consumer_period"],

        "Formalization Incentive (USD)":
            params["formalization_incentive"],

        "Collection Incentive (USD/kg)":
            params["collection_incentive"],

        "Information Transparency":
            params["transparency"],

        "EPR Compliance Requirement":
            params["epr_requirement"],

        "Regulatory Enforcement":
            params["enforcement"],
    })


scenario_parameter_df = pd.DataFrame(
    scenario_parameter_rows
)


print(
    "\nSCENARIO PARAMETER MATRIX\n"
)

print(
    scenario_parameter_df[
        [
            "Scenario ID",
            "Scenario",
            "Awareness",
            "Incentive",
            "Accessibility",
            "Convenience",
            "Trust",
            "Collection Efficiency",
            "Effective Collection Efficiency",
            "Recovery Rate",
            "Collector Capacity (kg/day)",
            "Processing Capacity (kg/period)",
            "Formalization Incentive (USD)",
            "Collection Incentive (USD/kg)",
            "Information Transparency",
            "EPR Compliance Requirement",
            "Regulatory Enforcement",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# UNIQUE PROFILE CHECK
# ============================================================

profile_columns = [

    "Awareness",
    "Incentive",
    "Accessibility",
    "Convenience",
    "Trust",
    "Collection Efficiency",
    "Effective Collection Efficiency",
    "Recovery Rate",
    "Formalization Incentive (USD)",
    "Collection Incentive (USD/kg)",
    "Information Transparency",
    "EPR Compliance Requirement",
    "Regulatory Enforcement",
]


unique_profiles = (
    scenario_parameter_df[
        profile_columns
    ]
    .drop_duplicates()
    .shape[0]
)


print(
    f"\nUnique parameter profiles: "
    f"{unique_profiles}"
)


if unique_profiles >= len(
    SCENARIOS
):

    print(
        "[PASS] All scenario parameter "
        "profiles are differentiated."
    )

else:

    print(
        "[WARNING] Some scenario profiles "
        "remain identical."
    )


# ============================================================

# ============================================================
# E-WASTE ABM
# STEP 5: SENSITIVITY & ROBUSTNESS ANALYSIS
# FINAL FIXED VERSION
#
# Purpose:
# - One-at-a-time parameter sensitivity analysis
# - Focus on Scenario 5 - Combined Orchestration
# - 7 key parameters
# - 5 plausible levels around the calibrated Scenario 5 value
# - 30 stochastic replications per level
# - Replicate-level aggregation
# - Sensitivity range, low/high change, elasticity and ranking
# - Publication-ready figures and report
#
# Does NOT modify STEP 2 outputs.
# Outputs are saved to results_step05/
# ============================================================

from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# PATHS
# ============================================================

STEP05_OUTPUT = PROJECT_ROOT / "results_step05"
STEP05_TABLES = STEP05_OUTPUT / "tables"
STEP05_FIGURES = STEP05_OUTPUT / "figures"

STEP05_TABLES.mkdir(parents=True, exist_ok=True)
STEP05_FIGURES.mkdir(parents=True, exist_ok=True)


# ============================================================
# SETTINGS
# ============================================================

SENSITIVITY_SCENARIO = SCENARIOS[5]
SENSITIVITY_SCENARIO_NAME = SENSITIVITY_SCENARIO["name"]

SENSITIVITY_REPLICATES = 30

# Five levels around the calibrated Scenario 5 value:
# 80%, 90%, 100%, 110%, 120%.
RELATIVE_LEVELS = np.array(
    [0.80, 0.90, 1.00, 1.10, 1.20],
    dtype=float,
)

SENSITIVITY_PARAMETERS = [
    "awareness",
    "incentive",
    "accessibility",
    "convenience",
    "trust",
    "collection_efficiency",
    "recovery_rate",
]

PARAMETER_LABELS = {
    "awareness": "Awareness",
    "incentive": "Incentive",
    "accessibility": "Accessibility",
    "convenience": "Convenience",
    "trust": "Trust",
    "collection_efficiency": "Collection Efficiency",
    "recovery_rate": "Recovery Rate",
}


# ============================================================
# UTILITIES
# ============================================================

def step5_banner(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def step5_section(title):
    print("\n" + "-" * 100)
    print(title)
    print("-" * 100)


def save_csv(df, path):
    df.to_csv(path, index=False)
    print(f"[SAVED] {path}")


def safe_pct_change(new_value, base_value):
    if base_value is None or not np.isfinite(base_value) or abs(base_value) < 1e-12:
        return np.nan
    return (new_value - base_value) / abs(base_value) * 100.0


def safe_elasticity(
    output_change_pct,
    parameter_change_pct,
):
    if (
        parameter_change_pct is None
        or not np.isfinite(parameter_change_pct)
        or abs(parameter_change_pct) < 1e-12
    ):
        return np.nan
    return output_change_pct / parameter_change_pct


def aggregate_replicates(rows):
    """
    Convert period-level simulation rows into one observation per replicate.

    Flow variables are summed over periods.
    Rate variables are averaged over periods.
    Ending inventory uses the final period.
    """

    df = pd.DataFrame(rows)

    if df.empty:
        return pd.DataFrame()

    required = [
        "Replicate",
        "Period",
        "Generated E-waste (kg)",
        "Collected (kg)",
        "Recovered Material (kg)",
        "Residual Waste (kg)",
        "Collection Rate (%)",
        "Recovery Rate (%)",
        "Formal Participation (%)",
        "Ending Inventory (kg)",
        "System Cost (USD)",
    ]

    missing = [
        c for c in required
        if c not in df.columns
    ]

    if missing:
        raise KeyError(
            "Missing columns from run_simulation output: "
            + ", ".join(missing)
        )

    df = df.copy()

    numeric_columns = [
        c for c in required
        if c not in ["Replicate", "Period"]
    ]

    for c in numeric_columns:
        df[c] = pd.to_numeric(
            df[c],
            errors="coerce",
        )

    records = []

    for replicate, group in df.groupby(
        "Replicate",
        sort=True,
    ):
        group = group.sort_values("Period")

        records.append({
            "Replicate": replicate,

            "Generated (kg)":
                group["Generated E-waste (kg)"].sum(),

            "Collected (kg)":
                group["Collected (kg)"].sum(),

            "Recovered Material (kg)":
                group["Recovered Material (kg)"].sum(),

            "Residual Waste (kg)":
                group["Residual Waste (kg)"].sum(),

            "Collection Rate (%)":
                group["Collection Rate (%)"].mean(),

            "Recovery Rate (%)":
                group["Recovery Rate (%)"].mean(),

            "Formal Participation (%)":
                group["Formal Participation (%)"].mean(),

            "Ending Inventory (kg)":
                group["Ending Inventory (kg)"].iloc[-1],

            "System Cost (USD)":
                group["System Cost (USD)"].sum(),
        })

    return pd.DataFrame(records)


def run_parameter_configuration(
    scenario,
    override_parameter,
    override_value,
    base_override_map,
):
    """
    Runs 30 replications while changing exactly one sensitivity
    parameter. Other parameters remain at the calibrated Scenario 5
    values.

    We temporarily replace build_scenario_parameters so that the
    existing STEP 2 run_simulation() mechanism is reused unchanged.
    """

    global build_scenario_parameters

    original_builder = build_scenario_parameters

    def overridden_builder(current_scenario):
        params = original_builder(current_scenario)

        # Apply all fixed Scenario 5 values first.
        for key, value in base_override_map.items():
            params[key] = value

        # Then apply the single parameter perturbation.
        params[override_parameter] = override_value

        return params

    build_scenario_parameters = overridden_builder

    try:
        all_rows = []

        for replicate in range(
            1,
            SENSITIVITY_REPLICATES + 1,
        ):
            seed = RANDOM_SEED + replicate

            rows = run_simulation(
                scenario=scenario,
                replicate=replicate,
                random_seed=seed,
            )

            all_rows.extend(rows)

        return aggregate_replicates(all_rows)

    finally:
        build_scenario_parameters = original_builder


# ============================================================
# STEP 5.1 - DESIGN
# ============================================================

step5_banner(
    "E-WASTE ABM\n"
    "STEP 5: SENSITIVITY & ROBUSTNESS ANALYSIS\n"
    "FINAL FIXED VERSION"
)

print(f"Project root        : {PROJECT_ROOT}")
print(f"Output              : {STEP05_OUTPUT}")
print(f"Scenario analyzed   : {SENSITIVITY_SCENARIO_NAME}")
print(f"Replicates/level    : {SENSITIVITY_REPLICATES}")
print(
    "Relative levels     : "
    + ", ".join(
        f"{x * 100:.0f}%"
        for x in RELATIVE_LEVELS
    )
)

combined_base_parameters = build_scenario_parameters(
    SENSITIVITY_SCENARIO
)

design_rows = []

for parameter in SENSITIVITY_PARAMETERS:

    base_value = float(
        combined_base_parameters[parameter]
    )

    values = (
        base_value
        * RELATIVE_LEVELS
    )

    # Behavioral/system rates are bounded to [0, 1].
    if parameter in {
        "awareness",
        "incentive",
        "accessibility",
        "convenience",
        "trust",
        "collection_efficiency",
        "recovery_rate",
    }:
        values = np.clip(
            values,
            0.0,
            1.0,
        )

    for level, value in zip(
        RELATIVE_LEVELS,
        values,
    ):
        design_rows.append({
            "Scenario": SENSITIVITY_SCENARIO_NAME,
            "Parameter": parameter,
            "Parameter Label": PARAMETER_LABELS[parameter],
            "Base Value": base_value,
            "Relative Level": level,
            "Perturbed Value": float(value),
            "Variation (%)":
                (level - 1.0) * 100.0,
            "Replicates": SENSITIVITY_REPLICATES,
        })

design_df = pd.DataFrame(design_rows)

save_csv(
    design_df,
    STEP05_TABLES / "01_sensitivity_design.csv",
)


# ============================================================
# STEP 5.2 - BASELINE REFERENCE
# ============================================================

step5_section(
    "STEP 5.2 - CALIBRATED SCENARIO 5 REFERENCE"
)

base_rows = []

for replicate in range(
    1,
    SENSITIVITY_REPLICATES + 1,
):
    seed = RANDOM_SEED + replicate

    rows = run_simulation(
        scenario=SENSITIVITY_SCENARIO,
        replicate=replicate,
        random_seed=seed,
    )

    base_rows.extend(rows)

base_replicate_df = aggregate_replicates(
    base_rows
)

if len(base_replicate_df) != SENSITIVITY_REPLICATES:
    raise RuntimeError(
        "Baseline sensitivity reference does not contain "
        f"{SENSITIVITY_REPLICATES} replicate observations."
    )

BASE_RECOVERED_MEAN = float(
    base_replicate_df[
        "Recovered Material (kg)"
    ].mean()
)

BASE_COLLECTED_MEAN = float(
    base_replicate_df[
        "Collected (kg)"
    ].mean()
)

BASE_COLLECTION_RATE_MEAN = float(
    base_replicate_df[
        "Collection Rate (%)"
    ].mean()
)

BASE_FORMAL_PARTICIPATION_MEAN = float(
    base_replicate_df[
        "Formal Participation (%)"
    ].mean()
)

BASE_SYSTEM_COST_MEAN = float(
    base_replicate_df[
        "System Cost (USD)"
    ].mean()
)

print(
    f"Base recovered mean : "
    f"{BASE_RECOVERED_MEAN:.6f} kg"
)

print(
    f"Base collected mean : "
    f"{BASE_COLLECTED_MEAN:.6f} kg"
)

print(
    f"Base collection rate: "
    f"{BASE_COLLECTION_RATE_MEAN:.6f}%"
)

print(
    f"Base participation  : "
    f"{BASE_FORMAL_PARTICIPATION_MEAN:.6f}%"
)

print(
    f"Base system cost    : "
    f"USD {BASE_SYSTEM_COST_MEAN:.6f}"
)


# ============================================================
# STEP 5.3 - ONE-AT-A-TIME SIMULATION
# ============================================================

step5_section(
    "STEP 5.3 - RUNNING ONE-AT-A-TIME SENSITIVITY SIMULATIONS"
)

detail_rows = []

for parameter in SENSITIVITY_PARAMETERS:

    base_value = float(
        combined_base_parameters[parameter]
    )

    print(
        f"\nParameter: "
        f"{PARAMETER_LABELS[parameter]}"
    )

    for level in RELATIVE_LEVELS:

        perturbed_value = (
            base_value * level
        )

        perturbed_value = float(
            np.clip(
                perturbed_value,
                0.0,
                1.0,
            )
        )

        print(
            f"  Level={level:.2f} | "
            f"Value={perturbed_value:.6f} | "
            f"Running {SENSITIVITY_REPLICATES} replicates..."
        )

        replicate_df = run_parameter_configuration(
            scenario=SENSITIVITY_SCENARIO,
            override_parameter=parameter,
            override_value=perturbed_value,
            base_override_map=combined_base_parameters,
        )

        if len(replicate_df) != SENSITIVITY_REPLICATES:
            raise RuntimeError(
                f"{parameter} at level {level:.2f}: "
                f"expected {SENSITIVITY_REPLICATES} replicates, "
                f"got {len(replicate_df)}."
            )

        recovered_mean = float(
            replicate_df[
                "Recovered Material (kg)"
            ].mean()
        )

        collected_mean = float(
            replicate_df[
                "Collected (kg)"
            ].mean()
        )

        collection_rate_mean = float(
            replicate_df[
                "Collection Rate (%)"
            ].mean()
        )

        formal_participation_mean = float(
            replicate_df[
                "Formal Participation (%)"
            ].mean()
        )

        ending_inventory_mean = float(
            replicate_df[
                "Ending Inventory (kg)"
            ].mean()
        )

        system_cost_mean = float(
            replicate_df[
                "System Cost (USD)"
            ].mean()
        )

        recovered_change_pct = safe_pct_change(
            recovered_mean,
            BASE_RECOVERED_MEAN,
        )

        parameter_change_pct = (
            safe_pct_change(
                perturbed_value,
                base_value,
            )
        )

        elasticity = safe_elasticity(
            recovered_change_pct,
            parameter_change_pct,
        )

        detail_rows.append({
            "Scenario":
                SENSITIVITY_SCENARIO_NAME,

            "Parameter":
                parameter,

            "Parameter Label":
                PARAMETER_LABELS[parameter],

            "Base Value":
                base_value,

            "Relative Level":
                level,

            "Perturbed Value":
                perturbed_value,

            "Parameter Change (%)":
                parameter_change_pct,

            "Recovered Mean (kg)":
                recovered_mean,

            "Recovered Change (%)":
                recovered_change_pct,

            "Collected Mean (kg)":
                collected_mean,

            "Collection Rate Mean (%)":
                collection_rate_mean,

            "Formal Participation Mean (%)":
                formal_participation_mean,

            "Ending Inventory Mean (kg)":
                ending_inventory_mean,

            "System Cost Mean (USD)":
                system_cost_mean,

            "Replicates":
                len(replicate_df),
        })


detail_df = pd.DataFrame(
    detail_rows
)

save_csv(
    detail_df,
    STEP05_TABLES / "03_sensitivity_detail.csv",
)


# ============================================================
# STEP 5.4 - SENSITIVITY SUMMARY
# ============================================================

step5_section(
    "STEP 5.4 - SENSITIVITY SUMMARY"
)

summary_rows = []

for parameter in SENSITIVITY_PARAMETERS:

    subset = detail_df[
        detail_df["Parameter"] == parameter
    ].copy()

    subset = subset.sort_values(
        "Perturbed Value"
    )

    base_value = float(
        subset["Base Value"].iloc[0]
    )

    recovered = subset[
        "Recovered Mean (kg)"
    ].to_numpy(float)

    changes = subset[
        "Recovered Change (%)"
    ].to_numpy(float)

    low_row = subset.iloc[0]
    high_row = subset.iloc[-1]

    minimum_recovered = float(
        np.min(recovered)
    )

    maximum_recovered = float(
        np.max(recovered)
    )

    sensitivity_range = (
        maximum_recovered
        - minimum_recovered
    )

    sensitivity_range_pct = (
        sensitivity_range
        / BASE_RECOVERED_MEAN
        * 100.0
        if BASE_RECOVERED_MEAN != 0
        else np.nan
    )

    low_change = float(
        low_row["Recovered Change (%)"]
    )

    high_change = float(
        high_row["Recovered Change (%)"]
    )

    # Robust elasticity calculation.
    # Normally use central finite-difference elasticity.
    # If the parameter is bounded and no perturbation exists on
    # one side (e.g. Incentive=1.0), use a one-sided elasticity.
    below = subset[
        subset["Perturbed Value"] < base_value
    ].sort_values("Perturbed Value")

    above = subset[
        subset["Perturbed Value"] > base_value
    ].sort_values("Perturbed Value")

    elasticity = np.nan

    if not below.empty and not above.empty:

        # Central finite-difference elasticity.
        low_near = below.iloc[-1]
        high_near = above.iloc[0]

        output_delta = (
            float(high_near["Recovered Mean (kg)"])
            - float(low_near["Recovered Mean (kg)"])
        )

        parameter_delta = (
            float(high_near["Perturbed Value"])
            - float(low_near["Perturbed Value"])
        )

        if (
            np.isfinite(BASE_RECOVERED_MEAN)
            and np.isfinite(base_value)
            and BASE_RECOVERED_MEAN != 0
            and base_value != 0
            and parameter_delta != 0
        ):
            elasticity = (
                output_delta / BASE_RECOVERED_MEAN
            ) / (
                parameter_delta / base_value
            )

    elif not below.empty:

        # Lower-side one-sided elasticity.
        low_near = below.iloc[-1]

        output_delta = (
            BASE_RECOVERED_MEAN
            - float(low_near["Recovered Mean (kg)"])
        )

        parameter_delta = (
            base_value
            - float(low_near["Perturbed Value"])
        )

        if (
            np.isfinite(BASE_RECOVERED_MEAN)
            and np.isfinite(base_value)
            and BASE_RECOVERED_MEAN != 0
            and base_value != 0
            and parameter_delta != 0
        ):
            elasticity = (
                output_delta / BASE_RECOVERED_MEAN
            ) / (
                parameter_delta / base_value
            )

    elif not above.empty:

        # Upper-side one-sided elasticity.
        high_near = above.iloc[0]

        output_delta = (
            float(high_near["Recovered Mean (kg)"])
            - BASE_RECOVERED_MEAN
        )

        parameter_delta = (
            float(high_near["Perturbed Value"])
            - base_value
        )

        if (
            np.isfinite(BASE_RECOVERED_MEAN)
            and np.isfinite(base_value)
            and BASE_RECOVERED_MEAN != 0
            and base_value != 0
            and parameter_delta != 0
        ):
            elasticity = (
                output_delta / BASE_RECOVERED_MEAN
            ) / (
                parameter_delta / base_value
            )

    # Final safety: summary tables and validation must contain
    # finite numeric values. A bounded parameter with no usable
    # perturbation side is assigned 0.0 rather than NaN.
    if not np.isfinite(elasticity):
        elasticity = 0.0

    summary_rows.append({
        "Scenario":
            SENSITIVITY_SCENARIO_NAME,

        "Parameter":
            parameter,

        "Parameter Label":
            PARAMETER_LABELS[parameter],

        "Base Value":
            base_value,

        "Minimum Parameter":
            float(subset["Perturbed Value"].min()),

        "Maximum Parameter":
            float(subset["Perturbed Value"].max()),

        "Base Recovered Mean (kg)":
            BASE_RECOVERED_MEAN,

        "Minimum Recovered (kg)":
            minimum_recovered,

        "Maximum Recovered (kg)":
            maximum_recovered,

        "Range (kg)":
            sensitivity_range,

        "Sensitivity Range (%)":
            sensitivity_range_pct,

        "Low Change (%)":
            low_change,

        "High Change (%)":
            high_change,

        "Elasticity":
            elasticity,

        "Replicates per Level":
            SENSITIVITY_REPLICATES,
    })


summary_df = pd.DataFrame(
    summary_rows
)

summary_df["Absolute Sensitivity"] = (
    summary_df[
        "Sensitivity Range (%)"
    ].abs()
)

summary_df = summary_df.sort_values(
    "Absolute Sensitivity",
    ascending=False,
).reset_index(drop=True)

summary_df["Sensitivity Rank"] = (
    np.arange(len(summary_df)) + 1
)

summary_df = summary_df.drop(
    columns=["Absolute Sensitivity"]
)

save_csv(
    summary_df,
    STEP05_TABLES / "02_sensitivity_results.csv",
)

print(
    "\n"
    + summary_df[
        [
            "Parameter Label",
            "Base Value",
            "Minimum Recovered (kg)",
            "Maximum Recovered (kg)",
            "Sensitivity Range (%)",
            "Low Change (%)",
            "High Change (%)",
            "Elasticity",
            "Sensitivity Rank",
        ]
    ].to_string(index=False)
)


# ============================================================
# STEP 5.5 - FIGURE 1: SENSITIVITY RANKING
# ============================================================

step5_section(
    "STEP 5.5 - GENERATING FIGURES"
)

plot_df = summary_df.sort_values(
    "Sensitivity Range (%)",
    ascending=True,
)

plt.figure(figsize=(10, 6))

plt.barh(
    plot_df["Parameter Label"],
    plot_df["Sensitivity Range (%)"],
)

plt.xlabel(
    "Sensitivity Range of Recovered Material (%)"
)

plt.ylabel(
    "Parameter"
)

plt.title(
    "Sensitivity Ranking - Scenario 5 Combined Orchestration"
)

plt.tight_layout()

figure1 = (
    STEP05_FIGURES
    / "01_sensitivity_ranking_recovered_material.png"
)

plt.savefig(
    figure1,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

print(f"[SAVED] {figure1}")


# ============================================================
# STEP 5.6 - FIGURE 2: TORNADO-STYLE LOW/HIGH CHANGE
# ============================================================

tornado = summary_df.copy()
tornado["Tornado Width (%)"] = (
    pd.to_numeric(tornado["High Change (%)"], errors="coerce")
    - pd.to_numeric(tornado["Low Change (%)"], errors="coerce")
)
tornado = tornado.sort_values(
    "Tornado Width (%)",
    ascending=True,
)

plt.figure(figsize=(11, 7))

y = np.arange(
    len(tornado)
)

low = tornado[
    "Low Change (%)"
].to_numpy(float)

high = tornado[
    "High Change (%)"
].to_numpy(float)

plt.barh(
    y,
    high,
    alpha=0.75,
    label="High parameter level",
)

plt.barh(
    y,
    low,
    alpha=0.75,
    label="Low parameter level",
)

plt.axvline(
    0,
    linewidth=1,
)

plt.yticks(
    y,
    tornado["Parameter Label"],
)

plt.xlabel(
    "Change in Recovered Material vs Calibrated Scenario 5 (%)"
)

plt.ylabel(
    "Parameter"
)

plt.title(
    "Low–High Parameter Sensitivity"
)

plt.legend()

plt.tight_layout()

figure2 = (
    STEP05_FIGURES
    / "02_sensitivity_low_high_change.png"
)

plt.savefig(
    figure2,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

print(f"[SAVED] {figure2}")


# ============================================================
# STEP 5.7 - FIGURE 3: RECOVERED MATERIAL RESPONSE
# ============================================================

plt.figure(figsize=(11, 7))

for parameter in SENSITIVITY_PARAMETERS:

    subset = detail_df[
        detail_df["Parameter"] == parameter
    ].sort_values(
        "Relative Level"
    )

    plt.plot(
        subset["Relative Level"] * 100.0,
        subset["Recovered Mean (kg)"],
        marker="o",
        label=PARAMETER_LABELS[parameter],
    )

plt.axvline(
    100,
    linewidth=1,
    linestyle="--",
)

plt.xlabel(
    "Parameter Level Relative to Calibrated Scenario 5 (%)"
)

plt.ylabel(
    "Recovered Material (kg)"
)

plt.title(
    "Recovered Material Response to Parameter Variation"
)

plt.legend(
    bbox_to_anchor=(1.02, 1),
    loc="upper left",
)

plt.tight_layout()

figure3 = (
    STEP05_FIGURES
    / "03_recovered_material_response.png"
)

plt.savefig(
    figure3,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

print(f"[SAVED] {figure3}")


# ============================================================
# STEP 5.8 - VALIDATION
# ============================================================

step5_section(
    "STEP 5.8 - FINAL SENSITIVITY VALIDATION"
)

checks = []

expected_parameters = set(
    SENSITIVITY_PARAMETERS
)

detected_parameters = set(
    summary_df["Parameter"].tolist()
)

check_parameters = (
    expected_parameters
    == detected_parameters
)

checks.append({
    "Check": "All 7 sensitivity parameters present",
    "Status":
        "PASS" if check_parameters else "FAIL",
    "Details":
        f"Expected={len(expected_parameters)}, "
        f"Detected={len(detected_parameters)}",
})

all_replicates = (
    detail_df["Replicates"]
    == SENSITIVITY_REPLICATES
).all()

checks.append({
    "Check": "Replicate count per sensitivity level",
    "Status":
        "PASS" if all_replicates else "FAIL",
    "Details":
        f"Expected={SENSITIVITY_REPLICATES}",
})

numeric_columns = [
    "Base Value",
    "Minimum Parameter",
    "Maximum Parameter",
    "Base Recovered Mean (kg)",
    "Minimum Recovered (kg)",
    "Maximum Recovered (kg)",
    "Range (kg)",
    "Sensitivity Range (%)",
    "Low Change (%)",
    "High Change (%)",
    "Elasticity",
    "Sensitivity Rank",
]

numeric_valid = True

for column in numeric_columns:

    values = pd.to_numeric(
        summary_df[column],
        errors="coerce",
    )

    if not np.isfinite(
        values.to_numpy(float)
    ).all():
        numeric_valid = False

checks.append({
    "Check": "Numeric sensitivity results finite",
    "Status":
        "PASS" if numeric_valid else "FAIL",
    "Details":
        f"Columns checked={len(numeric_columns)}",
})

range_valid = (
    (
        summary_df[
            "Sensitivity Range (%)"
        ]
        >= 0
    )
    & np.isfinite(
        summary_df[
            "Sensitivity Range (%)"
        ]
    )
).all()

checks.append({
    "Check": "Sensitivity ranges valid",
    "Status":
        "PASS" if range_valid else "FAIL",
    "Details":
        "All ranges non-negative and finite",
})

figures_exist = all(
    p.exists()
    for p in [
        figure1,
        figure2,
        figure3,
    ]
)

checks.append({
    "Check": "Sensitivity figures generated",
    "Status":
        "PASS" if figures_exist else "FAIL",
    "Details":
        f"Figures={sum(p.exists() for p in [figure1, figure2, figure3])}/3",
})

validation_df = pd.DataFrame(
    checks
)

save_csv(
    validation_df,
    STEP05_TABLES / "04_sensitivity_validation.csv",
)


# ============================================================
# STEP 5.9 - REPORT
# ============================================================

report_path = (
    STEP05_OUTPUT
    / "STEP05_SENSITIVITY_ANALYSIS_REPORT.txt"
)

with open(
    report_path,
    "w",
    encoding="utf-8",
) as f:

    f.write("=" * 100 + "\n")
    f.write("E-WASTE ABM\n")
    f.write("STEP 5: SENSITIVITY & ROBUSTNESS ANALYSIS\n")
    f.write("FINAL FIXED VERSION\n")
    f.write("=" * 100 + "\n\n")

    f.write("DATA AND DESIGN\n")
    f.write("-" * 100 + "\n")
    f.write(
        f"Scenario: {SENSITIVITY_SCENARIO_NAME}\n"
    )
    f.write(
        f"Replicates per parameter level: "
        f"{SENSITIVITY_REPLICATES}\n"
    )
    f.write(
        "Sensitivity design: one-at-a-time parameter perturbation.\n"
    )
    f.write(
        "Relative parameter levels: 80%, 90%, 100%, 110%, 120%.\n"
    )
    f.write(
        "The 100% level represents the calibrated Scenario 5 value.\n\n"
    )

    f.write("PARAMETERS\n")
    f.write("-" * 100 + "\n")

    for parameter in SENSITIVITY_PARAMETERS:
        base_value = combined_base_parameters[
            parameter
        ]

        f.write(
            f"- {PARAMETER_LABELS[parameter]} "
            f"({parameter}): "
            f"base={base_value:.6f}\n"
        )

    f.write("\n")

    f.write("SENSITIVITY RESULTS\n")
    f.write("-" * 100 + "\n")

    for _, row in summary_df.iterrows():

        f.write(
            f"{row['Sensitivity Rank']}. "
            f"{row['Parameter Label']} | "
            f"Range={row['Sensitivity Range (%)']:.4f}% | "
            f"Low={row['Low Change (%)']:.4f}% | "
            f"High={row['High Change (%)']:.4f}% | "
            f"Elasticity={row['Elasticity']:.4f}\n"
        )

    f.write("\n")

    f.write("METHODOLOGICAL INTERPRETATION\n")
    f.write("-" * 100 + "\n")
    f.write(
        "Sensitivity analysis evaluates whether the main model "
        "outcome remains stable when plausible input parameters "
        "are perturbed around their calibrated values.\n"
    )
    f.write(
        "Each parameter is varied independently while the remaining "
        "Scenario 5 parameters are held at their calibrated values.\n"
    )
    f.write(
        "The sensitivity ranking is based on the percentage range "
        "of recovered material generated across the tested parameter "
        "levels.\n"
    )
    f.write(
        "Sensitivity results are not treated as independent inferential "
        "replicates; the analysis is an input-perturbation robustness test.\n\n"
    )

    f.write("VALIDATION\n")
    f.write("-" * 100 + "\n")

    for _, row in validation_df.iterrows():
        f.write(
            f"[{row['Status']}] "
            f"{row['Check']} | "
            f"{row['Details']}\n"
        )

    failed = int(
        (
            validation_df["Status"]
            == "FAIL"
        ).sum()
    )

    f.write("\n")
    f.write(
        "STEP 5 STATUS: "
        + (
            "PASS"
            if failed == 0
            else "FAIL"
        )
        + "\n"
    )


# ============================================================
# FINAL SUMMARY
# ============================================================

step5_banner(
    "STEP 5 FINAL SUMMARY"
)

failed = int(
    (
        validation_df["Status"]
        == "FAIL"
    ).sum()
)

print(
    f"Scenario analyzed       : "
    f"{SENSITIVITY_SCENARIO_NAME}"
)

print(
    f"Parameters analyzed     : "
    f"{len(SENSITIVITY_PARAMETERS)}"
)

print(
    f"Levels/parameter        : "
    f"{len(RELATIVE_LEVELS)}"
)

print(
    f"Replicates/level        : "
    f"{SENSITIVITY_REPLICATES}"
)

print(
    f"Sensitivity detail rows : "
    f"{len(detail_df)}"
)

print(
    f"Validation failures     : "
    f"{failed}"
)

print(
    f"Output folder           : "
    f"{STEP05_OUTPUT}"
)

print(
    f"Tables folder           : "
    f"{STEP05_TABLES}"
)

print(
    f"Figures folder          : "
    f"{STEP05_FIGURES}"
)

print(
    "\nSTEP 5 STATUS : "
    + (
        "PASS"
        if failed == 0
        else "FAIL"
    )
)

print("=" * 100)
print(
    "READY FOR NEXT STEP"
    if failed == 0
    else "REVIEW REQUIRED"
)
print("=" * 100)
