from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore")

# ============================================================
# E-WASTE ABM
# STEP 3: SCENARIO ANALYSIS & DESCRIPTIVE RESULTS
# FINAL REVISED VERSION
#
# Purpose:
#   1. Load validated STEP 2 simulation outputs
#   2. Perform descriptive scenario analysis
#   3. Compare Baseline against all scenarios
#   4. Rank scenarios using transparent descriptive criteria
#   5. Analyze period trends
#   6. Generate publication-ready tables and figures
#
# Important:
#   STEP 3 remains descriptive. It does not claim causal
#   significance and does not replace later inferential analysis.
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

INPUT_DIR = PROJECT_ROOT / "results_step02"
OUTPUT_DIR = PROJECT_ROOT / "results_step03"

TABLE_DIR = OUTPUT_DIR / "tables"
FIGURE_DIR = OUTPUT_DIR / "figures"

TABLE_DIR.mkdir(parents=True, exist_ok=True)
FIGURE_DIR.mkdir(parents=True, exist_ok=True)

RAW_FILE = INPUT_DIR / "STEP02_RAW_SIMULATION_RESULTS.csv"
SCENARIO_FILE = INPUT_DIR / "STEP02_SCENARIO_SUMMARY.csv"
PERIOD_FILE = INPUT_DIR / "STEP02_PERIOD_RESULTS.csv"
PARAM_FILE = INPUT_DIR / "STEP02_SCENARIO_PARAMETERS.csv"


# ============================================================
# DISPLAY / UTILITY FUNCTIONS
# ============================================================

def header(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def section(title):
    print("\n" + "-" * 100)
    print(title)
    print("-" * 100)


def pass_msg(label, message):
    print(f"[PASS] {label:<35} : {message}")


def fail_msg(label, message):
    print(f"[FAIL] {label:<35} : {message}")


def save_csv(df, path):
    df.to_csv(path, index=False)
    print(f"[SAVED] {path}")


def first_existing_column(df, candidates):
    """Return the first matching column from a list of aliases."""
    for col in candidates:
        if col in df.columns:
            return col
    return None


def numeric_series(df, col):
    return pd.to_numeric(df[col], errors="coerce")


def safe_pct_change(new_value, base_value):
    if pd.isna(base_value) or base_value == 0:
        return np.nan
    return ((new_value - base_value) / abs(base_value)) * 100.0


def find_baseline(scenarios):
    for scenario in scenarios:
        if str(scenario).strip().lower() == "baseline":
            return scenario
    return scenarios[0] if scenarios else None


# ============================================================
# STEP 3.1 - LOAD STEP 2 RESULTS
# ============================================================

header("E-WASTE ABM")
print("STEP 3: SCENARIO ANALYSIS & DESCRIPTIVE RESULTS")
print("FINAL REVISED VERSION")
print("=" * 100)
print(f"Project root : {PROJECT_ROOT}")
print(f"Input        : {INPUT_DIR}")
print(f"Output       : {OUTPUT_DIR}")

header("STEP 3.1 - LOADING STEP 2 RESULTS")

required_files = [
    RAW_FILE,
    SCENARIO_FILE,
    PERIOD_FILE,
    PARAM_FILE,
]

all_found = True

for file_path in required_files:
    if file_path.exists():
        print(f"[FOUND] {file_path}")
    else:
        print(f"[MISSING] {file_path}")
        all_found = False

if not all_found:
    raise FileNotFoundError(
        "One or more required STEP 2 files are missing. "
        "Run STEP 2 successfully before STEP 3."
    )

raw = pd.read_csv(RAW_FILE)
scenario_summary_input = pd.read_csv(SCENARIO_FILE)
period_results = pd.read_csv(PERIOD_FILE)
scenario_parameters = pd.read_csv(PARAM_FILE)

print()
print(f"Raw simulation rows : {len(raw)}")
print(f"Raw simulation cols : {len(raw.columns)}")
print(f"Scenario rows       : {len(scenario_summary_input)}")
print(f"Period rows         : {len(period_results)}")
print(f"Parameter rows      : {len(scenario_parameters)}")


# ============================================================
# STEP 3.2 - BASIC DATA VALIDATION
# ============================================================

header("STEP 3.2 - BASIC DATA VALIDATION")

required_raw_columns = ["Scenario", "Replicate", "Period"]

missing_columns = [
    col for col in required_raw_columns
    if col not in raw.columns
]

if missing_columns:
    raise ValueError(
        f"Missing required columns in raw simulation data: "
        f"{missing_columns}"
    )

if raw.empty:
    raise ValueError("STEP 2 raw simulation result is empty.")

scenarios = list(raw["Scenario"].dropna().unique())

if not scenarios:
    raise ValueError("No scenarios were detected in STEP 2 raw results.")

print(f"Scenarios detected : {len(scenarios)}")
for i, scenario in enumerate(scenarios):
    print(f"{i}. {scenario}")

replicate_counts = raw.groupby("Scenario")["Replicate"].nunique()
period_counts = raw.groupby("Scenario")["Period"].nunique()

print()

for scenario in scenarios:
    rep_count = int(replicate_counts.get(scenario, 0))
    period_count = int(period_counts.get(scenario, 0))

    if rep_count == 30 and period_count == 12:
        pass_msg(
            "Replication structure",
            f"{scenario}: {rep_count} replicates × {period_count} periods"
        )
    else:
        print(
            f"[WARNING] {scenario}: "
            f"{rep_count} replicates × {period_count} periods"
        )

baseline_name = find_baseline(scenarios)

if baseline_name is not None:
    pass_msg("Baseline identification", f"Baseline = {baseline_name}")


# ============================================================
# STEP 3.3 - COLUMN / METRIC RECONCILIATION
# ============================================================

header("STEP 3.3 - MODEL OUTPUT METRIC RECONCILIATION")

# STEP 2 uses labels such as:
#   Generated E-waste (kg)
#   Formal E-waste (kg)
#   Informal E-waste (kg)
#   Collected (kg)
#   Processed (kg)
#   Recovered Material (kg)
#   Residual Waste (kg)
#   Collection Rate (%)
#   Recovery Rate (%)
#   Formal Participation (%)
#   Ending Inventory (kg)
#   Collection Cost (USD)
#   Processing Cost (USD)
#   System Cost (USD)
#
# Older versions of this STEP 3 script used slightly different
# labels. The alias map below prevents false "missing metric"
# results when STEP 2 is already correct.

metric_aliases = {
    "Generated E-waste (kg)": [
        "Generated E-waste (kg)",
        "Generated E-waste",
    ],
    "Formal E-waste (kg)": [
        "Formal E-waste (kg)",
        "Formal E-waste",
    ],
    "Informal E-waste (kg)": [
        "Informal E-waste (kg)",
        "Informal E-waste",
    ],
    "Collected (kg)": [
        "Collected (kg)",
        "Collected E-waste (kg)",
        "Collected E-waste",
    ],
    "Processed (kg)": [
        "Processed (kg)",
        "Processed E-waste (kg)",
        "Processed E-waste",
    ],
    "Recovered Material (kg)": [
        "Recovered Material (kg)",
        "Recovered Material",
    ],
    "Residual Waste (kg)": [
        "Residual Waste (kg)",
        "Residual Waste",
        "Processing Residual Waste (kg)",
    ],
    "Collection Rate (%)": [
        "Collection Rate (%)",
        "Collection Rate",
    ],
    "Recovery Rate (%)": [
        "Recovery Rate (%)",
        "Recovery Rate",
    ],
    "Formal Participation (%)": [
        "Formal Participation (%)",
        "Formal Participation",
    ],
    "Ending Inventory (kg)": [
        "Ending Inventory (kg)",
        "Ending Inventory",
    ],
    "Collection Cost (USD)": [
        "Collection Cost (USD)",
        "Collection Cost",
    ],
    "Processing Cost (USD)": [
        "Processing Cost (USD)",
        "Processing Cost",
    ],
    "System Cost (USD)": [
        "System Cost (USD)",
        "System Cost",
    ],
}

metric_columns = {}
missing_metrics = []

for standard_name, aliases in metric_aliases.items():
    matched = first_existing_column(raw, aliases)
    if matched is not None:
        metric_columns[standard_name] = matched
    else:
        missing_metrics.append(standard_name)

print("Metric mapping used by STEP 3:")
for standard_name, actual_name in metric_columns.items():
    print(f"  {standard_name:<35} <- {actual_name}")

if missing_metrics:
    print()
    print("[WARNING] Metrics not found:")
    for metric in missing_metrics:
        print(f"  - {metric}")

available_metrics = list(metric_columns.keys())

if not available_metrics:
    raise ValueError(
        "No expected STEP 2 output metrics were found in the raw simulation file."
    )

pass_msg(
    "Metric reconciliation",
    f"{len(available_metrics)} metrics available"
)


# ============================================================
# STEP 3.4 - DESCRIPTIVE STATISTICS
# ============================================================

header("STEP 3.4 - DESCRIPTIVE STATISTICS")

descriptive_rows = []

for scenario in scenarios:
    subset = raw[raw["Scenario"] == scenario]

    for standard_metric in available_metrics:
        actual_metric = metric_columns[standard_metric]

        values = numeric_series(subset, actual_metric).dropna()

        if len(values) == 0:
            continue

        descriptive_rows.append({
            "Scenario": scenario,
            "Metric": standard_metric,
            "N": int(len(values)),
            "Mean": float(values.mean()),
            "SD": float(values.std(ddof=1)) if len(values) > 1 else 0.0,
            "Minimum": float(values.min()),
            "Maximum": float(values.max()),
            "Median": float(values.median()),
        })

descriptive = pd.DataFrame(descriptive_rows)

if descriptive.empty:
    raise ValueError("Descriptive statistics could not be generated.")

descriptive_file = TABLE_DIR / "01_descriptive_statistics.csv"
save_csv(descriptive, descriptive_file)

print()
print(descriptive.to_string(index=False))


# ============================================================
# STEP 3.5 - SCENARIO MEAN COMPARISON
# ============================================================

header("STEP 3.5 - SCENARIO MEAN COMPARISON")

mean_table = (
    descriptive
    .pivot(
        index="Metric",
        columns="Scenario",
        values="Mean"
    )
    .reset_index()
)

mean_table_file = TABLE_DIR / "02_scenario_mean_comparison.csv"
save_csv(mean_table, mean_table_file)

print(mean_table.to_string(index=False))


# ============================================================
# STEP 3.6 - BASELINE VS ALL SCENARIOS
# ============================================================

header("STEP 3.6 - BASELINE VS ALL SCENARIOS")

comparison_rows = []

for metric in available_metrics:

    baseline_row = descriptive[
        (descriptive["Scenario"] == baseline_name) &
        (descriptive["Metric"] == metric)
    ]

    if baseline_row.empty:
        continue

    baseline_mean = float(baseline_row["Mean"].iloc[0])

    for scenario in scenarios:

        scenario_row = descriptive[
            (descriptive["Scenario"] == scenario) &
            (descriptive["Metric"] == metric)
        ]

        if scenario_row.empty:
            continue

        scenario_mean = float(scenario_row["Mean"].iloc[0])

        absolute_change = scenario_mean - baseline_mean
        percentage_change = safe_pct_change(
            scenario_mean,
            baseline_mean
        )

        comparison_rows.append({
            "Metric": metric,
            "Scenario": scenario,
            "Baseline Mean": baseline_mean,
            "Scenario Mean": scenario_mean,
            "Absolute Change": absolute_change,
            "Percentage Change vs Baseline (%)": percentage_change,
        })

baseline_comparison = pd.DataFrame(comparison_rows)

comparison_file = TABLE_DIR / "03_baseline_comparison.csv"
save_csv(baseline_comparison, comparison_file)

print(baseline_comparison.to_string(index=False))


# ============================================================
# STEP 3.7 - SCENARIO RANKING
# ============================================================

header("STEP 3.7 - SCENARIO RANKING")

# Higher values are desirable for these performance metrics.
higher_is_better_metrics = {
    "Collected (kg)",
    "Recovered Material (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
}

# Lower values are desirable for these burden metrics.
lower_is_better_metrics = {
    "Residual Waste (kg)",
    "System Cost (USD)",
    "Ending Inventory (kg)",
}

ranking_rows = []

for metric in available_metrics:

    metric_data = descriptive[
        descriptive["Metric"] == metric
    ].copy()

    if metric_data.empty:
        continue

    if metric in higher_is_better_metrics:
        ascending = False
    elif metric in lower_is_better_metrics:
        ascending = True
    else:
        # Descriptive-only metric: no arbitrary optimization direction.
        continue

    metric_data = metric_data.sort_values(
        "Mean",
        ascending=ascending
    ).reset_index(drop=True)

    metric_data["Rank"] = range(1, len(metric_data) + 1)

    for _, row in metric_data.iterrows():
        ranking_rows.append({
            "Metric": metric,
            "Scenario": row["Scenario"],
            "Mean": row["Mean"],
            "SD": row["SD"],
            "Rank": int(row["Rank"]),
            "Direction": (
                "Higher is better"
                if metric in higher_is_better_metrics
                else "Lower is better"
            ),
        })

ranking = pd.DataFrame(ranking_rows)

ranking_file = TABLE_DIR / "04_scenario_ranking.csv"
save_csv(ranking, ranking_file)

print(ranking.to_string(index=False))


# ============================================================
# STEP 3.8 - OVERALL DESCRIPTIVE SCENARIO PERFORMANCE
# ============================================================

header("STEP 3.8 - OVERALL DESCRIPTIVE SCENARIO PERFORMANCE")

score_rows = []

for scenario in scenarios:

    ranks = ranking[
        ranking["Scenario"] == scenario
    ]["Rank"]

    if len(ranks) == 0:
        continue

    score_rows.append({
        "Scenario": scenario,
        "Metrics Evaluated": int(len(ranks)),
        "Mean Rank": float(ranks.mean()),
        "Best Rank": int(ranks.min()),
        "Worst Rank": int(ranks.max()),
    })

overall_ranking = pd.DataFrame(score_rows)

if not overall_ranking.empty:
    overall_ranking = (
        overall_ranking
        .sort_values(
            ["Mean Rank", "Worst Rank", "Best Rank"]
        )
        .reset_index(drop=True)
    )

    overall_ranking["Overall Rank"] = (
        np.arange(1, len(overall_ranking) + 1)
    )

overall_file = TABLE_DIR / "05_overall_scenario_ranking.csv"
save_csv(overall_ranking, overall_file)

print(overall_ranking.to_string(index=False))


# ============================================================
# STEP 3.9 - PERIOD TREND ANALYSIS
# ============================================================

header("STEP 3.9 - PERIOD TREND ANALYSIS")

period_mean_rows = []

for scenario in scenarios:

    scenario_data = raw[
        raw["Scenario"] == scenario
    ]

    for period in sorted(
        scenario_data["Period"].dropna().unique()
    ):

        period_subset = scenario_data[
            scenario_data["Period"] == period
        ]

        row = {
            "Scenario": scenario,
            "Period": period,
        }

        for standard_metric in available_metrics:
            actual_metric = metric_columns[standard_metric]

            values = numeric_series(
                period_subset,
                actual_metric
            ).dropna()

            if len(values) > 0:
                row[standard_metric] = float(values.mean())

        period_mean_rows.append(row)

period_means = pd.DataFrame(period_mean_rows)

period_file = TABLE_DIR / "06_period_mean_results.csv"
save_csv(period_means, period_file)

print(f"Period mean rows generated: {len(period_means)}")


# ============================================================
# STEP 3.10 - KEY BASELINE CHANGES
# ============================================================

header("STEP 3.10 - KEY BASELINE CHANGES")

key_metrics = [
    "Collected (kg)",
    "Recovered Material (kg)",
    "Residual Waste (kg)",
    "Collection Rate (%)",
    "Recovery Rate (%)",
    "Formal Participation (%)",
    "System Cost (USD)",
    "Ending Inventory (kg)",
]

key_metrics = [
    metric for metric in key_metrics
    if metric in available_metrics
]

key_change_rows = []

for metric in key_metrics:

    baseline_value_series = descriptive[
        (descriptive["Scenario"] == baseline_name) &
        (descriptive["Metric"] == metric)
    ]["Mean"]

    if baseline_value_series.empty:
        continue

    baseline_value = float(baseline_value_series.iloc[0])

    for scenario in scenarios:

        scenario_value_series = descriptive[
            (descriptive["Scenario"] == scenario) &
            (descriptive["Metric"] == metric)
        ]["Mean"]

        if scenario_value_series.empty:
            continue

        scenario_value = float(
            scenario_value_series.iloc[0]
        )

        change = safe_pct_change(
            scenario_value,
            baseline_value
        )

        key_change_rows.append({
            "Metric": metric,
            "Scenario": scenario,
            "Baseline Mean": baseline_value,
            "Scenario Mean": scenario_value,
            "Change (%)": change,
        })

key_changes = pd.DataFrame(key_change_rows)

key_change_file = TABLE_DIR / "07_key_baseline_changes.csv"
save_csv(key_changes, key_change_file)

print(key_changes.to_string(index=False))


# ============================================================
# STEP 3.11 - SCENARIO DIFFERENTIATION DIAGNOSTIC
# ============================================================

header("STEP 3.11 - SCENARIO DIFFERENTIATION DIAGNOSTIC")

differentiation_rows = []

for metric in available_metrics:

    metric_values = descriptive[
        descriptive["Metric"] == metric
    ]["Mean"]

    if metric_values.empty:
        continue

    minimum = float(metric_values.min())
    maximum = float(metric_values.max())
    value_range = maximum - minimum

    differentiation_rows.append({
        "Metric": metric,
        "Minimum Scenario Mean": minimum,
        "Maximum Scenario Mean": maximum,
        "Scenario Mean Range": value_range,
        "All Scenario Means Identical": bool(
            np.isclose(value_range, 0.0)
        ),
    })

differentiation = pd.DataFrame(differentiation_rows)

diff_file = TABLE_DIR / "08_scenario_differentiation.csv"
save_csv(differentiation, diff_file)

print(differentiation.to_string(index=False))

different_count = int(
    (~differentiation["All Scenario Means Identical"]).sum()
)

print()
print(
    f"Metrics differentiated: "
    f"{different_count}/{len(differentiation)}"
)


# ============================================================
# STEP 3.12 - BASELINE VS COMBINED SCENARIO
# ============================================================

header("STEP 3.12 - BASELINE VS COMBINED SCENARIO")

combined_name = None

for scenario in scenarios:
    scenario_text = str(scenario).lower()
    if (
        "combined" in scenario_text
        or "orchestration" in scenario_text
    ):
        combined_name = scenario
        break

if combined_name is None and len(scenarios) >= 6:
    combined_name = scenarios[-1]

baseline_combined_rows = []

if combined_name is not None:

    for metric in available_metrics:

        base_row = descriptive[
            (descriptive["Scenario"] == baseline_name) &
            (descriptive["Metric"] == metric)
        ]

        combined_row = descriptive[
            (descriptive["Scenario"] == combined_name) &
            (descriptive["Metric"] == metric)
        ]

        if base_row.empty or combined_row.empty:
            continue

        base_mean = float(base_row["Mean"].iloc[0])
        combined_mean = float(combined_row["Mean"].iloc[0])

        baseline_combined_rows.append({
            "Metric": metric,
            "Baseline Mean": base_mean,
            "Combined Mean": combined_mean,
            "Difference": combined_mean - base_mean,
            "Percent Change": safe_pct_change(
                combined_mean,
                base_mean
            ),
        })

baseline_vs_combined = pd.DataFrame(
    baseline_combined_rows
)

baseline_combined_file = (
    TABLE_DIR / "09_baseline_vs_combined.csv"
)

save_csv(
    baseline_vs_combined,
    baseline_combined_file
)

print(f"Combined scenario: {combined_name}")
print(baseline_vs_combined.to_string(index=False))


# ============================================================
# STEP 3.13 - SCENARIO PARAMETER CONTEXT
# ============================================================

header("STEP 3.13 - SCENARIO PARAMETER CONTEXT")

scenario_parameter_file = (
    TABLE_DIR / "10_scenario_parameter_context.csv"
)

save_csv(
    scenario_parameters,
    scenario_parameter_file
)

print(scenario_parameters.to_string(index=False))


# ============================================================
# FIGURE HELPERS
# ============================================================

def make_bar_figure(
    metric,
    filename,
    title,
    ylabel,
    sort_desc=True,
):
    if metric not in available_metrics:
        return False

    data = descriptive[
        descriptive["Metric"] == metric
    ].copy()

    if data.empty:
        return False

    data = data.sort_values(
        "Mean",
        ascending=not sort_desc
    )

    plt.figure(figsize=(12, 6))

    plt.bar(
        data["Scenario"].astype(str),
        data["Mean"],
        yerr=data["SD"],
        capsize=5,
    )

    plt.xlabel("Scenario")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()

    output_file = FIGURE_DIR / filename

    plt.savefig(
        output_file,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    print(f"[SAVED] {output_file}")
    return True


# ============================================================
# STEP 3.14 - GENERATE FIGURES
# ============================================================

header("STEP 3.14 - GENERATING FIGURES")

figure_count = 0

if make_bar_figure(
    "Collected (kg)",
    "01_collected_ewaste_by_scenario.png",
    "Collected E-waste Across Scenarios",
    "Collected E-waste (kg)",
):
    figure_count += 1

if make_bar_figure(
    "Recovered Material (kg)",
    "02_recovered_material_by_scenario.png",
    "Recovered Material Across Scenarios",
    "Recovered Material (kg)",
):
    figure_count += 1

if make_bar_figure(
    "Collection Rate (%)",
    "03_collection_rate_by_scenario.png",
    "Collection Rate Across Scenarios",
    "Collection Rate (%)",
):
    figure_count += 1

if make_bar_figure(
    "Formal Participation (%)",
    "04_formal_participation_by_scenario.png",
    "Formal Participation Across Scenarios",
    "Formal Participation (%)",
):
    figure_count += 1

if make_bar_figure(
    "System Cost (USD)",
    "05_system_cost_by_scenario.png",
    "System Cost Across Scenarios",
    "System Cost (USD)",
):
    figure_count += 1


# ============================================================
# FIGURE 6 - RECOVERED MATERIAL PERIOD TREND
# ============================================================

if "Recovered Material (kg)" in period_means.columns:

    plt.figure(figsize=(12, 6))

    for scenario in scenarios:

        data = period_means[
            period_means["Scenario"] == scenario
        ]

        if data.empty:
            continue

        plt.plot(
            data["Period"],
            data["Recovered Material (kg)"],
            marker="o",
            label=str(scenario),
        )

    plt.xlabel("Simulation Period")
    plt.ylabel("Recovered Material (kg)")
    plt.title(
        "Recovered Material Trend by Simulation Period"
    )

    plt.legend(
        bbox_to_anchor=(1.02, 1),
        loc="upper left",
    )

    plt.tight_layout()

    figure_file = (
        FIGURE_DIR /
        "06_recovered_material_period_trend.png"
    )

    plt.savefig(
        figure_file,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    print(f"[SAVED] {figure_file}")
    figure_count += 1


# ============================================================
# FIGURE 7 - COLLECTION RATE PERIOD TREND
# ============================================================

if "Collection Rate (%)" in period_means.columns:

    plt.figure(figsize=(12, 6))

    for scenario in scenarios:

        data = period_means[
            period_means["Scenario"] == scenario
        ]

        if data.empty:
            continue

        plt.plot(
            data["Period"],
            data["Collection Rate (%)"],
            marker="o",
            label=str(scenario),
        )

    plt.xlabel("Simulation Period")
    plt.ylabel("Collection Rate (%)")
    plt.title(
        "Collection Rate Trend by Simulation Period"
    )

    plt.legend(
        bbox_to_anchor=(1.02, 1),
        loc="upper left",
    )

    plt.tight_layout()

    figure_file = (
        FIGURE_DIR /
        "07_collection_rate_period_trend.png"
    )

    plt.savefig(
        figure_file,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    print(f"[SAVED] {figure_file}")
    figure_count += 1


# ============================================================
# FIGURE 8 - ENDING INVENTORY PERIOD TREND
# ============================================================

if "Ending Inventory (kg)" in period_means.columns:

    plt.figure(figsize=(12, 6))

    for scenario in scenarios:

        data = period_means[
            period_means["Scenario"] == scenario
        ]

        if data.empty:
            continue

        plt.plot(
            data["Period"],
            data["Ending Inventory (kg)"],
            marker="o",
            label=str(scenario),
        )

    plt.xlabel("Simulation Period")
    plt.ylabel("Ending Inventory (kg)")
    plt.title(
        "Ending Inventory Trend by Simulation Period"
    )

    plt.legend(
        bbox_to_anchor=(1.02, 1),
        loc="upper left",
    )

    plt.tight_layout()

    figure_file = (
        FIGURE_DIR /
        "08_ending_inventory_period_trend.png"
    )

    plt.savefig(
        figure_file,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

    print(f"[SAVED] {figure_file}")
    figure_count += 1


# ============================================================
# STEP 3.15 - FINAL STEP 3 VALIDATION
# ============================================================

header("STEP 3.15 - FINAL STEP 3 VALIDATION")

validation = {
    "Input files": all_found,
    "Raw data non-empty": not raw.empty,
    "Scenarios detected": len(scenarios) > 0,
    "Required identifiers": not missing_columns,
    "Metrics available": len(available_metrics) > 0,
    "Descriptive statistics": not descriptive.empty,
    "Baseline identified": baseline_name is not None,
    "Scenario means generated": not mean_table.empty,
    "Baseline comparison generated": not baseline_comparison.empty,
    "Ranking generated": not ranking.empty,
    "Period analysis generated": not period_means.empty,
    "Figures generated": figure_count > 0,
}

for label, status in validation.items():
    if status:
        pass_msg(label, "PASS")
    else:
        fail_msg(label, "FAIL")

step3_pass = all(validation.values())

if not step3_pass:
    raise RuntimeError(
        "STEP 3 validation failed. Review the validation messages above."
    )


# ============================================================
# STEP 3.16 - GENERATE REPORT
# ============================================================

header("STEP 3.16 - GENERATING STEP 3 REPORT")

report_file = OUTPUT_DIR / "STEP03_SCENARIO_ANALYSIS_REPORT.txt"

with open(
    report_file,
    "w",
    encoding="utf-8",
) as f:

    f.write("=" * 100 + "\n")
    f.write("E-WASTE ABM\n")
    f.write("STEP 3: SCENARIO ANALYSIS & DESCRIPTIVE RESULTS\n")
    f.write("FINAL REVISED VERSION\n")
    f.write("=" * 100 + "\n\n")

    f.write("1. DATA SOURCE\n")
    f.write("-" * 100 + "\n")
    f.write(f"Raw simulation data : {RAW_FILE}\n")
    f.write(f"Scenario summary    : {SCENARIO_FILE}\n")
    f.write(f"Period results      : {PERIOD_FILE}\n")
    f.write(f"Scenario parameters : {PARAM_FILE}\n")
    f.write(f"Raw rows            : {len(raw)}\n")
    f.write(f"Scenarios           : {len(scenarios)}\n\n")

    f.write("2. REPLICATION STRUCTURE\n")
    f.write("-" * 100 + "\n")

    for scenario in scenarios:
        rep_count = int(
            replicate_counts.get(scenario, 0)
        )
        period_count = int(
            period_counts.get(scenario, 0)
        )

        f.write(
            f"{scenario}: "
            f"{rep_count} replicates × "
            f"{period_count} periods\n"
        )

    f.write("\n")

    f.write("3. BASELINE\n")
    f.write("-" * 100 + "\n")
    f.write(f"Baseline scenario: {baseline_name}\n\n")

    f.write("4. METRIC MAPPING\n")
    f.write("-" * 100 + "\n")

    for standard_name, actual_name in metric_columns.items():
        f.write(
            f"{standard_name} <- {actual_name}\n"
        )

    f.write("\n")

    f.write("5. DESCRIPTIVE RESULTS\n")
    f.write("-" * 100 + "\n")
    f.write(
        descriptive.to_string(index=False)
        + "\n\n"
    )

    f.write("6. OVERALL SCENARIO RANKING\n")
    f.write("-" * 100 + "\n")

    if not overall_ranking.empty:
        f.write(
            overall_ranking.to_string(index=False)
            + "\n\n"
        )
    else:
        f.write("No ranking was generated.\n\n")

    f.write("7. BASELINE VS COMBINED\n")
    f.write("-" * 100 + "\n")

    f.write(
        f"Combined scenario: {combined_name}\n"
    )

    if not baseline_vs_combined.empty:
        f.write(
            baseline_vs_combined.to_string(index=False)
            + "\n\n"
        )
    else:
        f.write(
            "Baseline-vs-combined table unavailable.\n\n"
        )

    f.write("8. METHODOLOGICAL NOTE\n")
    f.write("-" * 100 + "\n")
    f.write(
        "STEP 3 is descriptive scenario analysis. "
        "Scenario differences are summarized using means, "
        "standard deviations, minimums, maximums, medians, "
        "ranges, rankings, and percentage changes relative "
        "to the Baseline. No inferential hypothesis testing "
        "or causal significance claim is made at this stage.\n\n"
    )

    f.write("9. VALIDATION\n")
    f.write("-" * 100 + "\n")

    for label, status in validation.items():
        f.write(
            f"{label}: {'PASS' if status else 'FAIL'}\n"
        )

    f.write("\n")

    f.write("10. OUTPUT FILES\n")
    f.write("-" * 100 + "\n")

    f.write("Tables:\n")
    for file_path in sorted(TABLE_DIR.glob("*.csv")):
        f.write(f"  {file_path.name}\n")

    f.write("\nFigures:\n")
    for file_path in sorted(FIGURE_DIR.glob("*.png")):
        f.write(f"  {file_path.name}\n")

print(f"[SAVED] {report_file}")


# ============================================================
# STEP 3 FINAL SUMMARY
# ============================================================

header("STEP 3 FINAL SUMMARY")

print(f"Scenarios analyzed       : {len(scenarios)}")
print(f"Raw simulation rows      : {len(raw)}")
print(f"Metrics analyzed         : {len(available_metrics)}")
print(f"Baseline scenario        : {baseline_name}")
print(f"Combined scenario        : {combined_name}")
print(f"Descriptive rows         : {len(descriptive)}")
print(f"Period rows              : {len(period_means)}")
print(f"Ranking rows             : {len(ranking)}")
print(f"Tables generated         : {len(list(TABLE_DIR.glob('*.csv')))}")
print(f"Figures generated        : {figure_count}")

if not differentiation.empty:
    print(
        f"Metrics differentiated   : "
        f"{different_count}/{len(differentiation)}"
    )

print()
print("Output folder :", OUTPUT_DIR)
print("Tables folder :", TABLE_DIR)
print("Figures folder:", FIGURE_DIR)

print()
print("VALIDATION STATUS")
for label, status in validation.items():
    print(
        f"  {label:<35}: "
        f"{'PASS' if status else 'FAIL'}"
    )

print()
print(
    "STEP 3 STATUS : "
    + ("PASS" if step3_pass else "FAIL")
)

if step3_pass:
    print("READY FOR NEXT STEP")

header("STEP 3 COMPLETE")
