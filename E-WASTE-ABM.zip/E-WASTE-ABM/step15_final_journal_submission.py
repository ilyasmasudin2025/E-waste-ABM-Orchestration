from pathlib import Path
import csv
import shutil
import re
from datetime import datetime

ROOT = Path(r"D:\E-WASTE-ABM")
OUT = ROOT / "results_step15"
TABLES = OUT / "tables"
MANUSCRIPT = OUT / "manuscript"
PACKAGE = OUT / "FINAL_JOURNAL_SUBMISSION_PACKAGE"

for p in [OUT, TABLES, MANUSCRIPT, PACKAGE]:
    p.mkdir(parents=True, exist_ok=True)

STEP12 = ROOT / "results_step12"
STEP13 = ROOT / "results_step13"
STEP14 = ROOT / "results_step14"

def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fieldnames=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

def log(status, item, detail=""):
    print(f"[{status}] {item:<52} | {detail}")

print("=" * 100)
print("E-WASTE ABM")
print("STEP 15: FINAL JOURNAL SUBMISSION & MANUSCRIPT POLISH")
print("FINAL COMPATIBLE VERSION")
print("=" * 100)
print(f"Project root : {ROOT}")
print(f"Output       : {OUT}")

# ------------------------------------------------------------------
# 15.1 INPUT INTEGRITY
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.1 - STEP 12 / STEP 13 / STEP 14 INPUT INTEGRITY")
print("-" * 100)

required = {
    "STEP12 manuscript DOCX": STEP12 / "manuscript" / "STEP12_FINAL_MANUSCRIPT.docx",
    "STEP12 manuscript TXT": STEP12 / "manuscript" / "STEP12_FINAL_MANUSCRIPT.txt",
    "STEP12 abstract": STEP12 / "manuscript" / "STEP12_ABSTRACT.txt",
    "STEP12 method": STEP12 / "manuscript" / "STEP12_METHOD_INTEGRATION.txt",
    "STEP12 results": STEP12 / "manuscript" / "STEP12_RESULTS.txt",
    "STEP12 discussion": STEP12 / "manuscript" / "STEP12_DISCUSSION.txt",
    "STEP12 limitations": STEP12 / "manuscript" / "STEP12_LIMITATIONS.txt",
    "STEP12 conclusion": STEP12 / "manuscript" / "STEP12_CONCLUSION.txt",
    "STEP12 traceability": STEP12 / "manuscript" / "STEP12_EVIDENCE_TRACEABILITY.txt",
    "STEP12 numeric highlights": STEP12 / "tables" / "14_numeric_highlights.csv",
    "STEP12 claim matrix": STEP12 / "tables" / "13_claim_to_evidence.csv",
    "STEP13 manifest": STEP13 / "FINAL_PUBLICATION_PACKAGE_MANIFEST.csv",
    "STEP13 report": STEP13 / "STEP13_FINAL_PUBLICATION_READINESS_REPORT.txt",
    "STEP13 checklist": STEP13 / "tables" / "14_final_publication_readiness_checklist.csv",
    "STEP13 validation": STEP13 / "tables" / "15_final_step13_validation.csv",
    "STEP14 manuscript DOCX": STEP14 / "manuscript" / "FINAL_SUBMISSION_MANUSCRIPT.docx",
    "STEP14 manuscript TXT": STEP14 / "manuscript" / "FINAL_SUBMISSION_MANUSCRIPT.txt",
    "STEP14 manifest": STEP14 / "FINAL_SUBMISSION_PACKAGE_MANIFEST.csv",
}
integrity = []
for label, path in required.items():
    ok = path.exists() and path.stat().st_size > 0
    integrity.append({"Item": label, "Path": str(path), "Status": "PASS" if ok else "FAIL"})
    log("PASS" if ok else "FAIL", "Input integrity", label + ("" if ok else " MISSING"))

write_csv(TABLES / "01_input_integrity.csv", integrity)

# ------------------------------------------------------------------
# 15.2 LOAD MANUSCRIPT
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.2 - LOADING AUTHORITATIVE MANUSCRIPT CONTENT")
print("-" * 100)

parts = {}
for key, filename in {
    "abstract": "STEP12_ABSTRACT.txt",
    "method": "STEP12_METHOD_INTEGRATION.txt",
    "results": "STEP12_RESULTS.txt",
    "discussion": "STEP12_DISCUSSION.txt",
    "limitations": "STEP12_LIMITATIONS.txt",
    "conclusion": "STEP12_CONCLUSION.txt",
    "traceability": "STEP12_EVIDENCE_TRACEABILITY.txt",
    "full": "STEP12_FINAL_MANUSCRIPT.txt",
}.items():
    path = STEP12 / "manuscript" / filename
    parts[key] = path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

for k, v in parts.items():
    log("PASS" if v.strip() else "FAIL", "Manuscript loading", f"{k}: characters={len(v)}")

# ------------------------------------------------------------------
# 15.3 STRUCTURE / ACADEMIC READINESS
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.3 - MANUSCRIPT STRUCTURE & ACADEMIC READINESS")
print("-" * 100)

checks = []
structure_terms = {
    "Abstract": parts["abstract"],
    "Methodology": parts["method"],
    "Results": parts["results"],
    "Discussion": parts["discussion"],
    "Limitations": parts["limitations"],
    "Conclusion": parts["conclusion"],
    "Evidence traceability": parts["traceability"],
}
for name, text in structure_terms.items():
    ok = len(text.strip()) > 50
    checks.append({"Check": "Section present", "Section": name, "Status": "PASS" if ok else "FAIL"})
    log("PASS" if ok else "FAIL", "Manuscript structure", name)

# Conservative language-polish checks: report potential issues only.
full = parts["full"]
lower = full.lower()
style_flags = []
for pattern, label in [
    (r"\bvery\b", "Informal intensifier 'very'"),
    (r"\bobviously\b", "Potentially subjective 'obviously'"),
    (r"\bclearly\b", "Potentially assertive 'clearly'"),
    (r"\bwe prove\b", "Over-strong causal/proof wording"),
    (r"\bproves that\b", "Over-strong proof wording"),
]:
    n = len(re.findall(pattern, lower))
    if n:
        style_flags.append({"Pattern": label, "Count": n, "Status": "REVIEW"})
write_csv(TABLES / "02_style_review_flags.csv", style_flags or [{"Pattern":"No flagged terms","Count":0,"Status":"PASS"}])
log("PASS", "Style review", f"Flags for manual review={len(style_flags)}")

# ------------------------------------------------------------------
# 15.4 NUMERIC CONSISTENCY
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.4 - NUMERIC & SCENARIO CONSISTENCY")
print("-" * 100)

numeric_path = STEP12 / "tables" / "14_numeric_highlights.csv"
numeric_rows = read_csv(numeric_path) if numeric_path.exists() else []
claims_path = STEP12 / "tables" / "13_claim_to_evidence.csv"
claim_rows = read_csv(claims_path) if claims_path.exists() else []

numeric_values = []
for row in numeric_rows:
    for k, v in row.items():
        if k.lower() in {"value", "numeric value", "mean", "result", "metric value"}:
            try:
                numeric_values.append(float(str(v).replace(",", "")))
            except Exception:
                pass

scenario_names = [
    "Baseline",
    "Scenario 1 - Formal-Informal Integration",
    "Scenario 2 - Economic Incentives",
    "Scenario 3 - Information & Traceability",
    "Scenario 4 - Producer Responsibility",
    "Scenario 5 - Combined Orchestration",
]

scenario_hits = {s: (s.lower() in lower) for s in scenario_names}
for s, ok in scenario_hits.items():
    log("PASS" if ok else "FAIL", "Scenario consistency", s)

log("PASS" if numeric_rows else "FAIL", "Numeric source", f"Rows={len(numeric_rows)}")
log("PASS" if all(map(lambda x: x == x and abs(x) != float("inf"), numeric_values)) else "FAIL",
    "Numeric source", f"Finite numeric values={len(numeric_values)}")

# ------------------------------------------------------------------
# 15.5 CLAIM / EVIDENCE / STATISTICAL REPORTING
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.5 - CLAIM, EVIDENCE & STATISTICAL REPORTING READINESS")
print("-" * 100)

linked = 0
for r in claim_rows:
    evidence = str(r.get("Evidence", "")).strip()
    if evidence:
        linked += 1
coverage = (100.0 * linked / len(claim_rows)) if claim_rows else 0.0
log("PASS" if coverage == 100.0 else "FAIL", "Claim-to-evidence coverage",
    f"Linked={linked}/{len(claim_rows)}; coverage={coverage:.2f}%")

stat_path = STEP12 / "tables" / "05_statistical_evidence.csv"
effect_path = STEP12 / "tables" / "07_effect_size_evidence.csv"
sens_path = STEP12 / "tables" / "09_sensitivity_evidence.csv"
val_path = STEP12 / "tables" / "10_validation_evidence.csv"
stat_rows = read_csv(stat_path) if stat_path.exists() else []
effect_rows = read_csv(effect_path) if effect_path.exists() else []
sens_rows = read_csv(sens_path) if sens_path.exists() else []
val_rows = read_csv(val_path) if val_path.exists() else []

for label, rows in [
    ("Statistical evidence", stat_rows),
    ("Effect-size evidence", effect_rows),
    ("Sensitivity evidence", sens_rows),
    ("Validation evidence", val_rows),
]:
    log("PASS" if rows else "FAIL", label, f"Rows={len(rows)}")

# ------------------------------------------------------------------
# 15.6 JOURNAL-READY MANUSCRIPT BUILD
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.6 - BUILDING JOURNAL-READY MANUSCRIPT")
print("-" * 100)

header = (
    "E-WASTE ABM\n"
    "FINAL JOURNAL-READY MANUSCRIPT\n"
    "Prepared from authoritative STEP 12-14 outputs\n"
    f"Generated: {datetime.now().isoformat(timespec='seconds')}\n"
    + "=" * 100 + "\n\n"
)

journal_text = header
journal_text += "ABSTRACT\n\n" + parts["abstract"].strip() + "\n\n"
journal_text += "METHOD INTEGRATION\n\n" + parts["method"].strip() + "\n\n"
journal_text += "RESULTS\n\n" + parts["results"].strip() + "\n\n"
journal_text += "DISCUSSION\n\n" + parts["discussion"].strip() + "\n\n"
journal_text += "LIMITATIONS\n\n" + parts["limitations"].strip() + "\n\n"
journal_text += "CONCLUSION\n\n" + parts["conclusion"].strip() + "\n\n"
journal_text += "EVIDENCE TRACEABILITY\n\n" + parts["traceability"].strip() + "\n"

journal_txt = MANUSCRIPT / "FINAL_JOURNAL_READY_MANUSCRIPT.txt"
journal_txt.write_text(journal_text, encoding="utf-8")
log("PASS", "Journal manuscript", str(journal_txt))

# Copy the already-authoritative DOCX without rewriting its contents.
journal_docx = MANUSCRIPT / "FINAL_JOURNAL_READY_MANUSCRIPT.docx"
src_docx = STEP14 / "manuscript" / "FINAL_SUBMISSION_MANUSCRIPT.docx"
if src_docx.exists():
    shutil.copy2(src_docx, journal_docx)
    log("PASS", "Journal manuscript DOCX", str(journal_docx))
else:
    log("FAIL", "Journal manuscript DOCX", "STEP14 DOCX missing")

# ------------------------------------------------------------------
# 15.7 TABLE / FIGURE ASSEMBLY
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.7 - FINAL TABLE / FIGURE ASSEMBLY")
print("-" * 100)

asset_manifest = []
publication_dir = STEP13 / "FINAL_PUBLICATION_PACKAGE"
if publication_dir.exists():
    assets = [p for p in publication_dir.rglob("*") if p.is_file()]
else:
    assets = []

for p in assets:
    dest = PACKAGE / "publication_assets" / p.relative_to(publication_dir)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
    asset_manifest.append({
        "Source": str(p),
        "Destination": str(dest),
        "Size_bytes": p.stat().st_size,
        "Status": "PASS" if p.stat().st_size > 0 else "FAIL",
    })

write_csv(TABLES / "03_publication_asset_manifest.csv", asset_manifest,
          ["Source", "Destination", "Size_bytes", "Status"])
log("PASS" if asset_manifest else "FAIL", "Publication asset assembly",
    f"Artifacts copied={len(asset_manifest)}")

# ------------------------------------------------------------------
# 15.8 REPRODUCIBILITY PACKAGE
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.8 - REPRODUCIBILITY PACKAGE")
print("-" * 100)

repro_sources = [
    ROOT / "results_step00" / "ABM_PARAMETER_CONFIG.json",
    ROOT / "results_step00" / "ABM_BASE_PARAMETERS.csv",
    ROOT / "results_step00" / "ABM_SCENARIO_PARAMETERS.csv",
    ROOT / "results_step01" / "STEP01_AGENT_SPECIFICATION.csv",
    ROOT / "results_step01" / "STEP01_AGENT_PARAMETERS.csv",
    ROOT / "results_step02" / "STEP02_RAW_SIMULATION_RESULTS.csv",
]
repro_manifest = []
for p in repro_sources:
    dest = PACKAGE / "reproducibility" / p.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        shutil.copy2(p, dest)
        ok = dest.stat().st_size > 0
    else:
        ok = False
    repro_manifest.append({"Source":str(p), "Destination":str(dest), "Status":"PASS" if ok else "FAIL"})
    log("PASS" if ok else "FAIL", "Reproducibility asset", p.name)

write_csv(TABLES / "04_reproducibility_manifest.csv", repro_manifest,
          ["Source","Destination","Status"])

# ------------------------------------------------------------------
# 15.9 SUBMISSION CHECKLIST
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.9 - FINAL JOURNAL SUBMISSION CHECKLIST")
print("-" * 100)

checklist = [
    ("STEP14 pre-submission audit passed", (STEP14 / "FINAL_SUBMISSION_PACKAGE_MANIFEST.csv").exists()),
    ("Final manuscript TXT available", journal_txt.exists() and journal_txt.stat().st_size > 0),
    ("Final manuscript DOCX available", journal_docx.exists() and journal_docx.stat().st_size > 0),
    ("Abstract present", bool(parts["abstract"].strip())),
    ("Methodology present", bool(parts["method"].strip())),
    ("Results present", bool(parts["results"].strip())),
    ("Discussion present", bool(parts["discussion"].strip())),
    ("Limitations present", bool(parts["limitations"].strip())),
    ("Conclusion present", bool(parts["conclusion"].strip())),
    ("Claim-to-evidence coverage = 100%", coverage == 100.0),
    ("Statistical evidence available", bool(stat_rows)),
    ("Effect-size evidence available", bool(effect_rows)),
    ("Sensitivity evidence available", bool(sens_rows)),
    ("Validation evidence available", bool(val_rows)),
    ("Publication assets assembled", bool(asset_manifest)),
    ("Reproducibility inputs assembled", all(x["Status"] == "PASS" for x in repro_manifest)),
]
check_rows = []
for item, ok in checklist:
    check_rows.append({"Checklist item":item, "Status":"PASS" if ok else "FAIL"})
    log("PASS" if ok else "FAIL", "Submission checklist", item)
write_csv(TABLES / "05_final_journal_submission_checklist.csv", check_rows)

# ------------------------------------------------------------------
# 15.10 FINAL MANIFEST
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.10 - FINAL JOURNAL SUBMISSION MANIFEST")
print("-" * 100)

all_files = [p for p in PACKAGE.rglob("*") if p.is_file()]
manifest = []
for p in all_files:
    manifest.append({
        "Artifact": p.name,
        "Relative_path": str(p.relative_to(PACKAGE)),
        "Size_bytes": p.stat().st_size,
        "Non_empty": p.stat().st_size > 0,
    })
write_csv(OUT / "FINAL_JOURNAL_SUBMISSION_PACKAGE_MANIFEST.csv", manifest)
log("PASS" if all(x["Non_empty"] for x in manifest) and manifest else "FAIL",
    "Final manifest", f"Artifacts={len(manifest)}")

# ------------------------------------------------------------------
# 15.11 VALIDATION
# ------------------------------------------------------------------
print("\n" + "-" * 100)
print("STEP 15.11 - FINAL STEP 15 VALIDATION")
print("-" * 100)

failures = [r for r in check_rows if r["Status"] == "FAIL"]
validation = [
    {"Check":"Input integrity", "Status":"PASS" if all(x["Status"]=="PASS" for x in integrity) else "FAIL"},
    {"Check":"Manuscript structure", "Status":"PASS" if all(x["Status"]=="PASS" for x in checks) else "FAIL"},
    {"Check":"Claim-to-evidence", "Status":"PASS" if coverage == 100.0 else "FAIL"},
    {"Check":"Submission checklist", "Status":"PASS" if not failures else "FAIL"},
    {"Check":"Final package non-empty", "Status":"PASS" if manifest and all(x["Non_empty"] for x in manifest) else "FAIL"},
]
write_csv(TABLES / "06_final_step15_validation.csv", validation)

overall_fail = sum(1 for x in validation if x["Status"] == "FAIL")

# ------------------------------------------------------------------
# 15.12 REPORT
# ------------------------------------------------------------------
report = OUT / "STEP15_FINAL_JOURNAL_SUBMISSION_READINESS_REPORT.txt"
report_text = f"""E-WASTE ABM
STEP 15 FINAL JOURNAL SUBMISSION & MANUSCRIPT POLISH REPORT
============================================================

Status: {"PASS" if overall_fail == 0 else "FAIL"}

Claim-to-evidence coverage : {coverage:.2f}%
Statistical evidence rows  : {len(stat_rows)}
Effect-size evidence rows  : {len(effect_rows)}
Sensitivity evidence rows  : {len(sens_rows)}
Validation evidence rows   : {len(val_rows)}
Publication assets copied  : {len(asset_manifest)}
Submission package files   : {len(manifest)}
Checklist failures         : {len(failures)}
Validation failures        : {overall_fail}

Journal-ready manuscript:
{journal_docx}

Final package:
{PACKAGE}

NOTE:
STEP 15 does not alter simulation results, scenario values, statistical evidence,
sensitivity outputs, validation outcomes, or authoritative numeric findings.
It assembles and audits the already validated STEP 12-14 outputs for journal submission.
"""
report.write_text(report_text, encoding="utf-8")
log("PASS" if overall_fail == 0 else "FAIL", "Readiness report", str(report))

print("\n" + "=" * 100)
print("STEP 15 FINAL SUMMARY")
print("=" * 100)
print(f"Manuscript sections audited : 7")
print(f"Claim-to-evidence coverage  : {coverage:.2f}%")
print(f"Statistical evidence rows   : {len(stat_rows)}")
print(f"Effect-size evidence rows  : {len(effect_rows)}")
print(f"Sensitivity evidence rows  : {len(sens_rows)}")
print(f"Validation evidence rows   : {len(val_rows)}")
print(f"Publication assets          : {len(asset_manifest)}")
print(f"Submission artifacts        : {len(manifest)}")
print(f"Checklist failures          : {len(failures)}")
print(f"Validation failures         : {overall_fail}")
print(f"Output folder               : {OUT}")
print(f"Final package               : {PACKAGE}")
print()
print("STEP 15 STATUS :", "PASS" if overall_fail == 0 else "FAIL")
print("FINAL JOURNAL SUBMISSION READY" if overall_fail == 0 else "FINAL JOURNAL SUBMISSION NOT READY")
